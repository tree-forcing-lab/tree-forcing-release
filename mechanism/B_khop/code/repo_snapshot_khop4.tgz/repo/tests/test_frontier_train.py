"""Frontier interchange (card B3), the training side: frontier.Frontier (source pass + slice write at layer L), the
trainer seams of scripts/train_student.py (--b3-arm) and the readout. CPU, the tiny random Qwen3.5 text model (8 layers,
hidden 64) with the GPT-2 tokenizer, as tests/test_depth_forcing.py. Checks: the write puts exactly the source's slice
at the receiver's positions and changes nothing else; checkpointing on (reentrant and non-reentrant) equals off with the
hook active; the gradient reaches the receiver's layers and, only with --b3-source-grad, the source's; the loss of a
mixed micro-batch is kl_loss's (pads at weight 0 contribute nothing); 30 steps on 8 fixed receiver / source pairs make
the intervened forward pick the counterfactual letter while the plain CE still falls; the readout reports cf11 / same;
FSDP2 at world 1 with the hook; the trainer end to end per arm (subprocess) with its metrics block; the flag-off path
byte-identical to src_df's (COTD_REF_REPO); flag validation."""
import copy
import json
import os
import subprocess
import sys
import tempfile
import unittest
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "tests"))

try:
    import torch
    import transformers
    from cotdistill.frontier import (B3Example, B3Spec, B3Window, Frontier, SLOT_ALIGNED, SLOT_SPARE, STAT_LEN,
                                     _SliceWrite, bound_of, build_table, cf_answer, empty_stats, make_example,
                                     node_ends_all, parse_options, readout_summary, resolve_ends, stats_from_vector,
                                     stats_vector, strict_example, substitute)
    from cotdistill.depth_forcing import _Capture, canon_number, token_at
    from cotdistill.student import FINAL_TEMPLATE, Example, body_layers, collate, kl_loss, label_logits, text_parts
    from test_depth_forcing import gpt2_tok, tiny_qwen35
    from test_frontier import LETTERS, item, step
    HAVE = True
except ImportError:
    HAVE = False

from dataclasses import replace as dataclasses_replace  # noqa: E402

ENV = {**os.environ, "CUDA_VISIBLE_DEVICES": "", "OMP_NUM_THREADS": "2"}
TRAIN = str(ROOT / "scripts/train_student.py")


def diamond(j: int, a: int, b: int, c: int, d: int, who: str = "Tom") -> dict:
    """The 4-step diamond program with literals a, b, c, d: s0 = a - b, s1 = s0 x c, s2 = s1 + s0, s3 = s2 / d."""
    s0, s1 = a - b, (a - b) * c
    s2 = s1 + s0
    s3 = Fraction(s2, d)
    assert s3.denominator == 1, (a, b, c, d)
    prompt = (f"{who} had {a} apples and lost {b}. {who} multiplied what was left by {c}, added what was left before "
              f"multiplying and shared the total among {d} friends. How many each?")
    steps = [step(0, "−", a, b, s0), step(1, "×", s0, c, s1, a_from=0),
             step(2, "+", s1, s0, s2, a_from=1, b_from=0), step(3, "÷", s2, d, int(s3), a_from=2)]
    gold = int(s3)
    return item(f"d{j}", prompt, steps, [str(gold), str(gold + 11), str(gold + 23), str(gold + 5), str(gold + 2)])


def items8() -> list:
    """8 receivers: distinct literals (so every frontier value differs), the last two identical in program (a match
    pair: d6 and d7 share a, b, c, d with different names)."""
    base = [(5, 2, 4, 3), (9, 3, 2, 3), (7, 1, 3, 4), (12, 4, 5, 6), (8, 2, 7, 4), (10, 4, 3, 8)]
    its = [diamond(j, *t) for j, t in enumerate(base)]
    its.append(diamond(6, 6, 2, 5, 4, "Ann"))
    its.append(diamond(7, 6, 2, 5, 4, "Bob"))
    return its


def finals(items: list) -> list:
    return [Example(FINAL_TEMPLATE.format(problem=it["prompt"]), it["labels"], [it["teacher"][L] for L in it["labels"]],
                    1.0, "final", it["item_id"]) for it in items]


@unittest.skipUnless(HAVE, "needs torch + transformers")
class TestForward(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            cls.tok = gpt2_tok()
        except Exception as e:
            raise unittest.SkipTest(f"no local gpt2 tokenizer: {e}")
        cls.items = items8()
        cls.by = {it["item_id"]: it for it in cls.items}

    def fresh(self, spec=None, seed=0):
        model = tiny_qwen35(len(self.tok), seed)
        model.config.use_cache = False
        model.train()
        spec = spec or B3Spec("fsiit", layer=2, dim=8, seed=1)       # 2 x 4 x 8 = 64 = hidden
        fr = Frontier(model, spec)
        table = build_table(self.items, spec)
        return model, fr, spec, table

    def views(self, spec, table, epoch=0):
        out = []
        for it in self.items:
            r = make_example(it, table[it["item_id"]], table, spec, self.by, epoch=epoch)
            if r is None:                                  # ssiit: an item whose single-node counterfactuals are not clean
                self.assertEqual(spec.arm, "ssiit", it["item_id"])
                continue
            out.append(r[0])
        self.assertGreaterEqual(len(out), 6)
        return out

    def test_spec_limits(self):
        model = tiny_qwen35(len(self.tok))
        with self.assertRaises(ValueError):
            Frontier(model, B3Spec("fsiit", layer=7, dim=8))                  # layer L + 1 must exist
        with self.assertRaises(ValueError):
            Frontier(model, B3Spec("fsiit", layer=2, dim=40))                 # 2 x 40 > 64 (aligned + spare slice)
        Frontier(model, B3Spec("fsiit", layer=2, dim=32))                     # 2 x 32 = 64: max_nodes no longer counts
        Frontier(model, B3Spec("fsiit", layer=2, dim=8))

    def test_slice_write_is_exact(self):                                    # the write and nothing else
        model, fr, spec, table = self.fresh()
        model.eval()
        views = self.views(spec, table)
        batch = finals(self.items[:2]) + views[:3]
        body, _ = text_parts(model)
        L, d = spec.layer, spec.dim
        # the receiver's layer-L output with the write, captured at layer L + 1's input (the second fire: the source
        # pass runs first inside forward)
        fires = []
        hd = fr.dl[L + 1].register_forward_pre_hook(lambda m, a, k: fires.append((a[0] if a else k["hidden_states"]).detach().clone()),
                                                     with_kwargs=True)
        try:
            with torch.no_grad():
                z, st = fr.forward(model, self.tok, batch, 512, {})
        finally:
            hd.remove()
        self.assertEqual(len(fires), 2)
        written = fires[1]
        b = collate(self.tok, batch, 512, "cpu")
        with torch.no_grad(), _Capture(fr.dl, (L,)) as cap0:
            body(input_ids=b["input_ids"], attention_mask=b["attention_mask"], use_cache=False)
        plain = cap0.h[L]
        # the sources' layer-L outputs
        srcs = sorted({v.source_text for v in views[:3]}, key=lambda t: [v.source_text for v in views[:3]].index(t))
        sb = collate(self.tok, [Example(t, ["A"], [1.0], 1.0, "final", "s") for t in srcs], 512, "cpu")
        with torch.no_grad(), _Capture(fr.dl, (L,)) as caps:
            body(input_ids=sb["input_ids"], attention_mask=sb["attention_mask"], use_cache=False)
        src = caps.h[L]
        mask = torch.zeros_like(plain, dtype=torch.bool)
        for i, v in enumerate(batch):
            if not isinstance(v, B3Example):
                continue
            for r_end, s_end, slot in v.nodes:
                rp, sp = token_at(self.tok, v.text, r_end, 512), token_at(self.tok, v.source_text, s_end, 512)
                self.assertEqual(slot, 0)
                self.assertTrue(torch.equal(written[i, rp, 0:d], src[srcs.index(v.source_text), sp, 0:d]))
                mask[i, rp, 0:d] = True
        self.assertTrue(torch.equal(written[~mask], plain[~mask]))           # nothing else changed
        self.assertTrue(torch.equal(written[..., 2 * d:], plain[..., 2 * d:]))   # nothing outside [0, 2d) ever
        self.assertGreater(int(mask.sum()), 0)
        two = [v for v in batch if isinstance(v, B3Example) and len(v.nodes) == 2]
        for v in two:                                                        # two nodes: two distinct tokens
            self.assertEqual(len({token_at(self.tok, v.text, n[0], 512) for n in v.nodes}), 2)
        self.assertEqual(st["modes"]["full"][0], 3)
        self.assertEqual(st["n_src"], len(srcs))
        self.assertEqual(st["cut"], 0)
        # plain examples give label_logits' logits bit for bit (the write touches other rows only)
        z_plain = label_logits(model, self.tok, batch[:2], 512, {})
        for a_, b_ in zip(z_plain, z[:2]):
            self.assertTrue(torch.equal(a_, b_))

    def test_single_and_strict_writes(self):
        spec = B3Spec("ssiit", layer=2, dim=8, seed=1)
        model, fr, spec, table = self.fresh(spec)
        views = self.views(spec, table)
        self.assertTrue(all(len(v.nodes) == 1 for v in views))
        z, st = fr.forward(model, self.tok, views, 512, {})
        self.assertEqual(st["modes"]["single"][0], len(views))
        sv = [strict_example(it, table[it["item_id"]], table, spec, self.by, epoch=0) for it in self.items]
        sv = [x[0] for x in sv if x is not None]
        self.assertGreaterEqual(len(sv), 6)                                   # every item with S and S'
        z2, st2 = fr.forward(model, self.tok, sv, 512, {})
        self.assertEqual(st2["modes"]["strict"][0], len(sv))
        self.assertEqual(st2["cut"], 0)

    def test_checkpointing_equal(self):                                     # the hook under both checkpoint modes
        def run(ckpt):
            model, fr, spec, table = self.fresh()
            if ckpt is not None:
                model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": ckpt})
                if ckpt:
                    model.enable_input_require_grads()
            batch = finals(self.items[:2]) + self.views(spec, table)[:4]
            z, st = fr.forward(model, self.tok, batch, 512, {})
            loss = kl_loss(z, batch)
            model.zero_grad(set_to_none=True)
            loss.backward()
            g = {n: p.grad.detach().clone() for n, p in model.named_parameters() if p.grad is not None}
            if ckpt is not None:                                            # the flag was restored
                self.assertTrue(all(lay.gradient_checkpointing for lay in fr.dl))
            return loss.detach(), g
        off, non_re, re = run(None), run(False), run(True)
        for name, (loss, g) in (("non-reentrant", non_re), ("reentrant", re)):
            self.assertLess(abs(float(loss) - float(off[0])), 1e-5, name)
            self.assertEqual(set(g), set(off[1]), name)
            for n in off[1]:
                self.assertTrue(torch.allclose(off[1][n], g[n], atol=1e-5, rtol=1e-4), (name, n))

    def test_gradient_paths(self):
        """The receiver's layers <= L and > L get gradient; the source pass is detached by default (its activations are
        not in the graph) and in the graph with source_grad."""
        model, fr, spec, table = self.fresh()
        views = self.views(spec, table)[:4]
        z, st = fr.forward(model, self.tok, views, 512, {})
        model.zero_grad(set_to_none=True)
        kl_loss(z, views).backward()
        g = {n for n, p in model.named_parameters() if p.grad is not None and p.grad.abs().sum() > 0}
        self.assertTrue(any(n.startswith("model.layers.0.") for n in g))
        self.assertTrue(any(n.startswith("model.layers.6.") for n in g))
        # with the source gradient on, the written slices carry grad_fn
        spec_g = B3Spec("fsiit", layer=2, dim=8, seed=1, source_grad=True)
        model2, fr2, _, table2 = self.fresh(spec_g)
        src_grad = []
        orig = _SliceWrite.__enter__

        def spy(self_):
            src_grad.extend(v.requires_grad for *_, v in self_.writes)
            return orig(self_)
        _SliceWrite.__enter__ = spy
        try:
            fr2.forward(model2, self.tok, views, 512, {})
            with_grad = list(src_grad)
            src_grad.clear()
            fr.forward(model, self.tok, views, 512, {})
            without = list(src_grad)
        finally:
            _SliceWrite.__enter__ = orig
        self.assertTrue(with_grad and all(with_grad))
        self.assertTrue(without and not any(without))

    def test_loss_assembly_and_pads(self):
        """kl_loss over a mixed micro-batch = plain CE on plain examples + the views' CE toward their labels (cf for full,
        gold for strict, distractor for sham), weighted; a pad (weight 0) adds nothing; the stats count every non-pad
        view; the stats vector round-trips."""
        import dataclasses
        model, fr, spec, table = self.fresh()
        views = self.views(spec, table)[:3]
        sham_spec = B3Spec("sham", layer=2, dim=8, seed=1)
        sham = make_example(self.items[3], table["d3"], table, sham_spec, self.by)[0]
        strict = strict_example(self.items[6], table["d6"], table, spec, self.by)[0]
        pad = dataclasses.replace(views[0], weight=0.0)
        batch = finals(self.items[:1]) + views + [sham, strict, pad]
        z, st = fr.forward(model, self.tok, batch, 512, {})
        loss = kl_loss(z, batch)
        manual = 0.0
        for zi, e in zip(z, batch):
            manual = manual + e.weight * -(torch.tensor(e.target) * torch.log_softmax(zi, -1)).sum()
        self.assertLess(abs(float(loss) - float(manual / len(batch))), 1e-6)
        self.assertEqual(sham.target[sham.cf_gold], 1.0)
        self.assertNotEqual(sham.cf_gold, sham.orig_gold)
        self.assertEqual(strict.target[strict.orig_gold], 1.0)
        self.assertEqual({m: v[0] for m, v in st["modes"].items()},
                         {"full": 3, "single": 0, "strict": 1, "sham": 1, "cfaug": 0, "plain": 1, "blockplain": 0})
        self.assertEqual(stats_from_vector(stats_vector(st)), st)
        self.assertEqual(len(stats_vector(st)), STAT_LEN)
        w = B3Window()
        w.add(st)
        r = w.row()
        self.assertEqual((r["b3_full_n"], r["b3_strict_n"], r["b3_sham_n"]), (3, 1, 1))
        self.assertNotIn("b3_single_n", r)
        self.assertEqual(r["b3_plain_n"], 1)
        self.assertEqual(w.row(), {"b3_cut": 0, "b3_src_fwd": 0})
        self.assertEqual(w.totals["modes"]["full"][0], 3)
        # a micro-batch without any view: no source pass (outside --fsdp), only the plain column counts
        z0, st0 = fr.forward(model, self.tok, finals(self.items[:2]), 512, {})
        self.assertEqual((st0["n_src"], st0["modes"]["plain"][0], sum(v[0] for v in st0["modes"].values())), (0, 2, 2))

    def test_substitute(self):
        spec = B3Spec("fsiit", layer=2, dim=8, seed=1, p=1.0, strict_share=1.0)
        table = build_table(self.items, spec)
        counts: dict = {}
        out = []
        for it in self.items:
            out += substitute(finals([it]), it, table.get(it["item_id"]), table, spec, self.by, 0, counts)
        self.assertEqual(len(out), len(self.items))                        # substitution, not addition
        strict = [e for e in out if isinstance(e, B3Example) and e.mode == "strict"]
        self.assertEqual(counts.get("strict", 0), len(strict))              # strict share 1.0: strict wherever it exists
        self.assertEqual(counts.get("strict", 0) + counts.get("strict_fallback", 0), len(self.items))
        self.assertEqual(counts.get("full", 0) + counts.get("no_view", 0), counts.get("strict_fallback", 0))
        self.assertEqual(sum(counts.get(f"strict_{v}", 0) for v in ("pos_num", "pos_other", "sub")), counts["strict"])
        self.assertGreaterEqual(counts["strict"], 6)
        # share 0.5 over many epochs: about half of the intervened views are strict
        spec5 = B3Spec("fsiit", layer=2, dim=8, seed=1, p=1.0, strict_share=0.5)
        c5: dict = {}
        for ep in range(40):
            for it in self.items:
                substitute(finals([it]), it, table.get(it["item_id"]), table, spec5, self.by, ep, c5)
        share = c5["strict"] / (c5["strict"] + c5["full"])
        self.assertTrue(0.38 < share < 0.62, c5)
        spec0 = B3Spec("fsiit", layer=2, dim=8, seed=1, p=0.0)
        c0: dict = {}
        out0 = [substitute(finals([it]), it, table.get(it["item_id"]), table, spec0, self.by, 0, c0)[0] for it in self.items]
        self.assertTrue(all(type(e) is Example for e in out0))
        self.assertEqual(c0, {"plain": 8})
        # an item without a plan or whose last example is not a final view stays
        self.assertEqual(substitute(finals([self.items[0]]), self.items[0], None, table, spec, self.by, 0, {}), finals([self.items[0]]))

    def test_strict_writes_land_off_node(self):
        """Item 3 at token level: 'pos' writes land at a question token that is no node token of any boundary of R
        (slot [0, d)); 'sub' writes touch only [d, 2d) at R's node tokens of the boundary; the partner's frontier
        values differ from R's; label = the gold."""
        model, fr, spec, table = self.fresh()
        model.eval()
        L, d = spec.layer, spec.dim
        seen = set()
        for ep in range(6):
            for it in self.items:
                pl = table[it["item_id"]]
                out = strict_example(it, pl, table, spec, self.by, epoch=ep)
                if out is None:
                    continue
                ex = out[0]
                seen.add(ex.variant)
                b, sb = bound_of(table, ex.item_id, ex.k), bound_of(table, ex.source_id, ex.k_src)
                self.assertNotEqual(b.values, sb.values)
                self.assertEqual(ex.cf_gold, ex.orig_gold)
                node_tok = {token_at(self.tok, ex.text, e, 512) for e in node_ends_all(it, pl.steps)}
                q_end = token_at(self.tok, ex.text, len(it["prompt"].split("\nOptions:")[0]), 512)
                toks = [token_at(self.tok, ex.text, n[0], 512) for n in ex.nodes]
                if ex.variant.startswith("pos"):
                    self.assertTrue(all(n[2] == SLOT_ALIGNED for n in ex.nodes))
                    self.assertTrue(all(t not in node_tok and 0 <= t <= q_end for t in toks), (toks, node_tok))
                else:
                    r_ends, _ = resolve_ends(it, b.ends)
                    self.assertEqual(toks, [token_at(self.tok, ex.text, e, 512) for e in r_ends])
                    self.assertTrue(all(n[2] == SLOT_SPARE for n in ex.nodes))
                # the write: only [0, d) at the pos tokens or [d, 2d) at the node tokens, nothing else
                fires = []
                hd = fr.dl[L + 1].register_forward_pre_hook(
                    lambda m, a, k: fires.append((a[0] if a else k["hidden_states"]).detach().clone()), with_kwargs=True)
                try:
                    with torch.no_grad():
                        _, st = fr.forward(model, self.tok, [ex], 512, {})
                finally:
                    hd.remove()
                self.assertEqual(st["cut"], 0)
                bb = collate(self.tok, [ex], 512, "cpu")
                with torch.no_grad(), _Capture(fr.dl, (L,)) as cap0:
                    text_parts(model)[0](input_ids=bb["input_ids"], attention_mask=bb["attention_mask"], use_cache=False)
                diff = (fires[-1] != cap0.h[L])[0]
                lo = 0 if ex.variant.startswith("pos") else d
                allowed = torch.zeros_like(diff)
                for t in toks:
                    allowed[t, lo:lo + d] = True
                self.assertFalse(bool((diff & ~allowed).any()), ex.variant)
                self.assertTrue(bool(diff.any()))
        self.assertEqual(seen, {"pos_num", "sub"})                           # diamonds: a and d are free numbers

    def test_plain_column_equals_unhooked(self):
        """Item 5: on a micro-batch without an intervened view the plain column's CE is the soft CE of an un-hooked
        forward (label_logits) to 1e-5, its hits the argmax vs the gold."""
        model, fr, spec, table = self.fresh()
        model.eval()
        batch = [dataclasses_replace(e, gold=it["labels"].index(it["gold_label"]))
                 for e, it in zip(finals(self.items[:5]), self.items[:5])]
        with torch.no_grad():
            z, st = fr.forward(model, self.tok, batch, 512, {})
            ref = label_logits(model, self.tok, batch, 512, {})
        ce = sum(float(-(torch.tensor(e.target) * torch.log_softmax(r.float(), -1)).sum()) for r, e in zip(ref, batch))
        hits = sum(int(r.argmax()) == e.gold for r, e in zip(ref, batch))
        n, ce_sum, h, cut = st["modes"]["plain"]
        self.assertEqual(cut, 0)
        self.assertEqual(n, 5)
        self.assertLess(abs(ce_sum / n - ce / 5), 1e-5)
        self.assertEqual(h, hits)
        w = B3Window()
        w.add(st)
        r = w.row()
        self.assertLess(abs(r["b3_plain_ce"] - round(ce / 5, 4)), 1e-4)
        self.assertEqual((r["b3_plain_n"], r["b3_plain_acc"]), (5, round(hits / 5, 4)))
        self.assertEqual(B3Window.per_mode(st)["plain"]["n"], 5)

    def test_source_forwards_counted(self):
        """Item 6: a counter on the body's actual forward: a plain micro-batch outside --fsdp runs one forward (the
        receiver pass), CF-AUG views run one forward even with sync (the --fsdp path), a written arm under sync runs
        the dummy source pass on a plain micro-batch, and a micro-batch with a write runs two."""
        calls = []
        def counted(spec):
            model, fr, spec, table = self.fresh(spec)
            body, _ = text_parts(model)
            body.register_forward_pre_hook(lambda *a: calls.append(1))
            return model, fr, table
        model, fr, table = counted(B3Spec("fsiit", layer=2, dim=8, seed=1))
        calls.clear()
        fr.forward(model, self.tok, finals(self.items[:3]), 512, {})
        self.assertEqual((len(calls), fr.src_forwards), (1, 0))
        calls.clear()
        fr.forward(model, self.tok, finals(self.items[:3]), 512, {}, sync=True)   # --fsdp: the dummy source pass
        self.assertEqual((len(calls), fr.src_forwards, fr.src_dummy), (2, 0, 1))   # the dummy counts apart
        self.assertEqual(fr.src_seconds, 0.0)
        calls.clear()
        fr.forward(model, self.tok, finals(self.items[:1]) + self.views(fr.spec, table)[:2], 512, {})
        self.assertEqual((len(calls), fr.src_forwards, fr.src_dummy), (2, 1, 1))
        self.assertGreater(fr.src_seconds, 0.0)
        cf_spec = B3Spec("cfaug", layer=2, dim=8, seed=1)
        model, fr, table = counted(cf_spec)
        cviews = [make_example(it, table[it["item_id"]], table, cf_spec, self.by)[0] for it in self.items[:4]]
        self.assertTrue(all(v.mode == "cfaug" for v in cviews))
        for sync in (False, True):
            calls.clear()
            _, st = fr.forward(model, self.tok, finals(self.items[:1]) + cviews, 512, {}, sync=sync)
            self.assertEqual((len(calls), fr.src_forwards, fr.src_dummy, st["n_src"]), (1, 0, 0, 0), sync)

    def test_readout_decoy_pick(self):
        """Item 1, the readout: a model that always picks the decoy gives decoy = 1, acc = 0, ratio = 0 on cf11 / cf1;
        the same model keeps the gold without a write (block_plain gold = 1) and under the misaligned write
        (misaligned_keep = 1). readout_summary on a hand-built case too."""
        model, fr, spec, table = self.fresh()

        def fake(model_, tok, batch, max_len, cache):
            out = []
            for v in batch:
                pick = v.decoy if isinstance(v, B3Example) and v.mode == "full" and v.decoy >= 0 else v.gold
                z = torch.full((len(v.labels),), -5.0)
                z[pick] = 5.0
                out.append(z)
            return out, empty_stats()
        fr.call = fake
        ro = fr.readout(model, self.tok, self.items, [], 512, 4, {})
        for key in ("cf11", "cf1"):
            if ro[key]["n"]:
                self.assertEqual((ro[key]["acc"], ro[key]["decoy"], ro[key]["ratio"]), (0.0, 1.0, 0.0), key)
        self.assertGreater(ro["cf11"]["n"], 0)
        self.assertEqual((ro["block_plain"]["gold"], ro["block_plain"]["cf"], ro["block_plain"]["decoy"]), (1.0, 0.0, 0.0))
        self.assertEqual((ro["misaligned_keep"]["sub"]["keep"], ro["misaligned_keep"]["pos_num"]["keep"]), (1.0, 1.0))
        self.assertGreater(ro["misaligned_keep"]["sub"]["n"] + ro["misaligned_keep"]["pos_num"]["n"], 0)
        hand = readout_summary([2, 1, 0, 4], ["cf11", "block_plain", "misaligned", "cf1"],
                               [{"gold": 0, "cf": 1, "decoy": 2}, {"gold": 0, "cf": 1, "decoy": 2},
                                {"gold": 0, "cf": 1, "decoy": 2, "twin": 1, "variant": "pos_num"},
                                {"gold": 0, "cf": 4, "decoy": 3}])
        self.assertEqual(hand["cf11"], {"n": 1, "acc": 0.0, "decoy": 1.0, "ratio": 0.0, "cut": 0})
        self.assertEqual(hand["cf1"], {"n": 1, "acc": 1.0, "decoy": 0.0, "ratio": 1.0, "cut": 0})
        self.assertEqual(hand["block_plain"], {"n": 1, "gold": 0.0, "cf": 1.0, "decoy": 0.0, "cut": 0})
        self.assertEqual(hand["misaligned_keep"]["pos_num"], {"n": 1, "keep": 0.0})   # 0 != the twin's 1
        self.assertEqual(hand["misaligned_keep"]["sub"], {"n": 0, "keep": None})

    def test_cut_view_excluded(self):
        """Fix 2 item 2: a view whose write token falls outside the sequence (max_len cuts the question's start) is
        flagged per view: counted per mode in the training stats (b3_<mode>_cut) and, in the readout, kept out of every
        rate and counted in its dict's "cut"; n + cut is conserved against an uncut readout."""
        model, fr, spec, table = self.fresh()
        model.eval()
        views = self.views(spec, table)
        def cut_at(ml):                                                     # encode_tail keeps the tail: early
            return [i for i, v in enumerate(views)                          # node tokens fall outside the sequence
                    if any(token_at(self.tok, v.text, n[0], ml) is None or token_at(self.tok, v.source_text, n[1], ml) is None
                           for n in v.nodes)]
        ml = next(m for m in range(200, 10, -2) if cut_at(m))               # the longest max_len with a cut view
        exp = cut_at(ml)
        self.assertTrue(0 < len(exp) <= len(views), (ml, exp))
        with torch.no_grad():
            _, st = fr.forward(model, self.tok, views, ml, {})
        self.assertEqual(st["cut_rows"], exp)
        self.assertEqual(st["modes"]["full"][3], len(exp))
        w = B3Window()
        w.add(st)
        self.assertEqual(w.row()["b3_full_cut"], len(exp))
        self.assertEqual(B3Window.per_mode(w.totals)["full"]["cut"], len(exp))
        self.assertEqual(stats_from_vector(stats_vector(st))["modes"], st["modes"])
        full = fr.readout(model, self.tok, self.items, [], 512, 4, {})
        short = fr.readout(model, self.tok, self.items, [], ml, 4, {})
        self.assertGreater(short["cf11"]["cut"] + short["cf1"]["cut"], 0)
        for key in ("cf11", "cf1", "same"):
            self.assertEqual(short[key]["n"] + short[key]["cut"], full[key]["n"], key)
        self.assertEqual(short["block_plain"]["cut"], 0)                     # no write, never cut
        tot = lambda r: sum(r["misaligned_keep"][v]["n"] for v in ("sub", "pos_num", "pos_other"))
        self.assertEqual(tot(short) + short["misaligned_keep"]["cut"], tot(full))
        self.assertGreater(short["misaligned_keep"]["cut"], 0)
        # a cut misaligned view is not its twin's forward counted as kept
        hand = readout_summary([1, 1], ["block_plain", "misaligned"],
                               [{"gold": 1, "cf": 0, "decoy": 2}, {"gold": 1, "cf": 0, "decoy": 2, "twin": 0, "variant": "sub"}],
                               [False, True])
        self.assertEqual((hand["misaligned_keep"]["sub"], hand["misaligned_keep"]["cut"]), ({"n": 0, "keep": None}, 1))

    def test_number_follower_fails_pos_num(self):
        """Fix 2 item 1, hand-built: a model that follows any write on a NUMBER token and ignores every other write
        (the round-2 exploit: it passed the old 'pos' keep without reading the slice) now fails pos_num keep by
        construction, and the tier is G-fail."""
        import re as re_
        model, fr, spec, table = self.fresh()
        num_ends = {it["item_id"]: {m.end() for m in re_.finditer(r"-?\d+(?:,\d{3})*(?:\.\d+)?", it["prompt"].split("\nOptions:")[0])}
                    for it in self.items}

        def fake(model_, tok, batch, max_len, cache):
            out = []
            for v in batch:
                on_num = isinstance(v, B3Example) and any(n[0] in num_ends[v.item_id] for n in v.nodes)
                pick = (v.cf_s if v.cf_s >= 0 else v.gold) if on_num else v.gold
                z = torch.full((len(v.labels),), -5.0)
                z[pick] = 5.0
                out.append(z)
            return out, empty_stats()
        fr.call = fake
        ro = fr.readout(model, self.tok, self.items, [], 512, 4, {})
        mk = ro["misaligned_keep"]
        self.assertGreater(mk["pos_num"]["n"], 0)
        self.assertEqual(mk["pos_num"]["keep"], 0.0)
        self.assertEqual(ro["tier"], "G-fail")

    def test_tier_branches(self):
        """Fix 2 item 5: one row per branch (fractions), including mixed rows and a missing value."""
        from cotdistill.frontier import tier

        def row(acc, ratio, sub, pos, n=50):
            return {"cf11": {"n": n, "acc": acc, "ratio": ratio}, "cf1": {"n": n, "acc": acc, "ratio": ratio},
                    "misaligned_keep": {"sub": {"n": n, "keep": sub}, "pos_num": {"n": n, "keep": pos},
                                        "pos_other": {"n": 3, "keep": 0.0}, "cut": 0}}
        self.assertEqual(tier(row(0.60, 0.80, 0.95, 0.95)), "G-strong")        # every bar exactly met
        self.assertEqual(tier(row(0.59, 0.80, 0.95, 0.95)), "G-weak")
        self.assertEqual(tier(row(0.70, 0.75, 0.97, 0.97)), "G-weak")          # mixed: strong acc, weak ratio
        self.assertEqual(tier(row(0.70, 0.90, 0.97, 0.92)), "G-weak")          # one keep in 0.90-0.95
        self.assertEqual(tier(row(0.70, 0.65, 0.99, 0.99)), "G-fail")          # mixed: ratio below 0.70
        self.assertEqual(tier(row(0.39, 0.90, 0.99, 0.99)), "G-fail")
        self.assertEqual(tier(row(0.80, 0.90, 0.89, 0.99)), "G-fail")          # keep_sub below 0.90
        self.assertEqual(tier(row(0.80, 0.90, 0.99, 0.89)), "G-fail")          # keep_pos_num below 0.90
        self.assertEqual(tier(row(0.80, 0.90, 0.99, None)), "G-fail")          # pos_num n = 0: no evidence
        r = row(0.80, 0.90, 0.99, 0.99)
        r["cf1"] = {"n": 0, "acc": None, "ratio": None}
        self.assertEqual((tier(r), tier(r, "cf1")), ("G-strong", "G-fail"))

    def overfit(self, spec, steps=30, lr=3e-3):
        model, fr, spec, table = self.fresh(spec)
        views = self.views(spec, table)
        plain = finals(self.items)
        opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=lr, weight_decay=0.0)
        ces = []
        for _ in range(steps):
            z, st = fr.forward(model, self.tok, plain + views, 512, {})
            loss = kl_loss(z, plain + views)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
            with torch.no_grad():
                ces.append(float(kl_loss([zz.detach() for zz in z[:len(plain)]], plain)))
        with torch.no_grad():
            z, st = fr.forward(model, self.tok, views, 512, {})
            acc = sum(int(zz.argmax()) == v.cf_gold for zz, v in zip(z, views)) / len(views)
        return acc, ces, model, fr, table, views

    def test_overfit_to_counterfactual(self):
        acc, ces, model, fr, table, views = self.overfit(B3Spec("fsiit", layer=2, dim=8, seed=1))
        self.assertEqual(acc, 1.0, ces[::10])
        self.assertLess(ces[-1], ces[0] * 0.5, (ces[0], ces[-1]))
        # the readout on the same items (sources from the pool = the items themselves): cf1 / cf11 high, same keeps
        ro = fr.readout(model, self.tok, self.items, [], 512, 4, {})
        self.assertGreater(ro["cf11"]["n"] + ro["cf1"]["n"], 0)
        self.assertGreaterEqual(ro["same"]["n"], 1)                          # d6 <-> d7 share every frontier value
        for key in ("cf11", "cf1"):
            if ro[key]["n"]:
                self.assertIsNotNone(ro[key]["acc"])
                self.assertIsNotNone(ro[key]["decoy"])
        self.assertIsNotNone(ro["block_plain"]["gold"])
        self.assertIsNotNone(ro["misaligned_keep"]["sub"]["keep"])
        self.assertIn(ro["tier"], ("G-strong", "G-weak", "G-fail"))
        self.assertIsNotNone(ro["same"]["keep"])

    def test_readout_untrained_shape(self):
        model, fr, spec, table = self.fresh()
        ro = fr.readout(model, self.tok, self.items[:4], self.items[4:], 512, 4, {})
        self.assertEqual(set(ro), {"cf11", "cf1", "same", "block_plain", "misaligned_keep", "no_partner", "no_decoy", "tier", "tier_cf1",
                                   "misaligned_skip", "views"})
        self.assertEqual(ro["cf11"]["n"] + ro["cf1"]["n"], ro["block_plain"]["n"])
        mk = ro["misaligned_keep"]
        self.assertEqual(mk["sub"]["n"] + mk["pos_num"]["n"] + mk["pos_other"]["n"] + mk["cut"] + ro["misaligned_skip"],
                         ro["block_plain"]["n"])
        self.assertEqual(set(mk), {"sub", "pos_num", "pos_other", "cut"})
        for key in ("cf11", "cf1", "block_plain", "same"):
            self.assertEqual(ro[key]["cut"], 0, key)                            # max_len 512: nothing cut
        for key in ("cf11", "cf1"):
            self.assertEqual(set(ro[key]), {"n", "acc", "decoy", "ratio", "cut"})
        self.assertEqual(set(ro["block_plain"]), {"n", "gold", "cf", "decoy", "cut"})
        self.assertGreater(ro["views"], 0)


@unittest.skipUnless(HAVE, "needs torch + transformers")
class TestFSDPWorld1(unittest.TestCase):
    """The cluster path on the CPU: FSDP2 (gloo, world 1), both passes inside Readout.run, the slice write on an FSDP
    layer with non-reentrant checkpointing, one ShardedOptim step."""

    @classmethod
    def setUpClass(cls):
        try:
            cls.tok = gpt2_tok()
        except Exception as e:
            raise unittest.SkipTest(f"no local gpt2 tokenizer: {e}")
        import torch.distributed as dist
        if dist.is_initialized():
            raise unittest.SkipTest("a process group is already up")
        os.environ.update(RANK="0", WORLD_SIZE="1", LOCAL_RANK="0", MASTER_ADDR="127.0.0.1",
                          MASTER_PORT=str(29300 + os.getpid() % 300))
        from cotdistill import fsdp as fsdp_lib
        cls.fs = fsdp_lib.init(timeout_min=2.0)
        cls.items = items8()
        cls.by = {it["item_id"]: it for it in cls.items}

    @classmethod
    def tearDownClass(cls):
        import torch.distributed as dist
        if dist.is_initialized():
            dist.destroy_process_group()

    def test_two_passes_inside_root(self):
        from cotdistill import fsdp as fsdp_lib
        from cotdistill.fsdp import ShardedOptim, _local
        spec = B3Spec("fsiit", layer=2, dim=8, seed=1)
        model = tiny_qwen35(len(self.tok))
        model.config.use_cache = False
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
        fr = Frontier(model, spec)
        root = fsdp_lib.shard_model(model, self.fs.mesh)
        root.train()
        table = build_table(self.items, spec)
        views = [make_example(it, table[it["item_id"]], table, spec, self.by)[0] for it in self.items[:4]]
        batch = finals(self.items[4:6]) + views
        params = [p for p in root.parameters() if p.requires_grad]
        tr = ShardedOptim(params, "cpu-adamw", 1e-3, self.fs.device)
        z, st = fr.call(root, self.tok, batch, 512, {})
        self.assertEqual(st["modes"]["full"][0], 4)
        loss = kl_loss(z, batch) * len(batch) / len(batch)
        loss.backward()
        self.assertTrue(all(p.grad is not None for p in params))
        before = {id(p): _local(p).detach().clone() for p in params}
        tr.clip_grad_norm_(1.0)
        tr.step()
        tr.zero_grad()
        moved = max((_local(p).detach() - before[id(p)]).abs().max().item() for p in params)
        self.assertGreater(moved, 1e-4)
        self.assertTrue(all(lay.gradient_checkpointing for lay in fr.dl))   # restored after the write context
        n0 = fr.src_forwards                                                # --fsdp: a plain micro-batch still runs
        with torch.no_grad():                                               # the dummy source pass (same collectives)
            _, st0 = fr.call(root, self.tok, finals(self.items[:2]), 512, {})
        self.assertEqual((fr.src_forwards - n0, fr.src_dummy, st0["n_src"]), (0, 1, 0))   # fix 2 item 7
        self.assertGreater(fr.src_forwards, 0)                              # the real source pass of the views above
        tr.release()

    def test_source_grad_inside_root(self):
        """--b3-source-grad on the cluster path (card v2 option (a)): inside Readout.run with non-reentrant
        checkpointing, the source pass stays in the graph: the embedding rows only the source text holds get the same
        gradient as on the plain model (nonzero), and every gradient equals the plain model's."""
        from cotdistill import fsdp as fsdp_lib
        from cotdistill.fsdp import _local
        from test_frontier_v2 import source_only_view
        spec = B3Spec("fsiit", layer=2, dim=8, seed=1, source_grad=True)
        table = build_table(self.items, spec)
        v = source_only_view(self.tok, self.items, self.by, table, spec)
        batch = [v] + [make_example(it, table[it["item_id"]], table, spec, self.by)[0] for it in self.items[1:4]]
        recv = set()
        for e in batch:
            recv |= set(self.tok(e.text)["input_ids"])
        only = sorted(set(self.tok(v.source_text)["input_ids"]) - recv)
        grads = []
        for sharded in (False, True):
            model = tiny_qwen35(len(self.tok))
            model.config.use_cache = False
            model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
            fr = Frontier(model, spec)
            root = fsdp_lib.shard_model(model, self.fs.mesh) if sharded else model
            root.train()
            z, st = fr.call(root, self.tok, batch, 512, {})
            self.assertEqual((st["cut"], st["n_src"]), (0, len({e.source_text for e in batch})))
            kl_loss(z, batch).backward()
            grads.append({n: _local(p.grad).detach().clone() for n, p in model.named_parameters() if p.grad is not None})
        plain, shard = grads
        self.assertEqual(set(plain), set(shard))
        emb = next(n for n in plain if n.endswith("embed_tokens.weight"))
        self.assertGreater(shard[emb][only].abs().sum().item(), 0.0)
        for n in plain:
            self.assertTrue(torch.allclose(plain[n], shard[n], atol=1e-5, rtol=1e-4), n)
        # a plain-only micro-batch in training: the dummy source pass (under enable_grad, its graph unused) then the
        # backward, then a micro-batch with views on the same root: FSDP2's state is not stuck, gradients accumulate
        model.zero_grad(set_to_none=True)
        n0 = fr.src_dummy
        z0, st0 = fr.call(root, self.tok, finals(self.items[:2]), 512, {})
        kl_loss(z0, finals(self.items[:2])).backward()
        self.assertEqual((fr.src_dummy - n0, st0["n_src"]), (1, 0))
        g0 = {n: _local(p.grad).detach().clone() for n, p in model.named_parameters() if p.grad is not None}
        self.assertTrue(g0)
        z, st = fr.call(root, self.tok, batch, 512, {})
        kl_loss(z, batch).backward()
        g1 = {n: _local(p.grad).detach() for n, p in model.named_parameters() if p.grad is not None}
        self.assertGreater(g1[emb][only].abs().sum().item(), 0.0)
        for n in plain:                                         # accumulated: the plain batch's + the view batch's
            self.assertTrue(torch.allclose(g1[n], g0.get(n, 0) + plain[n], atol=1e-5, rtol=1e-4), n)


@unittest.skipUnless(HAVE, "needs torch + transformers")
class TestTrainerSmoke(unittest.TestCase):
    """train_student.py end to end per arm (CPU, tiny Qwen3.5 + GPT-2 tokenizer): the banner, the history columns, the
    metrics "b3" block with its table counts, draws, training totals and readout; flag validation; the flag-off path
    byte-identical to the reference checkout (COTD_REF_REPO, meant to be src_df/repo)."""

    @classmethod
    def setUpClass(cls):
        try:
            cls.tok = gpt2_tok()
        except Exception as e:
            raise unittest.SkipTest(f"no local gpt2 tokenizer: {e}")

    def fixture(self, d: str) -> None:
        tiny_qwen35(len(self.tok)).save_pretrained(d + "/m")
        self.tok.save_pretrained(d + "/m")
        items = items8() + [dict(diamond(8, 11, 5, 2, 3), item_id="n0", worked_steps=None)]
        Path(d + "/t.jsonl").write_text("\n".join(json.dumps(x) for x in items) + "\n")

    def run_train(self, d, out, *extra, script=TRAIN):
        r = subprocess.run([sys.executable, script, "--model", d + "/m", "--train", d + "/t.jsonl",
                            "--eval", "val=" + d + "/t.jsonl", "--final", "teacher", "--subq", "none", "--epochs", "3",
                            "--micro-bs", "3", "--grad-accum", "3", "--max-len", "512", "--eval-max-len", "512",
                            "--precision", "fp32master", "--lr", "1e-3", "--log-every", "1", "--seed", "1", "--out", out,
                            *extra], capture_output=True, text=True, timeout=1500, env=ENV)
        self.assertEqual(r.returncode, 0, r.stderr[-4000:])
        return r, json.loads(Path(out + "/metrics.json").read_text())

    def test_arms(self):
        with tempfile.TemporaryDirectory() as d:
            self.fixture(d)
            for arm in ("fsiit", "ssiit", "sham", "cfaug"):
                r, m = self.run_train(d, d + "/" + arm, "--b3-arm", arm, "--b3-layer", "2", "--b3-dim", "8", "--b3-p", "1.0")
                self.assertIn(f"frontier interchange: arm {arm}, layer 2 (output), 8 dims per node", r.stdout)
                self.assertIn("items with steps usable", r.stdout)
                b3 = m["b3"]
                self.assertEqual((b3["arm"], b3["layer"], b3["dim"], b3["p"]), (arm, 2, 8, 1.0))
                self.assertEqual(b3["table"]["usable"], 8)
                self.assertGreater(sum(v for k, v in b3["draws"].items() if k in ("full", "single", "sham", "cfaug", "strict")), 0)
                mode = {"fsiit": "full", "ssiit": "single", "sham": "sham", "cfaug": "cfaug"}[arm]
                self.assertIn(f"b3_{mode}_n", b3["train"], b3["train"])
                # the draws exclude the counting pass and agree with what the forward counted (one forward per view
                # per epoch): p = 1.0, 8 usable items, 3 epochs
                drawn = sum(v for k, v in b3["draws"].items() if k in ("full", "single", "sham", "cfaug", "strict"))
                forwarded = sum(v for k, v in b3["train"].items() if k.endswith("_n") and k != "b3_plain_n")
                self.assertEqual(drawn, forwarded, (b3["draws"], b3["train"]))
                if arm in ("fsiit", "sham"):                             # every usable item, every epoch, less no_decoy
                    self.assertEqual(drawn + b3["draws"].get("no_view", 0), 24, b3["draws"])
                    self.assertEqual(b3["draws"].get("no_view", 0), b3["draws"].get("no_decoy", 0), b3["draws"])
                    self.assertEqual(sum(b3["draws"]["k_hist"].values()), drawn)
                    self.assertGreater(b3["draws"].get("strict", 0), 0)  # strict share 0.5
                # the plain column (item 5): the plain examples of the receiver pass, logged per row and in total
                self.assertEqual(b3["train"]["plain"]["n"], b3["train"]["b3_plain_n"])
                self.assertEqual(b3["train"]["plain"]["n"], 3 * 9 - drawn)
                self.assertIn("b3_plain_ce", m["history"][-1])
                self.assertIn("b3_plain_acc", m["history"][-1])
                self.assertEqual(b3["table"]["excluded"]["shared_token"], 1)   # d1 at k = 2 (3 is a and d)
                # n0 (no steps) stays plain each epoch; ssiit also leaves items without a clean single-node
                # counterfactual plain (no_view)
                self.assertEqual(b3["draws"].get("plain", 0), 3 + b3["draws"].get("no_view", 0), b3["draws"])
                self.assertIn(f"b3_{mode}_ce", m["history"][-1], m["history"][-1])
                self.assertEqual(len(m["history"]), 3)                        # 3 epochs x 9 items / 9 per update
                ro = b3["readout"]["val"]
                self.assertIn("cf11", ro)
                self.assertIn("misaligned_keep", ro)
                self.assertIn("decoy", ro["cf11"])
                self.assertGreater(ro["views"], 0)
                if arm != "cfaug":
                    self.assertGreater(b3["train"]["b3_src_fwd"], 0)
                else:
                    self.assertEqual(b3["train"]["b3_src_fwd"], 0)
                    self.assertEqual(b3["timing"]["source_forwards"], 0)   # item 6: CF-AUG runs no source forward
                self.assertGreaterEqual(b3["timing"]["source_pass_s"], 0.0)
                self.assertIn("val", b3["timing"]["readout_s"])
                self.assertIn("b3 timing: source pass", r.stdout)
                self.assertIn("val", m["eval"])

    def test_a2_unchanged_against_reference(self):
        ref = os.environ.get("COTD_REF_REPO")
        if not ref or not Path(ref, "scripts/train_student.py").exists():
            raise unittest.SkipTest("set COTD_REF_REPO to the reference checkout (src_df/repo)")
        with tempfile.TemporaryDirectory() as d:
            self.fixture(d)
            _, new = self.run_train(d, d + "/new", "--no-grad-ckpt")
            _, old = self.run_train(d, d + "/old", "--no-grad-ckpt", script=str(Path(ref, "scripts/train_student.py")))
            self.assertEqual([r["loss"] for r in new["history"]], [r["loss"] for r in old["history"]])
            self.assertEqual(new["eval"]["val"], old["eval"]["val"])
            self.assertNotIn("b3", new)

    def test_flag_validation(self):
        with tempfile.TemporaryDirectory() as d:
            self.fixture(d)
            for extra, msg in ((["--b3-layer", "3"], "need --b3-arm"),
                               (["--b3-arm", "fsiit", "--b3-layer", "7"], "0..6"),
                               (["--b3-arm", "fsiit", "--b3-layer", "2", "--b3-dim", "40"], "exceed the hidden size"),
                               (["--b3-arm", "fsiit", "--df-layers", "1"], "--df-layers"),
                               (["--b3-arm", "fsiit", "--loop-layers", "2-3"], "--loop-layers"),
                               (["--b3-arm", "fsiit", "--chat-template"], "--chat-template"),
                               (["--b3-arm", "fsiit", "--subq", "cot"], "--subq none"),
                               (["--b3-arm", "fsiit", "--b3-p", "2"], "0 <= --b3-p <= 1"),
                               (["--b3-arm", "x"], "invalid choice")):
                r = subprocess.run([sys.executable, TRAIN, "--model", d + "/m", "--train", d + "/t.jsonl",
                                    "--epochs", "1", "--out", d + "/o", *extra], capture_output=True, text=True,
                                   timeout=900, env=ENV)
                self.assertNotEqual(r.returncode, 0, extra)
                self.assertIn(msg, r.stderr, extra)


if __name__ == "__main__":
    unittest.main()
