"""Frontier interchange with a learned subspace (card B3 v2 option (b), --b3-rotate): frontier.rotation (Q, 2d x H,
orthonormal rows, init = the coordinate axes), the rotated write in _SliceWrite, Q's optimizer group (rotation_groups,
fsdp.ShardCPUAdamW on_device) and the trainer seams. CPU, the tiny random Qwen3.5 text model (8 layers, hidden 64) with
the GPT-2 tokenizer, as tests/test_frontier_train.py. Checks: Q is the coordinate slice at init and stays orthonormal
under AdamW; at init the rotated write equals the v1 slice write bit for bit (aligned, strict 'pos' and 'sub') and so do
the logits; a perturbed Q writes h - Qs^T Qs h + Qs^T Q0 h_s at the node tokens and nothing else; Q gets a nonzero
gradient with the source detached; the readout runs the rotated write; FSDP2 at world 1: Q outside the model, its own
group in ShardCPUAdamW, scheduled, stepped, zeroed; the trainer end to end, single process and under torchrun --fsdp
cpu-adamw (history columns, b3_rotation.pth, an lr of 1e-30 reproduces the rotate-off losses, two ranks refused);
rotate off = the frozen v1 trainer (COTD_B3V1_REPO); flag validation."""
import json
import math
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "tests"))

try:
    import torch
    import transformers  # noqa: F401
    from cotdistill.frontier import (ROT_FILE, B3Example, B3Spec, Frontier, SLOT_SPARE, _SliceWrite, build_table,
                                     make_example, rotation, rotation_groups, strict_example)
    from cotdistill.depth_forcing import _Capture, token_at
    from cotdistill.student import Example, collate, kl_loss, text_parts
    from test_depth_forcing import gpt2_tok, tiny_qwen35
    from test_frontier_train import ENV, TRAIN, diamond, finals, items8
    HAVE = True
except ImportError:
    HAVE = False


def perturb(fr, scale: float = 0.3, seed: int = 5) -> None:
    """Q away from its init: random reflector entries off the diagonal (the diagonal keeps its signs)."""
    p = fr.rot_params()[0]
    noise = torch.randn(p.shape, generator=torch.Generator().manual_seed(seed))
    noise.diagonal().zero_()
    with torch.no_grad():
        p.add_(scale * noise)


def capture_written(fr, model, tok, batch, L):
    """(letter logits, layer L's output as layer L + 1 reads it in the receiver pass: the second fire)."""
    fires = []
    hd = fr.dl[L + 1].register_forward_pre_hook(
        lambda m, a, k: fires.append((a[0] if a else k["hidden_states"]).detach().clone()), with_kwargs=True)
    try:
        with torch.no_grad():
            z, st = fr.forward(model, tok, batch, 512, {})
    finally:
        hd.remove()
    return z, fires[-1], st


@unittest.skipUnless(HAVE, "needs torch + transformers")
class TestRotation(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            cls.tok = gpt2_tok()
        except Exception as e:
            raise unittest.SkipTest(f"no local gpt2 tokenizer: {e}")
        cls.items = items8()
        cls.by = {it["item_id"]: it for it in cls.items}

    def pair(self, seed=0, **kw):
        """The same random model twice (rotate off, rotate on) with the same spec otherwise."""
        out = []
        for rot in (False, True):
            model = tiny_qwen35(len(self.tok), seed)
            model.config.use_cache = False
            model.eval()
            spec = B3Spec("fsiit", layer=2, dim=8, seed=1, rotate=rot, **kw)
            out.append((model, Frontier(model, spec), spec))
        return out

    def batch(self, spec):
        """2 plain finals, the full views and strict views of both variants ('pos' and 'sub', a few epochs' coins)."""
        table = build_table(self.items, spec)
        views = [make_example(it, table[it["item_id"]], table, spec, self.by)[0] for it in self.items]
        strict = []
        for ep in range(4):
            for it in self.items:
                r = strict_example(it, table[it["item_id"]], table, spec, self.by, epoch=ep)
                if r is not None:
                    strict.append(r[0])
        self.assertEqual({e.variant for e in strict}, {"pos_num", "sub"})
        return finals(self.items[:2]) + views[:4] + strict[:6]

    def test_rotation_init_and_orthonormal(self):
        m = rotation(16, 64)
        self.assertTrue(torch.equal(m.weight, torch.eye(16, 64)))           # the coordinate axes, exactly
        self.assertEqual([p.dtype for p in m.parameters()], [torch.float32])
        self.assertEqual(sum(p.numel() for p in m.parameters()), 16 * 64)    # no H x H base, one reflector matrix
        self.assertEqual([n for n, _ in m.named_buffers()], [])
        st = torch.get_rng_state()
        rotation(16, 64)
        self.assertTrue(torch.equal(st, torch.get_rng_state()))              # the torch RNG is not touched
        w = torch.nn.Parameter(torch.randn(4, 64))
        groups = rotation_groups([w], list(m.parameters()), 1e-2)
        self.assertEqual((groups[1]["lr"], groups[1]["weight_decay"], groups[1]["on_device"]), (1e-2, 0.0, True))
        opt = torch.optim.AdamW(groups, lr=1e-3)                             # default weight decay 0.01 on the base
        x = torch.randn(32, 64)
        for _ in range(25):
            loss = ((m.weight @ x.T) ** 3).sum() + (w ** 2).sum()
            opt.zero_grad()
            loss.backward()
            opt.step()
        Q = m.weight.detach()
        self.assertLess(float((Q @ Q.T - torch.eye(16)).abs().max()), 1e-5)
        self.assertGreater(float((Q - torch.eye(16, 64)).norm()), 0.05)     # it moved
        # the pitfall rotation_groups guards against: weight decay on the reflectors zeroes rows (.int() of the diagonal)
        m2 = rotation(16, 64)
        bad = torch.optim.AdamW(m2.parameters(), lr=1e-2, weight_decay=0.1)
        m2.weight.sum().backward()
        bad.step()
        Q2 = m2.weight.detach()
        self.assertGreater(float((Q2 @ Q2.T - torch.eye(16)).abs().max()), 0.5)

    def test_init_write_equals_v1(self):
        (m0, f0, s0), (m1, f1, s1) = self.pair()
        batch = self.batch(s0)
        z0, w0, st0 = capture_written(f0, m0, self.tok, batch, s0.layer)
        z1, w1, st1 = capture_written(f1, m1, self.tok, batch, s1.layer)
        self.assertTrue(torch.equal(w0, w1))                                 # bit for bit, every token and dimension
        for a, b in zip(z0, z1):
            self.assertTrue(torch.equal(a, b))
        self.assertEqual(st0["modes"], st1["modes"])
        self.assertEqual(st0["cut"], 0)
        self.assertGreater(st0["modes"]["strict"][0], 0)
        self.assertTrue(any(isinstance(e, B3Example) and any(n[2] == SLOT_SPARE for n in e.nodes) for e in batch))
        # with the gradient on (training mode, the hook's fp32 path in the graph) the loss is the same too
        for m in (m0, m1):
            m.train()
        l0 = kl_loss(f0.forward(m0, self.tok, batch, 512, {})[0], batch)
        l1 = kl_loss(f1.forward(m1, self.tok, batch, 512, {})[0], batch)
        self.assertEqual(float(l0), float(l1))

    def test_perturbed_write_formula(self):
        """Q away from the axes: at each node token h <- h - Qs^T Qs h + Qs^T Q0 h_s (h_s the source's full state);
        every other token unchanged; the write leaves Q's orthogonal complement of the block untouched."""
        _, (model, fr, spec) = self.pair()
        perturb(fr)
        Q = fr.rot.weight.detach()
        self.assertGreater(float((Q - torch.eye(16, 64)).norm()), 0.5)
        L, d = spec.layer, spec.dim
        batch = self.batch(spec)
        _, written, st = capture_written(fr, model, self.tok, batch, L)
        self.assertEqual(st["cut"], 0)
        body = text_parts(model)[0]
        b = collate(self.tok, batch, 512, "cpu")
        with torch.no_grad(), _Capture(fr.dl, (L,)) as cap0:
            body(input_ids=b["input_ids"], attention_mask=b["attention_mask"], use_cache=False)
        plain = cap0.h[L]
        srcs = []
        for e in batch:
            if isinstance(e, B3Example) and e.nodes and e.source_text not in srcs:
                srcs.append(e.source_text)
        sb = collate(self.tok, [Example(t, ["A"], [1.0], 1.0, "final", "s") for t in srcs], 512, "cpu")
        with torch.no_grad(), _Capture(fr.dl, (L,)) as caps:
            body(input_ids=sb["input_ids"], attention_mask=sb["attention_mask"], use_cache=False)
        src = caps.h[L]
        touched = torch.zeros(plain.shape[:2], dtype=torch.bool)
        n = 0
        for i, e in enumerate(batch):
            if not isinstance(e, B3Example):
                continue
            for r_end, s_end, slot in e.nodes:
                rp, sp = token_at(self.tok, e.text, r_end, 512), token_at(self.tok, e.source_text, s_end, 512)
                qs, q0 = Q[slot * d:(slot + 1) * d], Q[:d]
                hr, hs = plain[i, rp], src[srcs.index(e.source_text), sp]
                want = hr - qs.T @ (qs @ hr) + qs.T @ (q0 @ hs)
                self.assertTrue(torch.allclose(written[i, rp], want, atol=1e-5, rtol=1e-5), (i, rp, slot))
                self.assertTrue(torch.allclose(qs @ written[i, rp], q0 @ hs, atol=1e-5))   # the block holds Q0 h_s
                touched[i, rp] = True
                n += 1
        self.assertGreater(n, 0)
        self.assertTrue(torch.equal(written[~touched], plain[~touched]))
        self.assertFalse(torch.equal(written[touched][:, 2 * d:], plain[touched][:, 2 * d:]))   # no longer a slice

    def test_q_gradient_with_source_detached(self):
        for perturbed in (False, True):
            _, (model, fr, spec) = self.pair()
            model.train()
            if perturbed:
                perturb(fr)
            table = build_table(self.items, spec)
            views = [make_example(it, table[it["item_id"]], table, spec, self.by)[0] for it in self.items[:4]]
            seen = []
            orig = _SliceWrite.__enter__

            def spy(self_):
                seen.append((self_.rot is not None, [v.requires_grad for *_, v in self_.writes]))
                return orig(self_)
            _SliceWrite.__enter__ = spy
            try:
                z, _ = fr.forward(model, self.tok, views, 512, {})
            finally:
                _SliceWrite.__enter__ = orig
            self.assertTrue(seen and seen[0][0])
            self.assertTrue(seen[0][1] and not any(seen[0][1]))              # the source vectors are detached
            model.zero_grad(set_to_none=True)
            kl_loss(z, views).backward()
            g = fr.rot_params()[0].grad
            self.assertIsNotNone(g)
            self.assertGreater(float(g.abs().sum()), 0.0, perturbed)
            self.assertEqual(float(g.diagonal().abs().sum()), 0.0)          # the diagonal is read only by its sign
            self.assertTrue(torch.isfinite(g).all())

    def test_readout_uses_q(self):
        (m0, f0, _), (m1, f1, _) = self.pair()
        r0 = f0.readout(m0, self.tok, self.items, [], 512, 4, {})
        rots = []
        orig = _SliceWrite.__enter__

        def spy(self_):
            rots.append(self_.rot)
            return orig(self_)
        _SliceWrite.__enter__ = spy
        try:
            r1 = f1.readout(m1, self.tok, self.items, [], 512, 4, {})
        finally:
            _SliceWrite.__enter__ = orig
        self.assertTrue(rots and all(r is not None for r in rots))
        self.assertEqual(r0, r1)                                             # init: the v1 readout exactly
        # the readout's written views see Q: a perturbed Q changes their letter logits
        perturb(f1, scale=2.0)
        table = build_table(self.items, f1.spec)
        views = [make_example(it, table[it["item_id"]], table, f1.spec, self.by)[0] for it in self.items[:4]]
        with torch.no_grad():
            za = f0.call(m0, self.tok, views, 512, {})[0]
            zb = f1.call(m1, self.tok, views, 512, {})[0]
        self.assertFalse(all(torch.equal(a, b) for a, b in zip(za, zb)))

    def test_spec(self):
        self.assertEqual(B3Spec("fsiit").as_dict()["rotate"], False)
        self.assertIsNone(B3Spec("fsiit").as_dict()["rotate_lr"])
        self.assertEqual(B3Spec("fsiit", rotate=True, rotate_lr=1e-3).as_dict()["rotate_lr"], 1e-3)
        model = tiny_qwen35(len(self.tok))
        for kw in ({"rotate_lr": 1e-3}, {"rotate": True, "rotate_lr": 0.0}):
            with self.assertRaises(ValueError):
                Frontier(model, B3Spec("fsiit", layer=2, dim=8, **kw))
        self.assertIsNone(Frontier(model, B3Spec("fsiit", layer=2, dim=8)).rot)
        self.assertEqual(Frontier(model, B3Spec("fsiit", layer=2, dim=8)).rot_params(), [])
        fr = Frontier(model, B3Spec("fsiit", layer=2, dim=8, rotate=True))
        self.assertEqual(tuple(fr.rot.weight.shape), (16, 64))
        self.assertEqual(fr.rot_stats()["b3_rot_dev"], 0.0)
        with tempfile.TemporaryDirectory() as d:
            perturb(fr)
            fr.save_rotation(Path(d) / ROT_FILE)
            blob = torch.load(Path(d) / ROT_FILE, weights_only=False)
            self.assertTrue(torch.equal(blob["Q"], fr.rot.weight.detach()))
            m = rotation(16, 64)
            m.load_state_dict(blob["state_dict"])                            # rebuilds the same Q
            self.assertTrue(torch.equal(m.weight.detach(), blob["Q"]))
            self.assertEqual((blob["dim"], blob["hidden"], blob["layer"]), (8, 64, 2))


@unittest.skipUnless(HAVE, "needs torch + transformers")
class TestRotationFSDPWorld1(unittest.TestCase):
    """The cluster path on the CPU: FSDP2 (gloo, world 1), Q outside the sharded model, ShardedOptim cpu-adamw with Q's
    on_device group: gradient inside Readout.run, Q's own clip, the scheduler, the step, zero_grad."""

    @classmethod
    def setUpClass(cls):
        try:
            cls.tok = gpt2_tok()
        except Exception as e:
            raise unittest.SkipTest(f"no local gpt2 tokenizer: {e}")
        import torch.distributed as dist
        if dist.is_initialized():
            raise unittest.SkipTest("a process group is already up")
        os.environ.update(RANK="0", WORLD_SIZE="1", LOCAL_RANK="0", MASTER_ADDR="127.0.0.1",
                          MASTER_PORT=str(29700 + os.getpid() % 200))
        from cotdistill import fsdp as fsdp_lib
        cls.fs = fsdp_lib.init(timeout_min=2.0)
        cls.items = items8()
        cls.by = {it["item_id"]: it for it in cls.items}

    @classmethod
    def tearDownClass(cls):
        import torch.distributed as dist
        if dist.is_initialized():
            dist.destroy_process_group()

    def test_q_in_its_own_group(self):
        from cotdistill import fsdp as fsdp_lib
        from cotdistill.fsdp import ShardCPUAdamW, ShardedOptim, _local
        spec = B3Spec("fsiit", layer=2, dim=8, seed=1, rotate=True, rotate_lr=1e-2)
        model = tiny_qwen35(len(self.tok))
        model.config.use_cache = False
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
        fr = Frontier(model, spec)
        root = fsdp_lib.shard_model(model, self.fs.mesh)
        fr.place(self.fs.device)
        root.train()
        params = [p for p in root.parameters() if p.requires_grad]
        rot = fr.rot_params()
        self.assertFalse({id(p) for p in rot} & {id(p) for p in params})     # Q is not an FSDP parameter
        self.assertFalse(any(hasattr(p, "to_local") for p in rot))
        tr = ShardedOptim(params, "cpu-adamw", 1e-3, self.fs.device, groups=rotation_groups(params, rot, 1e-2))
        self.assertEqual([id(p) for p in tr.extra], [id(p) for p in rot])
        self.assertIsNotNone(tr.opt.dev_opt)
        self.assertEqual(len(tr.opt.master), len(params))                   # no CPU master for Q
        sched = torch.optim.lr_scheduler.LambdaLR(tr.opt, lambda s: 0.5)
        self.assertEqual([g["lr"] for g in tr.opt.param_groups], [5e-4, 5e-3])   # same shape, own rate
        table = build_table(self.items, spec)
        views = [make_example(it, table[it["item_id"]], table, spec, self.by)[0] for it in self.items[:4]]
        batch = finals(self.items[4:6]) + views
        z, st = fr.call(root, self.tok, batch, 512, {})
        self.assertEqual(st["modes"]["full"][0], 4)
        kl_loss(z, batch).backward()
        self.assertTrue(all(p.grad is not None for p in params))
        self.assertGreater(float(rot[0].grad.abs().sum()), 0.0)              # Q's gradient through the root's forward
        q_before = fr.rot.weight.detach().clone()
        before = {id(p): _local(p).detach().clone() for p in params}
        torch.nn.utils.clip_grad_norm_(rot, 1.0)                             # the trainer's rot_clip
        tr.clip_grad_norm_(1.0)
        tr.step()
        tr.zero_grad()
        self.assertIsNone(rot[0].grad)                                       # zeroed with the model
        moved = max((_local(p).detach() - before[id(p)]).abs().max().item() for p in params)
        self.assertGreater(moved, 1e-5)
        Q = fr.rot.weight.detach()
        self.assertGreater(float((Q - q_before).abs().max()), 1e-4)          # Q stepped (fp32, on its device)
        self.assertLess(float((Q @ Q.T - torch.eye(16)).abs().max()), 1e-5)
        self.assertEqual(tr.opt.dev_opt.param_groups[0]["lr"], 5e-3)         # synced from the scheduled outer group
        sched.step()
        tr.reset_state()
        self.assertEqual(len(tr.opt.dev_opt.state), 0)
        tr.release()
        # why Q needs its own group: in a plain group ShardCPUAdamW refuses an fp32 tensor next to bf16 shards
        with self.assertRaises(ValueError):
            ShardCPUAdamW([torch.nn.Parameter(torch.zeros(4, dtype=torch.bfloat16)), torch.nn.Parameter(torch.zeros(4))])


@unittest.skipUnless(HAVE, "needs torch + transformers")
class TestRotationTrainer(unittest.TestCase):
    """train_student.py --b3-rotate end to end (CPU, tiny Qwen3.5 + GPT-2 tokenizer)."""

    @classmethod
    def setUpClass(cls):
        try:
            cls.tok = gpt2_tok()
        except Exception as e:
            raise unittest.SkipTest(f"no local gpt2 tokenizer: {e}")

    def fixture(self, d: str) -> None:
        tiny_qwen35(len(self.tok)).save_pretrained(d + "/m")
        self.tok.save_pretrained(d + "/m")
        items = items8() + [dict(diamond(8, 11, 5, 2, 3), item_id="n0", worked_steps=None)]
        Path(d + "/t.jsonl").write_text("\n".join(json.dumps(x) for x in items) + "\n")

    def run_train(self, d, out, *extra, script=TRAIN):
        r = subprocess.run([sys.executable, script, "--model", d + "/m", "--train", d + "/t.jsonl",
                            "--eval", "val=" + d + "/t.jsonl", "--final", "teacher", "--subq", "none", "--epochs", "3",
                            "--micro-bs", "3", "--grad-accum", "3", "--max-len", "512", "--eval-max-len", "512",
                            "--precision", "fp32master", "--lr", "1e-3", "--log-every", "1", "--seed", "1", "--out", out,
                            "--b3-arm", "fsiit", "--b3-layer", "2", "--b3-dim", "8", "--b3-p", "1.0", *extra],
                           capture_output=True, text=True, timeout=1500, env=ENV)
        self.assertEqual(r.returncode, 0, r.stderr[-4000:])
        return r, json.loads(Path(out + "/metrics.json").read_text())

    def test_rotate_end_to_end(self):
        with tempfile.TemporaryDirectory() as d:
            self.fixture(d)
            r, m = self.run_train(d, d + "/rot", "--b3-rotate", "--b3-rotate-lr", "1e-2")
            self.assertIn("learned subspace Q (16 x hidden, lr 0.01)", r.stdout)
            b3 = m["b3"]
            self.assertEqual((b3["rotate"], b3["rotate_lr"]), (True, 1e-2))
            h = m["history"]
            self.assertEqual(len(h), 3)
            for row in h:                                                   # Q follows the base schedule x 10
                self.assertTrue(math.isclose(row["b3_rot_lr"], 10 * row["lr"], rel_tol=1e-9), row)
                self.assertLess(row["b3_rot_orth"], 1e-5)
                self.assertIsNotNone(row["b3_rot_gnorm"])
            self.assertGreater(h[-1]["b3_rot_dev"], 0.0)
            self.assertGreaterEqual(h[-1]["b3_rot_dev"], h[-1]["b3_rot_dev_src"])
            ro = b3["rotation"]
            self.assertEqual(ro["file"], ROT_FILE)
            self.assertEqual(ro["lr"], 1e-2)
            self.assertEqual(ro["b3_rot_dev"], h[-1]["b3_rot_dev"])         # no update after the last row
            blob = torch.load(Path(d, "rot", ROT_FILE), weights_only=False)
            Q = blob["Q"]
            self.assertEqual(tuple(Q.shape), (16, 64))
            self.assertEqual(Q.dtype, torch.float32)
            self.assertLess(float((Q @ Q.T - torch.eye(16)).abs().max()), 1e-5)
            self.assertAlmostEqual(float((Q - torch.eye(16, 64)).norm()), ro["b3_rot_dev"], places=5)
            self.assertIn("val", b3["readout"])
            self.assertIn("b3 rotation", r.stdout)
            # Q pinned at its init (lr 1e-30: no representable step) = the rotate-off run: the whole plumbing (the
            # extra group, the clip, the rotated write in training and readout) adds nothing at Q = the axes
            _, m_pin = self.run_train(d, d + "/pin", "--b3-rotate", "--b3-rotate-lr", "1e-30")
            _, m_off = self.run_train(d, d + "/off")
            self.assertEqual([x["loss"] for x in m_pin["history"]], [x["loss"] for x in m_off["history"]])
            self.assertEqual(m_pin["b3"]["readout"], m_off["b3"]["readout"])
            self.assertEqual(m_pin["eval"]["val"], m_off["eval"]["val"])
            self.assertEqual(m_pin["b3"]["rotation"]["b3_rot_dev"], 0.0)
            self.assertNotIn("rotation", m_off["b3"])
            self.assertNotIn("b3_rot_dev", m_off["history"][-1])
            self.assertFalse(Path(d, "off", ROT_FILE).exists())

    def run_fsdp(self, d, out, *extra, nproc=1, ok=True):
        r = subprocess.run([sys.executable, "-m", "torch.distributed.run", "--standalone", "--local-addr", "127.0.0.1",
                            "--nproc_per_node", str(nproc), TRAIN, "--model", d + "/m", "--train", d + "/t.jsonl",
                            "--eval", "val=" + d + "/t.jsonl", "--final", "teacher", "--subq", "none", "--epochs", "2",
                            "--micro-bs", "3", "--grad-accum", "3", "--max-len", "512", "--eval-max-len", "512",
                            "--lr", "1e-3", "--log-every", "1", "--seed", "1", "--out", out, "--b3-arm", "fsiit",
                            "--b3-layer", "2", "--b3-dim", "8", "--b3-p", "1.0", "--fsdp", "--fsdp-optim", "cpu-adamw",
                            *extra], capture_output=True, text=True, timeout=1500, env={**ENV, "OMP_NUM_THREADS": "1"})
        if not ok:
            return r, None
        self.assertEqual(r.returncode, 0, r.stderr[-4000:])
        return r, json.loads(Path(out + "/metrics.json").read_text())

    def test_rotate_under_fsdp(self):
        """The job path (torchrun, --fsdp cpu-adamw, world 1): Q placed on the rank's device, stepped in its own group
        at its own scheduled lr, saved; Q pinned (lr 1e-30) = the rotate-off fsdp run; two ranks are refused."""
        with tempfile.TemporaryDirectory() as d:
            self.fixture(d)
            r, m = self.run_fsdp(d, d + "/rot", "--b3-rotate", "--b3-rotate-lr", "1e-2")
            self.assertIn("fsdp: 1 ranks", r.stdout)
            h = m["history"]
            self.assertEqual(len(h), 2)
            for row in h:
                self.assertTrue(math.isclose(row["b3_rot_lr"], 10 * row["lr"], rel_tol=1e-9), row)
                self.assertLess(row["b3_rot_orth"], 1e-5)
            self.assertGreater(h[0]["b3_rot_dev"], 0.0)
            self.assertTrue(Path(d, "rot", ROT_FILE).exists())
            _, m_pin = self.run_fsdp(d, d + "/pin", "--b3-rotate", "--b3-rotate-lr", "1e-30")
            _, m_off = self.run_fsdp(d, d + "/off")
            self.assertEqual([x["loss"] for x in m_pin["history"]], [x["loss"] for x in m_off["history"]])
            self.assertEqual([x["gnorm"] for x in m_pin["history"]], [x["gnorm"] for x in m_off["history"]])
            self.assertEqual(m_pin["b3"]["readout"], m_off["b3"]["readout"])
            r2, _ = self.run_fsdp(d, d + "/two", "--b3-rotate", nproc=2, ok=False)
            self.assertNotEqual(r2.returncode, 0)
            self.assertIn("--b3-rotate: one rank only", r2.stderr)

    def test_rotate_off_equals_v1(self):
        ref = os.environ.get("COTD_B3V1_REPO")
        if not ref or not Path(ref, "scripts/train_student.py").exists():
            raise unittest.SkipTest("set COTD_B3V1_REPO to the frozen v1 checkout (src_b3/repo.pre_v2)")
        with tempfile.TemporaryDirectory() as d:
            self.fixture(d)
            _, new = self.run_train(d, d + "/new", "--no-grad-ckpt")
            _, old = self.run_train(d, d + "/old", "--no-grad-ckpt", script=str(Path(ref, "scripts/train_student.py")))
            self.assertEqual(new["history"][0].keys() - {"s_per_step", "approx_tok_per_s"},
                             old["history"][0].keys() - {"s_per_step", "approx_tok_per_s"})
            self.assertEqual([r["loss"] for r in new["history"]], [r["loss"] for r in old["history"]])
            self.assertEqual(new["eval"]["val"], old["eval"]["val"])
            self.assertEqual(new["b3"]["readout"], old["b3"]["readout"])
            b_new = json.loads(json.dumps(new["b3"]))     # minus the v2 block-all keys (a zero blockplain mode, block_all)
            self.assertEqual(b_new.pop("block_all"), False)
            self.assertEqual(b_new["train"].pop("blockplain"), {"n": 0, "ce": None, "acc": None, "cut": 0})
            self.assertEqual(b_new["train_totals"]["modes"].pop("blockplain"), [0, 0.0, 0, 0])
            self.assertEqual(b_new["train_totals"], old["b3"]["train_totals"])
            self.assertEqual({k: v for k, v in b_new.items() if k not in ("rotate", "rotate_lr", "timing")},
                             {k: v for k, v in old["b3"].items() if k != "timing"})

    def test_flag_validation(self):
        with tempfile.TemporaryDirectory() as d:
            self.fixture(d)
            for extra, msg in ((["--b3-rotate"], "need --b3-arm"),
                               (["--b3-rotate-lr", "1e-3"], "need --b3-arm"),
                               (["--b3-arm", "fsiit", "--b3-layer", "2", "--b3-dim", "8", "--b3-rotate-lr", "1e-3"],
                                "only with --b3-rotate"),
                               (["--b3-arm", "fsiit", "--b3-layer", "2", "--b3-dim", "8", "--b3-rotate",
                                 "--b3-rotate-lr", "0"], "> 0")):
                r = subprocess.run([sys.executable, TRAIN, "--model", d + "/m", "--train", d + "/t.jsonl",
                                    "--epochs", "1", "--out", d + "/o", *extra], capture_output=True, text=True,
                                   timeout=900, env=ENV)
                self.assertNotEqual(r.returncode, 0, extra)
                self.assertIn(msg, r.stderr, extra)


if __name__ == "__main__":
    unittest.main()
