"""Frontier interchange v2 (card CARD_b3_v2 sections 1 and 4): --b3-block-all and the source-gradient path. Checks:
flag off, every arm's substitution is byte-identical to the v1 snapshot (src_b3/repo.pre_v2, COTD_B3_REF_REPO) over two
epochs of the real training data, and so is the trainer's metrics block on the tiny fixture; flag on, no item with a
valid view keeps its original block in any arm, the blockplain view is the epoch's intervened block with the gold
label, S-SIIT uses its single-node block and SHAM / CF-AUG use F-SIIT's; over one epoch of the real data (F-SIIT, p 0.5,
strict share 0.25, seed 16) the label shares on blocks with foreign values equal b3_data_stats_v2.json's; the forward
logs blockplain in its own column; --b3-source-grad puts a nonzero gradient on the embedding row of a token that only
the source text holds (zero without the flag), under no checkpointing and both checkpoint modes."""
import collections
import json
import os
import subprocess
import sys
import tempfile
import unittest
from dataclasses import asdict, replace
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "tests"))

from cotdistill.frontier import (B3Example, B3Spec, LETTERS, N_OPTIONS, B3Window, build_table, canon_value,  # noqa: E402
                                 gold_value, make_example, parse_options, substitute)
from cotdistill.depth_forcing import canon_number  # noqa: E402
from cotdistill.student import Example  # noqa: E402

DATA = ROOT / "data/student_gsm8k_tf_vt/train.jsonl"
REF = Path(os.environ.get("COTD_B3_REF_REPO", str(ROOT.parent / "repo.pre_v2")))
STATS = Path(os.environ.get("COTD_B3_STATS_V2", str(ROOT.parent / "b3_data_stats_v2.json")))
ENV = {**os.environ, "CUDA_VISIBLE_DEVICES": "", "OMP_NUM_THREADS": "2"}
TRAIN = str(ROOT / "scripts/train_student.py")
ARMS = ("fsiit", "ssiit", "sham", "cfaug")

# One process per checkout: every arm's substitution over the real data, two specs x two epochs, one sha256 per
# (spec, arm, epoch) over the examples (type, every field) and the counts. B3Spec is built without block_all, so the
# script runs on the v1 snapshot unchanged.
DUMP = r'''
import hashlib, json, sys
from dataclasses import asdict
sys.path.insert(0, sys.argv[1])
from cotdistill.frontier import B3Spec, build_table, substitute
from cotdistill.student import Example
items = [json.loads(l) for l in open(sys.argv[2]) if l.strip()]
by = {it["item_id"]: it for it in items}
out = {}
for seed, p, share in ((16, 0.5, 0.25), (1, 1.0, 0.5)):
    t = build_table(items, B3Spec("fsiit", seed=seed))
    for arm in ("fsiit", "ssiit", "sham", "cfaug"):
        sp = B3Spec(arm, seed=seed, p=p, strict_share=share)
        for ep in (0, 1):
            h, counts = hashlib.sha256(), {}
            for it in items:
                fin = [Example(it["prompt"], list(it["labels"]), [it["teacher"][L] for L in it["labels"]], 1.0, "final",
                               it["item_id"], it["labels"].index(it["gold_label"]))]
                for e in substitute(fin, it, t.get(it["item_id"]), t, sp, by, ep, counts):
                    h.update(repr((type(e).__name__, sorted(asdict(e).items()))).encode())
            h.update(json.dumps(counts).encode())        # key order included (metrics' draws keep insertion order)
            out[f"{seed}|{p}|{share}|{arm}|{ep}"] = h.hexdigest()
print(json.dumps(out))
'''


def load_items() -> list:
    return [json.loads(l) for l in open(DATA) if l.strip()]


def plain_final(it: dict) -> Example:
    """The trainer's plain final example of a gsmvt item (build_examples with --final teacher): the teacher target."""
    return Example(it["prompt"], list(it["labels"]), [it["teacher"][L] for L in it["labels"]], 1.0, "final",
                   it["item_id"], it["labels"].index(it["gold_label"]))


def role(e) -> str | None:
    """The label's role in a block with foreign values (None: no such block): gold, cf (cf(S)), decoy (cf(S')), own
    (R's own distractor or a filler)."""
    if not isinstance(e, B3Example) or e.cf_s < 0:
        return None
    return ("gold" if e.cf_gold == e.orig_gold else "cf" if e.cf_gold == e.cf_s else
            "decoy" if e.cf_gold == e.decoy else "own")


@unittest.skipUnless(DATA.exists(), "needs data/student_gsm8k_tf_vt/train.jsonl")
class TestBlockAllRealData(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.items = load_items()
        cls.by = {it["item_id"]: it for it in cls.items}
        cls.table = build_table(cls.items, B3Spec("fsiit", seed=16))

    def draw(self, spec: B3Spec, epoch: int = 0):
        counts: dict = {}
        out = [substitute([plain_final(it)], it, self.table.get(it["item_id"]), self.table, spec, self.by, epoch,
                          counts)[-1] for it in self.items]
        return out, counts

    def test_flag_off_byte_identical_to_v1(self):
        if not (REF / "src/cotdistill/frontier.py").exists():
            raise unittest.SkipTest(f"no v1 snapshot at {REF} (COTD_B3_REF_REPO)")
        res = {}
        for name, src in (("v1", REF / "src"), ("v2", ROOT / "src")):
            r = subprocess.run([sys.executable, "-c", DUMP, str(src), str(DATA)], capture_output=True, text=True,
                               timeout=900, env=ENV)
            self.assertEqual(r.returncode, 0, r.stderr[-3000:])
            res[name] = json.loads(r.stdout.strip().splitlines()[-1])
        self.assertEqual(len(res["v1"]), 16)
        self.assertEqual(res["v1"], res["v2"])

    def test_no_original_block_for_items_with_a_view(self):
        """Flag on, every arm, two epochs: an item whose arm has a view this epoch (CF-AUG: F-SIIT's view) never keeps
        its original block; one without keeps its original example unchanged. The blockplain view is that view's block
        (text identical), label the gold, one-hot target, the plain weight, no write; S-SIIT's is its single-node block
        (differs from F-SIIT's somewhere), SHAM's and CF-AUG's equal F-SIIT's."""
        blocks = {}
        for arm in ARMS:
            for ep in (0, 1):
                spec = B3Spec(arm, seed=16, p=0.5, strict_share=0.25, block_all=True)
                view_spec = spec if arm in ("fsiit", "ssiit") else replace(spec, arm="fsiit")
                out, counts = self.draw(spec, ep)
                n_bp = 0
                for it, e in zip(self.items, out):
                    pl = self.table.get(it["item_id"])
                    v = make_example(it, pl, self.table, view_spec, self.by, epoch=ep) if pl is not None else None
                    if v is None:
                        if isinstance(e, B3Example):     # no view this epoch: a strictness view (its own boundary
                            #                                  coin) or CF-AUG's own view can still stand
                            self.assertIn((arm == "cfaug", e.mode), ((False, "strict"), (True, "cfaug")), it["item_id"])
                        else:
                            self.assertEqual(e, plain_final(it), (arm, it["item_id"]))
                        continue
                    self.assertIsInstance(e, B3Example, (arm, ep, it["item_id"]))
                    if e.mode == "cfaug":
                        continue
                    self.assertGreaterEqual(e.cf_s, 0, (arm, e.mode))
                    self.assertGreaterEqual(e.decoy, 0, (arm, e.mode))
                    if e.mode != "blockplain":
                        continue
                    n_bp += 1
                    self.assertEqual(e.text, v[0].text, (arm, it["item_id"]))
                    self.assertEqual((e.nodes, e.source_text, e.weight), ((), "", 1.0))
                    self.assertEqual(e.cf_gold, e.orig_gold)
                    self.assertEqual(e.gold, e.orig_gold)
                    self.assertEqual(e.target, [1.0 if i == e.orig_gold else 0.0 for i in range(N_OPTIONS)])
                    opts = parse_options(e.text.split("\nAnswer:")[0])
                    self.assertEqual(canon_number(opts[e.orig_gold]), canon_value(gold_value(it)))
                    blocks[(arm, ep, it["item_id"])] = e.text
                self.assertEqual(n_bp, counts.get("blockplain", 0))
                self.assertGreater(n_bp, 2000)
                self.assertEqual(counts.get("blockplain", 0) + counts.get("block_orig", 0), counts["plain"])
                self.assertEqual(counts.get("blockplain_soft", 0), 0)       # gsmvt's teacher is one-hot gold
        for arm in ("sham", "cfaug"):
            shared = [k for k in blocks if k[0] == arm and ("fsiit",) + k[1:] in blocks]
            self.assertGreater(len(shared), 1000)
            self.assertTrue(all(blocks[k] == blocks[("fsiit",) + k[1:]] for k in shared), arm)
        ss = [k for k in blocks if k[0] == "ssiit" and ("fsiit",) + k[1:] in blocks]
        self.assertTrue(any(blocks[k] != blocks[("fsiit",) + k[1:]] for k in ss))

    def test_label_prior_one_epoch(self):
        """F-SIIT, p 0.5, strict share 0.25, seed 16, epoch 0, flag on: on blocks with foreign values the label is the
        gold for blockplain and strict views and cf(S) for full views; never cf(S') or an own option. P(gold) is the
        card's 0.625 within 0.01 (0.5 + 0.125 of the usable items, less the fallbacks) and the counts equal the stats
        script's (b3_data_stats_v2.json, when present)."""
        out, counts = self.draw(B3Spec("fsiit", seed=16, p=0.5, strict_share=0.25, block_all=True))
        roles = collections.Counter(r for r in map(role, out) if r is not None)
        by_mode = collections.Counter(e.mode for e in out if role(e) is not None)
        n = sum(roles.values())
        self.assertEqual((roles["decoy"], roles["own"]), (0, 0))
        self.assertEqual(roles["gold"], by_mode["blockplain"] + by_mode["strict"])
        self.assertEqual(roles["cf"], by_mode["full"])
        self.assertEqual(by_mode["blockplain"], counts["blockplain"])
        self.assertLess(abs(roles["gold"] / n - 0.625), 0.01, roles)
        if STATS.exists():
            ref = json.loads(STATS.read_text())["train.jsonl"]["block_all"]["p0.5"]["fsiit"]
            self.assertEqual(ref["label_roles"], {k: roles[k] for k in ("gold", "cf", "decoy", "own")})
            self.assertEqual(ref["foreign_blocks"], n)
            self.assertEqual(ref["p_gold_given_foreign"], round(roles["gold"] / n, 4))
            self.assertEqual(ref["counts"]["blockplain"], counts["blockplain"])


class TestBlockAllFixture(unittest.TestCase):
    """The 8 diamond items of test_frontier_train (no data file needed)."""

    @classmethod
    def setUpClass(cls):
        from test_frontier_train import items8
        cls.items = items8()
        cls.by = {it["item_id"]: it for it in cls.items}

    def finals(self):
        return [Example(it["prompt"], list(it["labels"]), [it["teacher"][L] for L in it["labels"]], 1.0, "final",
                        it["item_id"]) for it in self.items]

    def test_p0_all_blockplain_and_spec(self):
        spec = B3Spec("fsiit", layer=2, dim=8, seed=1, p=0.0, block_all=True)
        self.assertTrue(spec.as_dict()["block_all"])
        self.assertFalse(B3Spec("fsiit").as_dict()["block_all"])
        table = build_table(self.items, spec)
        counts: dict = {}
        out = [substitute([f], it, table.get(it["item_id"]), table, spec, self.by, 0, counts)[0]
               for f, it in zip(self.finals(), self.items)]
        self.assertEqual(counts["plain"], 8)
        self.assertEqual(counts.get("blockplain", 0) + counts.get("block_orig", 0), 8)
        self.assertGreaterEqual(counts["blockplain"], 6)
        for e in out:
            if isinstance(e, B3Example):
                self.assertEqual((e.mode, e.nodes), ("blockplain", ()))
                self.assertEqual(e.labels, list(LETTERS))
        # an item without a plan stays as it is and is counted in block_orig
        c2: dict = {}
        f = self.finals()[0]
        self.assertEqual(substitute([f], self.items[0], None, table, spec, self.by, 0, c2), [f])
        self.assertEqual(c2, {"plain": 1, "block_orig": 1})
        # weight carried from the plain example (not lambda)
        f3 = replace(self.finals()[3], weight=0.5)
        e3 = substitute([f3], self.items[3], table["d3"], table, replace(spec, lam=7.0), self.by, 0, {})[0]
        if isinstance(e3, B3Example):
            self.assertEqual(e3.weight, 0.5)


try:
    import torch
    import transformers  # noqa: F401
    from cotdistill.frontier import Frontier, bound_of, resolve_ends, SLOT_ALIGNED
    from cotdistill.student import FINAL_TEMPLATE, kl_loss, text_parts
    from test_depth_forcing import gpt2_tok, tiny_qwen35
    HAVE_TORCH = True
except ImportError:
    HAVE_TORCH = False


def source_only_view(tok, items, by, table, spec):
    """A full view of d0 whose source is d6 (written by 'Ann'; every receiver here is 'Tom''s), and the token ids that
    occur in the source text up to its last written token but in no receiver text: their embedding rows are reached
    only through the source pass."""
    v = make_example(items[0], table["d0"], table, spec, by)[0]
    src = by["d6"]
    sb = bound_of(table, "d6", v.k)
    s_ends, _ = resolve_ends(src, sb.ends)
    v = replace(v, source_id="d6", source_text=FINAL_TEMPLATE.format(problem=src["prompt"]), k_src=v.k,
                nodes=tuple((r, s_ends[j], SLOT_ALIGNED) for j, (r, _, _) in enumerate(v.nodes)))
    return v


@unittest.skipUnless(HAVE_TORCH, "needs torch + transformers")
class TestSourceGrad(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            cls.tok = gpt2_tok()
        except Exception as e:
            raise unittest.SkipTest(f"no local gpt2 tokenizer: {e}")
        from test_frontier_train import items8
        cls.items = items8()
        cls.by = {it["item_id"]: it for it in cls.items}

    def emb_grad(self, source_grad: bool, ckpt: str):
        spec = B3Spec("fsiit", layer=2, dim=8, seed=1, source_grad=source_grad)
        model = tiny_qwen35(len(self.tok), 0)
        model.config.use_cache = False
        model.train()
        if ckpt != "off":
            model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": ckpt == "reentrant"})
        fr = Frontier(model, spec)
        table = build_table(self.items, spec)
        v = source_only_view(self.tok, self.items, self.by, table, spec)
        batch = [v] + [make_example(it, table[it["item_id"]], table, spec, self.by)[0] for it in self.items[1:4]]
        recv = set()
        for e in batch:
            recv |= set(self.tok(e.text)["input_ids"])
        src_ids = self.tok(v.source_text)["input_ids"]
        from cotdistill.depth_forcing import token_at
        last = max(token_at(self.tok, v.source_text, s, 512) for _, s, _ in v.nodes)
        only = sorted(set(src_ids[:last + 1]) - recv)
        self.assertTrue(only, "the source holds no token the receivers lack")
        z, st = fr.forward(model, self.tok, batch, 512, {})
        self.assertEqual(st["cut"], 0)
        model.zero_grad(set_to_none=True)
        kl_loss(z, batch).backward()
        g = text_parts(model)[0].get_input_embeddings().weight.grad
        return g[only].abs().sum().item(), g.abs().sum().item()

    def test_source_only_row(self):
        for ckpt in ("off", "reentrant", "nonreentrant"):
            on, tot_on = self.emb_grad(True, ckpt)
            off, tot_off = self.emb_grad(False, ckpt)
            self.assertGreater(on, 0.0, ckpt)
            self.assertEqual(off, 0.0, ckpt)
            self.assertGreater(tot_off, 0.0, ckpt)                    # the receiver rows get gradient either way

    def test_blockplain_column(self):
        """A blockplain view runs unchanged (no source pass) and is logged in its own column with kl_loss's CE."""
        spec = B3Spec("fsiit", layer=2, dim=8, seed=1, p=0.0, block_all=True)
        model = tiny_qwen35(len(self.tok), 0)
        model.config.use_cache = False
        fr = Frontier(model, spec)
        table = build_table(self.items, spec)
        exs = []
        for it in self.items:
            f = Example(it["prompt"], list(it["labels"]), [it["teacher"][L] for L in it["labels"]], 1.0, "final",
                        it["item_id"])
            exs += substitute([f], it, table[it["item_id"]], table, spec, self.by, 0, {})
        bp = [e for e in exs if isinstance(e, B3Example)]
        self.assertTrue(bp and all(e.mode == "blockplain" for e in bp))
        with torch.no_grad():
            z, st = fr.forward(model, self.tok, bp, 512, {})
        self.assertEqual((st["n_src"], st["cut"]), (0, 0))
        self.assertEqual(st["modes"]["blockplain"][0], len(bp))
        self.assertEqual(sum(v[0] for m, v in st["modes"].items() if m != "blockplain"), 0)
        ce = sum(-(torch.tensor(e.target) * torch.log_softmax(zi.float(), -1)).sum().item() for zi, e in zip(z, bp))
        self.assertAlmostEqual(st["modes"]["blockplain"][1], ce, places=4)
        w = B3Window()
        w.add(st)
        r = w.row()
        self.assertEqual(r["b3_blockplain_n"], len(bp))
        self.assertNotIn("b3_blockplain_cut", r)


@unittest.skipUnless(HAVE_TORCH, "needs torch + transformers")
class TestTrainerV2(unittest.TestCase):
    """train_student.py end to end on the tiny fixture: flag off, the metrics' b3 block (draws, history, readout,
    training totals less the new zero blockplain column) equals the v1 snapshot's; flag on, every plain view of an item
    with a view is a blockplain view, forwarded once per epoch."""

    @classmethod
    def setUpClass(cls):
        try:
            cls.tok = gpt2_tok()
        except Exception as e:
            raise unittest.SkipTest(f"no local gpt2 tokenizer: {e}")

    def run_train(self, d, out, *extra, script=TRAIN):
        r = subprocess.run([sys.executable, script, "--model", d + "/m", "--train", d + "/t.jsonl",
                            "--eval", "val=" + d + "/t.jsonl", "--final", "teacher", "--subq", "none", "--epochs", "3",
                            "--micro-bs", "3", "--grad-accum", "3", "--max-len", "512", "--eval-max-len", "512",
                            "--precision", "fp32master", "--lr", "1e-3", "--log-every", "1", "--seed", "1", "--out", out,
                            "--no-grad-ckpt", "--b3-arm", "fsiit", "--b3-layer", "2", "--b3-dim", "8", *extra],
                           capture_output=True, text=True, timeout=1500, env=ENV)
        self.assertEqual(r.returncode, 0, r.stderr[-4000:])
        return r, json.loads(Path(out + "/metrics.json").read_text())

    def test_flag_off_and_on(self):
        from test_frontier_train import diamond, items8
        ref = REF / "scripts/train_student.py"
        with tempfile.TemporaryDirectory() as d:
            tiny_qwen35(len(self.tok)).save_pretrained(d + "/m")
            self.tok.save_pretrained(d + "/m")
            items = items8() + [dict(diamond(8, 11, 5, 2, 3), item_id="n0", worked_steps=None)]
            Path(d + "/t.jsonl").write_text("\n".join(json.dumps(x) for x in items) + "\n")
            _, new = self.run_train(d, d + "/new")
            if ref.exists():
                _, old = self.run_train(d, d + "/old", script=str(ref))
                self.assertEqual([r["loss"] for r in new["history"]], [r["loss"] for r in old["history"]])
                self.assertEqual(new["eval"]["val"], old["eval"]["val"])
                b_new, b_old = dict(new["b3"]), dict(old["b3"])
                for b in (b_new, b_old):
                    b.pop("timing")
                self.assertEqual(b_new.pop("block_all"), False)
                self.assertEqual((b_new.pop("rotate"), b_new.pop("rotate_lr")), (False, None))   # option (b)'s keys
                self.assertEqual(b_new["train"].pop("blockplain"), {"n": 0, "ce": None, "acc": None, "cut": 0})
                self.assertEqual(b_new["train_totals"]["modes"].pop("blockplain"), [0, 0.0, 0, 0])
                self.assertEqual(json.dumps(b_new, sort_keys=True), json.dumps(b_old, sort_keys=True))
                self.assertEqual(list(b_new["draws"]), list(b_old["draws"]))        # insertion order too
            r, on = self.run_train(d, d + "/on", "--b3-block-all", "--b3-p", "0.5")
            self.assertIn("block-all (plain examples in the views' blocks, label the gold)", r.stdout)
            b3 = on["b3"]
            self.assertTrue(b3["block_all"])
            dr = b3["draws"]
            self.assertEqual(dr["blockplain"], b3["train"]["blockplain"]["n"])
            self.assertGreater(dr["blockplain"], 0)
            self.assertEqual(dr["blockplain"] + dr["block_orig"], dr["plain"])
            self.assertEqual(b3["train"]["plain"]["n"], dr["block_orig"])        # n0 (no steps) and items without a view
            self.assertGreaterEqual(dr["block_orig"], 3)
            self.assertIn("b3_blockplain_ce", on["history"][-1])
            self.assertNotIn("b3_blockplain_cut", on["history"][-1])
            bad = subprocess.run([sys.executable, TRAIN, "--model", d + "/m", "--train", d + "/t.jsonl", "--epochs", "1",
                                  "--out", d + "/o", "--b3-block-all"], capture_output=True, text=True, timeout=900,
                                 env=ENV)
            self.assertNotEqual(bad.returncode, 0)
            self.assertIn("--b3-block-all / --b3-rotate / --b3-rotate-lr need --b3-arm", bad.stderr)


if __name__ == "__main__":
    unittest.main()
