"""Frontier interchange (src/cotdistill/frontier.py; card B3): the data layer. CPU, no model: the program reader and
executor, boundaries and frontiers, counterfactual answers, node positions, partner tables, option blocks, the per-epoch
draws of every arm, CF-AUG substitution; and, with data/ present, the first 300 real items (program re-execution
reproduces the gold, the excluded items are the 7 mismatches)."""
import json
import random
import sys
import unittest
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cotdistill.frontier import (B3Example, B3Spec, Boundary, LETTERS, N_OPTIONS, SLOT_ALIGNED, SLOT_SPARE,  # noqa: E402
                                 ancestors, bound_of, boundaries, build_table, cf_answer, clean, decoy_for, execute,
                                 fmt, free_ends, free_number_ends, frontier, literals, make_example, node_end,
                                 node_ends_all,
                                 non_operand_end, num, option_block, parse_options, partners, program, program_ok,
                                 render_options, resolve_ends, signature, strict_example, substitute,
                                 substitute_literals, validate_spec, wiring)
from cotdistill.depth_forcing import canon_number  # noqa: E402
from cotdistill.student import FINAL_TEMPLATE  # noqa: E402

DATA = ROOT / "data/student_gsm8k_tf_vt/train.jsonl"


def step(i, op, a, b, value, a_from=None, b_from=None):
    return {"step": i + 1, "op": op, "a": str(a), "b": str(b), "value": str(value), "a_from": a_from, "b_from": b_from,
            "text": f"{a} {op} {b} = {value}"}


def item(iid, prompt, steps, options, gold_i=0):
    return {"item_id": iid, "prompt": prompt + "\nOptions:\n" + "\n".join(f"{L}) {o}" for L, o in zip(LETTERS, options)),
            "labels": list(LETTERS), "options": options, "gold_label": LETTERS[gold_i], "worked_steps": steps,
            "teacher": {L: (1.0 if j == gold_i else 0.0) for j, L in enumerate(LETTERS)}}


# A diamond program: s0 = 5 - 2 = 3 (literals 5, 2), s1 = 3 x 4 = 12 (s0, literal 4), s2 = 12 + 3 = 15 (s1, s0),
# s3 = 15 / 3 = 5 (s2, literal 3). Every literal occurs once in the question, in program order.
DIAMOND_PROMPT = ("Tom had 5 apples and lost 2. He multiplied what was left by 4, added what was left before multiplying "
                  "and shared the total among 3 friends. How many each?")
DIAMOND_STEPS = lambda: [step(0, "−", 5, 2, 3), step(1, "×", 3, 4, 12, a_from=0),   # noqa: E731
                         step(2, "+", 12, 3, 15, a_from=1, b_from=0), step(3, "÷", 15, 3, 5, a_from=2)]
DIAMOND = item("d", DIAMOND_PROMPT, DIAMOND_STEPS(), ["5", "12", "15", "7", "2"])

OTHER = item("o", "Ann has 7 pears and eats 1. She doubles the rest, 2 times, and gives away 4.",
             [step(0, "−", 7, 1, 6), step(1, "×", 6, 2, 12, a_from=0), step(2, "−", 12, 4, 8, a_from=1)],
             ["8", "6", "12", "4", "10"])


@unittest.skipUnless(True, "")
class TestProgram(unittest.TestCase):
    def test_num_fmt_clean(self):
        self.assertEqual(num("1,000"), 1000)
        self.assertEqual(num("12.5"), Fraction(25, 2))
        self.assertEqual(num("−3"), -3)
        self.assertIsNone(num("x"))
        self.assertEqual([fmt(Fraction(3)), fmt(Fraction(25, 2)), fmt(Fraction(1, 4)), fmt(Fraction(-7, 2))], ["3", "12.5", "0.25", "-3.5"])
        self.assertTrue(clean(Fraction(1, 4)))
        self.assertFalse(clean(Fraction(1, 3)))
        self.assertFalse(clean(Fraction(10 ** 8)))
        self.assertFalse(clean(None))

    def test_program_and_execute(self):
        steps = program(DIAMOND)
        self.assertEqual([s.value for s in steps], [3, 12, 15, 5])
        self.assertEqual(execute(steps, 0, {}), 5)
        self.assertTrue(program_ok(DIAMOND))
        self.assertIsNone(program(dict(DIAMOND, worked_steps=[])))
        bad = dict(DIAMOND, worked_steps=[dict(s) for s in DIAMOND["worked_steps"]])
        bad["worked_steps"][1]["op"] = "mod"
        self.assertIsNone(program(bad))
        wrong = dict(DIAMOND, options=["4", "12", "15", "7", "2"])      # the program does not give the gold
        self.assertFalse(program_ok(wrong))
        self.assertIsNone(execute([*steps], 3, {}))                     # s3 reads s2, missing from env

    def test_frontier_literals_wiring(self):                            # the diamond: 0 -> 1, (1, 0) -> 2, 2 -> 3
        steps = program(DIAMOND)
        self.assertEqual(frontier(steps, 1), (0,))                       # s0 feeds s1 and s2
        self.assertEqual(frontier(steps, 2), (0, 1))                     # s2 reads s0 and s1
        self.assertEqual(frontier(steps, 3), (2,))
        self.assertEqual(literals(steps, 2), (Fraction(3),))             # only s3's literal 3 remains
        self.assertEqual(literals(steps, 1), (Fraction(4), Fraction(3)))
        self.assertEqual(wiring(steps, 2, (0, 1)), (("+", ("F", 1), ("F", 0)), ("÷", ("P", 0), ("L",))))
        self.assertEqual(signature(steps, 3, (2,)), ((Fraction(15),), (Fraction(3),), (("÷", ("F", 0), ("L",)),)))
        self.assertEqual(frontier(program(item("e", "x", [step(0, "+", 1, 2, 3), step(1, "+", 4, 5, 9)], ["9", "1", "2", "3", "4"])), 1), ())

    def test_counterfactual(self):
        steps = program(DIAMOND)
        self.assertEqual(cf_answer(steps, 2, (0, 1), (Fraction(6), Fraction(21))), Fraction(9))   # (21 + 6) / 3
        self.assertEqual(cf_answer(steps, 1, (0,), (Fraction(9),)), Fraction(15))                 # (9 x 4 + 9) / 3
        self.assertEqual(cf_answer(steps, 3, (2,), (Fraction(6),)), Fraction(2))                  # 6 / 3
        self.assertEqual(cf_answer(steps, 3, (2,), (Fraction(7),)), Fraction(7, 3))              # 7 / 3: not clean
        self.assertFalse(clean(cf_answer(steps, 3, (2,), (Fraction(7),))))
        self.assertTrue(clean(cf_answer(steps, 2, (0, 1), (Fraction(1), Fraction(2)))))          # (2 + 1) / 3 = 1
        self.assertFalse(clean(cf_answer(steps, 2, (0, 1), (Fraction(1), Fraction(5, 2)))))      # 3.5 / 3 = 7/6
        self.assertFalse(clean(cf_answer(program(OTHER), 2, (1,), (Fraction(1, 3),))))

    def test_node_positions(self):
        steps = program(DIAMOND)
        q = DIAMOND["prompt"].split("\nOptions:")[0]
        self.assertEqual(ancestors(steps, 2), {0, 1, 2})
        e0, e1, e2, e3 = (node_end(DIAMOND, steps, i) for i in range(4))
        self.assertTrue(q[:e0].endswith("lost 2"), q[:e0])              # s0's literals 5 and 2: the later one
        self.assertTrue(q[:e1].endswith("by 4"), q[:e1])                # s1: its literal 4 comes after s0's
        self.assertTrue(q[:e2].endswith("by 4"), q[:e2])                # s2 reads s1 and s0 only: the latest ancestor literal
        self.assertTrue(q[:e3].endswith("among 3"), q[:e3])             # s3: its own literal 3, the last number
        self.assertLess(e0, e1)
        self.assertLess(e2, e3)
        no = item("n", "Nothing numeric here.\nmore", [step(0, "+", 1, 2, 3)], ["3", "4", "5", "6", "7"])
        self.assertIsNone(node_end(no, program(no), 0))
        bs = boundaries(DIAMOND, steps)
        self.assertEqual([(b.k, b.F) for b in bs], [(1, (0,)), (2, (0, 1)), (3, (2,))])
        self.assertEqual(bs[1].values, (Fraction(3), Fraction(12)))
        self.assertEqual(bs[1].ends, (e0, e1))

    def test_option_block_and_rendering(self):
        rng = random.Random(0)
        text, options, gold_i, where = option_block(DIAMOND, [Fraction(9), Fraction(5), Fraction(25, 2)], rng)
        self.assertEqual(len(options), N_OPTIONS)
        self.assertEqual(options[gold_i], "5")
        self.assertIn("9", options)
        self.assertIn("12.5", options)
        self.assertEqual(len({canon_number(o) for o in options}), N_OPTIONS)      # distinct values
        self.assertEqual(where[canon_number("9")], options.index("9"))
        self.assertEqual(where[canon_number("5")], gold_i)                # a cf equal to the gold collapses onto it
        self.assertTrue(text.startswith(DIAMOND["prompt"].split("\nOptions:")[0] + "\nOptions:\n"))   # question untouched
        self.assertEqual(parse_options(text), options)
        self.assertEqual(sorted(parse_options(render_options(DIAMOND["prompt"], ["1", "2", "3", "4", "5"]))), ["1", "2", "3", "4", "5"])
        # a counterfactual equal in value to an existing option collapses onto it; fillers appear when options run out
        dup = item("dup", DIAMOND_PROMPT, DIAMOND_STEPS(), ["5", "5.0", "12", "12.0", "15"])
        text2, options2, _, where2 = option_block(dup, [Fraction(12)], rng)
        self.assertEqual(len({canon_number(o) for o in options2}), N_OPTIONS)
        self.assertIn("6", options2)                                     # filler gold + 1
        self.assertEqual(where2[canon_number("12")], options2.index("12"))
        with self.assertRaises(ValueError):
            option_block(DIAMOND, [Fraction(v) for v in (10, 11, 12, 13, 14)], rng)
        # deterministic in the rng
        a = option_block(DIAMOND, [Fraction(5)], random.Random(3))[1]
        b = option_block(DIAMOND, [Fraction(5)], random.Random(3))[1]
        self.assertEqual(a, b)
        self.assertNotEqual(a, option_block(DIAMOND, [Fraction(5)], random.Random(4))[1])

    def test_substitute_literals(self):
        p = substitute_literals(DIAMOND["prompt"], {"5": "9", "2": "1", "4": "4", "3": "6"})
        self.assertIn("Tom had 9 apples and lost 1", p)
        self.assertIn("by 4", p)
        self.assertIn("among 6 friends", p)                              # every standalone occurrence, by value
        self.assertIn("among 9", substitute_literals("Tom had 5 apples, 5 pears among 5 kids.\nOptions:\nA) 5", {"5": "9"}))
        self.assertTrue(p.endswith(DIAMOND["prompt"].split("\nOptions:", 1)[1]))      # the Options block kept
        self.assertIsNone(substitute_literals(DIAMOND["prompt"], {"77": "1"}))         # a literal not in the question


class TestTableAndDraws(unittest.TestCase):
    def setUp(self):
        self.items = [DIAMOND, OTHER,
                      item("p", "Bob has 9 cats and 3 dogs. He buys 2 more of each kind, 2 times.",
                           [step(0, "+", 9, 3, 12), step(1, "×", 12, 2, 24, a_from=0)], ["24", "12", "9", "3", "2"]),
                      item("q", "Sue reads 8 pages, then 6 pages, then twice that, 2 times.",
                           [step(0, "+", 8, 6, 14), step(1, "×", 14, 2, 28, a_from=0)], ["28", "14", "8", "6", "2"]),
                      item("m", DIAMOND_PROMPT.replace("Tom", "Mia"), DIAMOND_STEPS(), ["5", "12", "15", "7", "2"]),   # a match partner
                      {"item_id": "z", "prompt": "No steps.\nOptions:\nA) 1\nB) 2\nC) 3\nD) 4\nE) 5", "labels": list(LETTERS),
                       "options": ["1", "2", "3", "4", "5"], "gold_label": "A", "teacher": {"A": 1.0}}]
        self.spec = B3Spec("fsiit", layer=1, dim=8, seed=3)
        self.table = build_table(self.items, self.spec)
        self.by = {it["item_id"]: it for it in self.items}

    def test_table_counts_and_partners(self):
        c = self.table["_counts"]
        self.assertEqual((c["items"], c["with_steps"], c["program_ok"], c["usable"]), (6, 5, 5, 5))
        self.assertEqual(c["boundaries"], 3 + 2 + 1 + 1 + 3)
        self.assertEqual(c["size_hist"], {"1": 8, "2": 2})
        self.assertEqual(c["nodes_with_position"], c["nodes"])
        part = self.table["_partners"]
        for (iid, k), (sid, sk) in part["size"].items():                # same size, clean cf, different from the gold
            b = next(x for x in self.table[iid].bounds if x.k == k)
            sb = next(x for x in self.table[sid].bounds if x.k == sk)
            self.assertEqual(b.size, sb.size)
            self.assertNotEqual(sid, iid)
            cf = cf_answer(self.table[iid].steps, k, b.F, sb.values)
            self.assertTrue(clean(cf) and cf != self.table[iid].gold, (iid, k, sid, sk, cf))
        self.assertEqual(set(part["match"]), {("d", 1), ("d", 2), ("d", 3), ("m", 1), ("m", 2), ("m", 3)})   # d <-> m only
        self.assertEqual(part["match"][("d", 2)], ("m", 2))
        self.assertTrue(set(part["match"]) <= set(part["samevalue"]))
        self.assertEqual(self.table["z"].excluded if "z" in self.table else "", "")   # no steps: not in the table
        self.assertNotIn("z", self.table)
        self.assertEqual(build_table(self.items, self.spec)["_partners"], part)        # deterministic
        self.assertIn("5", self.table["_literals"])

    def test_make_example_full(self):
        ex, info = make_example(DIAMOND, self.table["d"], self.table, self.spec, self.by, epoch=0)
        self.assertIsInstance(ex, B3Example)
        self.assertEqual(ex.mode, "full")
        self.assertEqual(ex.item_id, "d")
        self.assertIsNotNone(ex.source_id)
        self.assertEqual(len(ex.nodes), next(b for b in self.table["d"].bounds if b.k == ex.k).size)
        opts = parse_options(ex.text.replace("\n\nAnswer:", ""))
        self.assertEqual(len(opts), N_OPTIONS)
        self.assertEqual(opts[ex.orig_gold], "5")
        sb = next(x for x in self.table[ex.source_id].bounds if x.k == ex.k_src)
        b = next(x for x in self.table["d"].bounds if x.k == ex.k)
        cf = cf_answer(self.table["d"].steps, ex.k, b.F, sb.values)
        self.assertEqual(canon_number(opts[ex.cf_gold]), canon_number(fmt(cf)))        # the label is the cf answer
        self.assertNotEqual(ex.cf_gold, ex.orig_gold)
        self.assertEqual(ex.target[ex.cf_gold], 1.0)
        self.assertEqual(ex.weight, self.spec.lam)
        self.assertTrue(all(n[2] == SLOT_ALIGNED for n in ex.nodes))                 # one shared slice [0, d)
        self.assertEqual(len({n[0] for n in ex.nodes}), len(ex.nodes))               # each node at its own token
        self.assertEqual(ex.source_text, FINAL_TEMPLATE.format(problem=self.by[ex.source_id]["prompt"]))
        self.assertTrue(all(isinstance(n[0], int) and isinstance(n[1], int) for n in ex.nodes))   # ends resolved
        qlen = len(DIAMOND["prompt"].split("\nOptions:")[0])
        self.assertEqual(resolve_ends(DIAMOND, (None, 7)), ((qlen, 7), 1))
        self.assertTrue(ex.text.startswith(DIAMOND["prompt"].split("\nOptions:")[0]))  # question untouched
        self.assertEqual(make_example(DIAMOND, self.table["d"], self.table, self.spec, self.by, epoch=0)[0], ex)   # deterministic
        self.assertIsNone(make_example(self.items[-1], self.table.get("z", self.table["d"]), self.table, self.spec, self.by)
                          if "z" in self.table else None)

    def test_make_example_single_and_sham(self):
        spec = B3Spec("ssiit", layer=1, dim=8, seed=3)
        ex, info = make_example(DIAMOND, self.table["d"], self.table, spec, self.by, epoch=1)
        self.assertEqual(ex.mode, "single")
        self.assertEqual(len(ex.nodes), 1)
        b = next(x for x in self.table["d"].bounds if x.k == ex.k)
        sb = next(x for x in self.table[ex.source_id].bounds if x.k == ex.k_src)
        j = ex.nodes[0][2]
        vals = list(b.values)
        vals[j] = sb.values[j]
        single = cf_answer(self.table["d"].steps, ex.k, b.F, tuple(vals))
        opts = parse_options(ex.text.replace("\n\nAnswer:", ""))
        self.assertEqual(canon_number(opts[ex.cf_gold]), canon_number(fmt(single)))
        sham = B3Spec("sham", layer=1, dim=8, seed=3)
        ex2, _ = make_example(DIAMOND, self.table["d"], self.table, sham, self.by, epoch=0)
        self.assertEqual(ex2.mode, "sham")
        full = cf_answer(self.table["d"].steps, ex2.k, next(x for x in self.table["d"].bounds if x.k == ex2.k).F,
                         next(x for x in self.table[ex2.source_id].bounds if x.k == ex2.k_src).values)
        opts2 = parse_options(ex2.text.replace("\n\nAnswer:", ""))
        self.assertEqual(canon_number(opts2[ex2.cf_s]), canon_number(fmt(full)))      # cf(S) in the block
        self.assertIn(ex2.cf_gold, (ex2.cf_s, ex2.decoy))                             # label cf(S) or cf(S')
        self.assertNotEqual(ex2.cf_gold, ex2.orig_gold)
        fs, _ = make_example(DIAMOND, self.table["d"], self.table, self.spec, self.by, epoch=0)
        self.assertEqual((ex2.text, ex2.nodes, ex2.source_text), (fs.text, fs.nodes, fs.source_text))   # F-SIIT's write

    def test_strict_example(self):
        """Item 3: the size partner S (different frontier values), a non-aligned address, label = the gold; the block is
        the intervened views' block (gold, cf(S), cf(S'))."""
        seen = set()
        q = DIAMOND["prompt"].split("\nOptions:")[0]
        avoid = node_ends_all(DIAMOND, self.table["d"].steps)
        for ep in range(12):
            out = strict_example(DIAMOND, self.table["d"], self.table, self.spec, self.by, epoch=ep)
            self.assertIsNotNone(out)
            ex, info = out
            seen.add(info["variant"])
            self.assertEqual((ex.mode, ex.variant), ("strict", info["variant"]))
            self.assertEqual(ex.cf_gold, ex.orig_gold)                   # label = the gold
            self.assertEqual(ex.target[ex.orig_gold], 1.0)
            self.assertEqual(ex.weight, self.spec.strict)
            self.assertEqual(ex.source_id, self.table["_partners"]["size"][("d", ex.k)][0])   # the size partner S
            b, sb = bound_of(self.table, "d", ex.k), bound_of(self.table, ex.source_id, ex.k_src)
            self.assertNotEqual(sb.values, b.values)                     # different frontier values
            opts = parse_options(ex.text.replace("\n\nAnswer:", ""))
            cf = cf_answer(self.table["d"].steps, ex.k, b.F, sb.values)
            self.assertEqual(canon_number(opts[ex.cf_s]), canon_number(fmt(cf)))
            self.assertEqual(len({ex.orig_gold, ex.cf_s, ex.decoy}), 3)
            r_ends, _ = resolve_ends(DIAMOND, b.ends)
            if ex.variant.startswith("pos"):                             # a non-node question token, the aligned slice
                self.assertTrue(all(n[2] == SLOT_ALIGNED for n in ex.nodes))
                self.assertTrue(all(n[0] not in avoid and 0 < n[0] <= len(q) for n in ex.nodes))
                self.assertEqual(set(ex.avoid), avoid)
                self.assertEqual(ex.variant, "pos_num")                  # the diamond has free numbers (5, 3)
                self.assertTrue(all(n[0] in free_number_ends(DIAMOND, self.table["d"].steps) for n in ex.nodes))
            else:                                                        # the aligned tokens, the spare slice
                self.assertEqual([n[0] for n in ex.nodes], list(r_ends))
                self.assertTrue(all(n[2] == SLOT_SPARE for n in ex.nodes))
        self.assertEqual(seen, {"pos_num", "sub"})
        # 'pos' needs one free token per node: a question made only of node numbers has none -> skipped, counted
        bare = item("bare", "2 4", DIAMOND_STEPS(), ["5", "12", "15", "7", "2"])    # 2 = s0's token, 4 = s1's and s2's
        tbl = build_table([bare, DIAMOND, OTHER], self.spec)
        self.assertEqual(free_ends(bare, tbl["bare"].steps), [])
        why, kinds = {}, set()
        for ep in range(12):
            out = strict_example(bare, tbl["bare"], tbl, self.spec, {"bare": bare, "d": DIAMOND, "o": OTHER},
                                 epoch=ep, why=why)
            kinds.add(None if out is None else out[0].variant)
        self.assertIn(None, kinds)
        self.assertFalse({"pos_num", "pos_other"} & kinds)
        self.assertGreater(why.get("strict_skip", 0), 0)
        # free ends: no node position of any boundary, nothing inside a node number ('1,000' -> '1', ',')
        thou = item("t", "Max spends 250 of his 1,000 coins today.",
                    [step(0, "−", 1000, 250, 750), step(1, "×", 750, 2, 1500, a_from=0)], ["1500", "750", "1000", "2", "3"])
        st = program(thou)
        fe = free_ends(thou, st)
        qt = thou["prompt"].split("\nOptions:")[0]
        self.assertNotIn(qt.index("1,000") + 1, fe)
        self.assertNotIn(qt.index("1,000") + 2, fe)
        self.assertTrue(all(e not in node_ends_all(thou, st) for e in fe))

    def test_cfaug_example(self):
        spec = B3Spec("cfaug", layer=1, dim=8, seed=5)
        out = make_example(DIAMOND, self.table["d"], self.table, spec, self.by, epoch=0)
        self.assertIsNotNone(out)
        ex, info = out
        self.assertEqual((ex.mode, ex.source_id, ex.nodes), ("cfaug", None, ()))
        self.assertNotEqual(ex.text.split("\nOptions:")[0], DIAMOND["prompt"].split("\nOptions:")[0])   # substituted
        opts = parse_options(ex.text.replace("\n\nAnswer:", ""))
        self.assertEqual(len(opts), N_OPTIONS)
        # the labelled option is the substituted program's answer: re-read the numbers from the new question
        q = ex.text.split("\nOptions:")[0]
        import re
        nums = re.findall(r"\d+(?:\.\d+)?", q)
        a, b_, c, d = (Fraction(x) for x in nums[:4])                      # had a, lost b, by c, among d
        self.assertEqual(canon_number(opts[ex.cf_gold]), canon_number(fmt(((a - b_) * c + (a - b_)) / d)))
        self.assertNotEqual((a, b_, c, d), (Fraction(5), Fraction(2), Fraction(4), Fraction(3)))

    def test_validate_spec(self):
        validate_spec(B3Spec("fsiit"))
        for bad in (B3Spec("x"), B3Spec("fsiit", p=1.5), B3Spec("fsiit", dim=0), B3Spec("fsiit", strict=-1)):
            with self.assertRaises(ValueError):
                validate_spec(bad)


def wide(iid: str, a: int, b: int, c: int, d: int, who: str = "Kim") -> dict:
    """A two-node frontier at k = 2 with the nodes on different tokens: s0 = a + b (literals a, b), s1 = c x d (literals
    c, d, later in the text), s2 = s0 + s1, s3 = s2 x 2 (the literal 2 of 'twice')."""
    s0, s1 = a + b, c * d
    return item(iid, f"{who} has {a} red and {b} blue pens, then {c} boxes of {d} pens each, then twice the total.",
                [step(0, "+", a, b, s0), step(1, "×", c, d, s1), step(2, "+", s0, s1, s0 + s1, a_from=0, b_from=1),
                 step(3, "×", s0 + s1, 2, 2 * (s0 + s1), a_from=2)],
                [str(2 * (s0 + s1))] + [str(2 * (s0 + s1) + o) for o in (3, 7, 11, 13)])


def shared(iid: str, a: int, b: int) -> dict:
    """Two frontier nodes on ONE token: s0 = a + b and s1 = a x b both become computable at b; s2 = s0 + s1."""
    return item(iid, f"Lee has {a} cups and {b} plates.",
                [step(0, "+", a, b, a + b), step(1, "×", a, b, a * b), step(2, "+", a + b, a * b, 2 * a * b // 2 + a + b,
                                                                           a_from=0, b_from=1)],
                [str(a + b + a * b), "1", "2", "3", "4"])


class TestFix1(unittest.TestCase):
    """Fix round 1 (CARD_b3_v1 Amendment 1 C): the decoy S' in every block, the SHAM coin, the strictness views, one
    shared slice per node and the shared-token exclusion."""

    def setUp(self):
        self.items = [wide(f"w{j}", *t) for j, t in enumerate([(3, 4, 5, 6), (2, 9, 3, 7), (8, 1, 4, 4), (6, 5, 2, 8),
                                                               (7, 7, 3, 3), (12, 3, 6, 2)])]
        self.items += [shared("s0", 3, 5), DIAMOND, OTHER]
        self.by = {it["item_id"]: it for it in self.items}
        self.spec = B3Spec("fsiit", layer=1, dim=8, seed=4)
        self.table = build_table(self.items, self.spec)

    def blocks(self, arm, epochs=6, strict=False):
        spec = B3Spec(arm, layer=1, dim=8, seed=4)
        out = []
        for ep in range(epochs):
            for it in self.items:
                pl = self.table[it["item_id"]]
                r = (strict_example if strict else make_example)(it, pl, self.table, spec, self.by, epoch=ep)
                if r is not None:
                    out.append((it, r[0], r[1]))
        return out

    def test_decoy_in_every_block(self):
        """Item 1: every written block has 5 options holding gold, cf(S), cf(S') with distinct canonical values; cf(S')
        is decoy_for's re-execution with S' = ex.decoy_id."""
        n = 0
        for arm, strict in (("fsiit", False), ("ssiit", False), ("sham", False), ("fsiit", True)):
            for it, ex, info in self.blocks(arm, strict=strict):
                n += 1
                opts = parse_options(ex.text.replace("\n\nAnswer:", ""))
                self.assertEqual(len(opts), N_OPTIONS)
                self.assertEqual(len({canon_number(o) for o in opts}), N_OPTIONS)
                self.assertEqual(len({ex.orig_gold, ex.cf_s, ex.decoy}), 3, (arm, ex.item_id))
                pl = self.table[ex.item_id]
                self.assertEqual(canon_number(opts[ex.orig_gold]), canon_number(fmt(pl.gold)))
                b, sb = bound_of(self.table, ex.item_id, ex.k), bound_of(self.table, ex.source_id, ex.k_src)
                if ex.mode == "single":
                    j = list(resolve_ends(it, b.ends)[0]).index(ex.nodes[0][0])   # the written node (ends are distinct)
                    vals = list(b.values)
                    vals[j] = sb.values[j]
                    cf = cf_answer(pl.steps, b.k, b.F, tuple(vals))

                    def f(v, j=j):
                        w = list(b.values)
                        w[j] = v[j]
                        return cf_answer(pl.steps, b.k, b.F, tuple(w))
                else:
                    cf = cf_answer(pl.steps, b.k, b.F, sb.values)

                    def f(v):
                        return cf_answer(pl.steps, b.k, b.F, v)
                self.assertEqual(canon_number(opts[ex.cf_s]), canon_number(fmt(cf)))
                did, _, dv = decoy_for(self.table, b, f, (pl.gold, cf))
                self.assertEqual(did, ex.decoy_id)
                self.assertEqual(canon_number(opts[ex.decoy]), canon_number(fmt(dv)))
                self.assertTrue(0 <= info["own"] <= 2)
                if ex.mode in ("full", "single"):
                    self.assertEqual(ex.cf_gold, ex.cf_s)
        self.assertGreater(n, 50)

    def test_no_decoy_dropped_and_counted(self):
        """A boundary whose only same-size candidates give cf(S) again has no S': the view is dropped (plain example
        stands), counted in no_decoy."""
        a, b_ = wide("a", 3, 4, 5, 6), wide("b", 2, 9, 3, 7)          # size-2 pool of two items: S' would be S
        its = [a, b_]
        spec = B3Spec("fsiit", layer=1, dim=8, seed=4, p=1.0, strict=0.0)
        t = build_table(its, spec)
        by = {x["item_id"]: x for x in its}
        from cotdistill.student import Example
        b2 = bound_of(t, "a", 2)
        self.assertEqual(b2.size, 2)
        sid, sk = t["_partners"]["size"][("a", 2)]
        self.assertEqual(sid, "b")
        cf = cf_answer(t["a"].steps, 2, b2.F, bound_of(t, sid, sk).values)
        self.assertIsNone(decoy_for(t, b2, lambda v: cf_answer(t["a"].steps, 2, b2.F, v), (t["a"].gold, cf)))
        counts: dict = {}
        epochs = 0
        for ep in range(40):                           # until the k = 2 boundary has been drawn a few times
            fin = [Example("x", list(LETTERS), [1.0] + [0.0] * 4, 1.0, "final", "a")]
            out = substitute(fin, a, t["a"], t, spec, by, ep, counts)
            epochs += 1
            if isinstance(out[-1], B3Example):
                self.assertNotEqual(out[-1].k, 2)              # never a view on the boundary without S'
            if counts.get("no_decoy", 0) >= 3:
                break
        self.assertGreaterEqual(counts.get("no_decoy", 0), 3, counts)
        self.assertEqual(counts["no_view"], counts["plain"])    # dropped -> the plain example stands
        self.assertEqual(counts["no_view"] + counts.get("full", 0), epochs)

    def test_sham_label_coin(self):
        """Item 2: over 2,000 SHAM draws the label is cf(S) half the time (chi-square, 1 dof, p > 0.01 <=> stat <
        6.635); the write is F-SIIT's; with S fixed per (R, k) both labels occur."""
        spec = B3Spec("sham", layer=1, dim=8, seed=4)
        fs = B3Spec("fsiit", layer=1, dim=8, seed=4)
        n = hits = ep = 0
        per_rk: dict = {}
        while n < 2000:
            for it in self.items:
                pl = self.table[it["item_id"]]
                r = make_example(it, pl, self.table, spec, self.by, epoch=ep)
                if r is None:
                    continue
                ex = r[0]
                self.assertIn(ex.cf_gold, (ex.cf_s, ex.decoy))
                f = make_example(it, pl, self.table, fs, self.by, epoch=ep)[0]
                self.assertEqual((ex.text, ex.nodes, ex.source_text, ex.cf_s, ex.decoy),
                                 (f.text, f.nodes, f.source_text, f.cf_gold, f.decoy))
                n += 1
                hits += ex.cf_gold == ex.cf_s
                per_rk.setdefault((ex.item_id, ex.k, ex.source_id), set()).add(ex.cf_gold == ex.cf_s)
            ep += 1
        chi = (hits - n / 2) ** 2 / (n / 2) + ((n - hits) - n / 2) ** 2 / (n / 2)
        self.assertLess(chi, 6.635, (hits, n))
        both = [k for k, v in per_rk.items() if v == {True, False}]
        self.assertGreaterEqual(len(both), len(per_rk) * 0.9, per_rk)

    def test_one_slice_per_node_and_shared_token(self):
        """Item 4: a two-node frontier writes [0, d) at two distinct tokens; a boundary with two nodes on one token is
        excluded (as receiver and as source) and counted."""
        c = self.table["_counts"]
        self.assertEqual(c["excluded"]["shared_token"], 1)              # s0 at k = 2
        self.assertNotIn(2, [b.k for b in self.table["s0"].bounds])
        self.assertTrue(all(sk != 2 or sid != "s0" for (sid, sk) in self.table["_partners"]["size"].values()))
        self.assertTrue(all((sid, sk) != ("s0", 2) for cands in self.table["_partners"]["decoy"].values()
                            for sid, sk in cands))
        two = [ex for _, ex, _ in self.blocks("fsiit") if len(ex.nodes) == 2]
        self.assertTrue(two)
        for ex in two:
            self.assertEqual({n[2] for n in ex.nodes}, {SLOT_ALIGNED})
            self.assertEqual(len({n[0] for n in ex.nodes}), 2)
        # CF-AUG ignores the rule (no write): s0 still draws
        self.assertIsNotNone(make_example(self.by["s0"], self.table["s0"], self.table, B3Spec("cfaug", seed=4), self.by))

    def test_pos_numbers_first(self):
        """Fix 2 item 1: 'pos' writes go to free NUMBER tokens when the item has one per node (pos_num); an item with
        fewer free numbers than nodes uses all of them and completes with other free tokens (pos_other)."""
        from cotdistill.frontier import strict_nodes
        # wide: nodes at b (s0) and d (s1, s2); a and c are free numbers -> the 2-node boundary is pos_num
        w = self.by["w0"]
        pl = self.table["w0"]
        nums = free_number_ends(w, pl.steps)
        q = w["prompt"].split("\nOptions:")[0]
        self.assertEqual([q[:e].rsplit(" ", 1)[-1] for e in nums], ["3", "5"])      # a = 3, c = 5
        b2 = bound_of(self.table, "w0", 2)
        sid, sk = self.table["_partners"]["size"][("w0", 2)]
        for seed in range(6):
            nodes, avoid, var = strict_nodes(w, pl, b2, bound_of(self.table, sid, sk), self.by[sid], "pos",
                                             random.Random(seed))
            self.assertEqual(var, "pos_num")
            self.assertEqual(sorted(n[0] for n in nodes), nums)
        # c not in the text: one free number (a) for two nodes -> a plus one other free token
        thin = item("thin", "Kim has 3 red and 4 blue pens, then boxes of 6 pens each, then twice the total.",
                    [step(0, "+", 3, 4, 7), step(1, "×", 5, 6, 30), step(2, "+", 7, 30, 37, a_from=0, b_from=1),
                     step(3, "×", 37, 2, 74, a_from=2)], ["74", "77", "81", "85", "87"])
        st = program(thin)
        tp = build_table([thin] + self.items, self.spec)
        n1 = free_number_ends(thin, st)
        self.assertEqual(len(n1), 1)
        tb = bound_of(tp, "thin", 2)
        self.assertEqual(tb.size, 2)
        sid, sk = tp["_partners"]["size"][("thin", 2)]
        nodes, _, var = strict_nodes(thin, tp["thin"], tb, bound_of(tp, sid, sk), {**self.by, "thin": thin}[sid], "pos",
                                     random.Random(0))
        self.assertEqual(var, "pos_other")
        self.assertIn(n1[0], [n[0] for n in nodes])
        self.assertTrue(all(n[0] in free_ends(thin, st) for n in nodes))


@unittest.skipUnless(DATA.exists(), "needs data/")
class TestRealData(unittest.TestCase):
    def test_first_300_items(self):
        items = [json.loads(l) for l in open(DATA) if l.strip()][:300]
        with_steps = [it for it in items if it.get("worked_steps")]
        ok = sum(program_ok(it) for it in with_steps)
        self.assertGreaterEqual(ok, len(with_steps) - 2)                 # 7 mismatches in 5,696
        t = build_table(items, B3Spec("fsiit", seed=16))
        c = t["_counts"]
        self.assertEqual(c["with_steps"], len(with_steps))
        self.assertGreater(c["usable"] / c["with_steps"], 0.9)
        self.assertGreater(c["nodes_with_position"] / c["nodes"], 0.9)
        self.assertGreater(c["items_with_size_partner"] / c["usable"], 0.95)
        by = {it["item_id"]: it for it in items}
        n = 0
        for it in with_steps:
            pl = t.get(it["item_id"])
            if pl is None or pl.excluded:
                continue
            out = make_example(it, pl, t, B3Spec("fsiit", seed=16), by)
            if out is None:
                continue
            ex, info = out
            n += 1
            opts = parse_options(ex.text.replace("\n\nAnswer:", ""))
            self.assertEqual(len(opts), N_OPTIONS)
            self.assertEqual(len({canon_number(o) for o in opts}), N_OPTIONS)
            self.assertNotEqual(ex.cf_gold, ex.orig_gold)
            self.assertEqual(len({ex.orig_gold, ex.cf_s, ex.decoy}), 3)               # gold, cf(S), cf(S') distinct
            self.assertEqual(ex.cf_gold, ex.cf_s)
        self.assertGreater(n, 0.9 * c["usable"])
        self.assertLess(c["excluded"]["shared_token"] / (c["boundaries"] + c["excluded"]["shared_token"]), 0.25)
        # fix 2 item 1: the share of 'pos' strictness views whose writes all sit on a number token
        var = {"pos_num": 0, "pos_other": 0, "sub": 0}
        for ep in range(3):
            for it in with_steps:
                pl = t.get(it["item_id"])
                if pl is None or pl.excluded:
                    continue
                out = strict_example(it, pl, t, B3Spec("fsiit", seed=16), by, epoch=ep)
                if out is not None:
                    var[out[0].variant] += 1
        share = var["pos_num"] / max(1, var["pos_num"] + var["pos_other"])
        print(f"\n[fix2] pos views on number tokens, first 300 train items x 3 epochs: {var} share {share:.3f}")
        self.assertGreaterEqual(share, 0.75, var)


if __name__ == "__main__":
    unittest.main()
