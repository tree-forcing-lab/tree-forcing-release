"""Depth forcing (src/cotdistill/depth_forcing.py; train_student.py / eval_student.py --df-layers; arms DF, DFX).
CPU, float32, a tiny random Qwen3.5 text model (8 layers, full attention at 3 and 7, the rest Gated DeltaNet, as
tests/test_layer_loop.py) with the GPT-2 tokenizer from the local HF cache (its vocabulary gives the digit tokens
the value encodings need). Checks: (1) with the feature off the letter logits and the loss are the plain A2 arm's
bit for bit (and, with COTD_REF_REPO set, the trainer's history equals the reference checkout's); (2) at lambda 0 the
gradients of the base weights equal A2's; (3) the captures are the listed layers' outputs and the supervised count
per k matches the items' step counts; (4) the InfoNCE candidate set holds the positive once and the loss is finite;
(5) 30 optimisation steps on 8 fixed items drive the probe accuracy at every supervised layer to 1.0 while the answer
CE still decreases; (6) --df-shuffle gives every item another item's values, deterministically; (7) sidecar round trip
and the eval_student probe path (subprocess, as tests/test_layer_loop.py); (8) gradient checkpointing on (reentrant
and non-reentrant) gives the loss of checkpointing off within 1e-5; plus the digits target, flag validation, the
token-budget loop and the value helpers."""
import copy
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

try:
    import torch
    import transformers
    from cotdistill.depth_forcing import (DF_HEADS_FILE, DF_SIDECAR, DIGITS_OUT, DFSpec, DFWindow, DepthForcing,
                                          _Capture, build_table, canon_number, df_partners, digit_code,
                                          load_df_heads, no_operand_counts, operand_end, option_values,
                                          param_groups, parse_df_layers, prompt_numbers, supervised_counts, token_at)
    from cotdistill.student import Example, body_layers, kl_loss, label_logits, text_parts
    HAVE = True
except ImportError:
    HAVE = False

ENV = {**os.environ, "CUDA_VISIBLE_DEVICES": "", "OMP_NUM_THREADS": "2"}
TRAIN = str(ROOT / "scripts/train_student.py")
EVAL = str(ROOT / "scripts/eval_student.py")
LAYER_TYPES = ["linear_attention"] * 3 + ["full_attention"] + ["linear_attention"] * 3 + ["full_attention"]


def gpt2_tok():
    tok = transformers.AutoTokenizer.from_pretrained("gpt2", local_files_only=True)
    tok.pad_token = tok.eos_token
    return tok


def tiny_qwen35(vocab: int, seed: int = 0):
    """A random Qwen3.5 text model: hidden 64, 8 layers, full attention at 3 and 7 (as Qwen3.5-4B's 3, 7, ...)."""
    cfg = transformers.Qwen3_5TextConfig(vocab_size=vocab, hidden_size=64, intermediate_size=128, num_hidden_layers=8,
                                         num_attention_heads=4, num_key_value_heads=2, head_dim=16,
                                         layer_types=list(LAYER_TYPES), linear_num_value_heads=4, linear_num_key_heads=2,
                                         linear_key_head_dim=16, linear_value_head_dim=16, linear_conv_kernel_dim=4,
                                         max_position_embeddings=512, tie_word_embeddings=True)
    torch.manual_seed(seed)
    return transformers.Qwen3_5ForCausalLM(cfg)


def df_item(j: int, n_steps: int, base: int = 0, with_steps: bool = True) -> dict:
    """A GSM8K-like item: a chain of n_steps arithmetic steps whose values are base + 1, base + 2, ... (so the items'
    value sets are disjoint when base differs by >= 100), option A gold = the last value, other options other numbers."""
    vals = [base + k for k in range(1, n_steps + 1)]
    ops = [10 * k + j + 1 for k in range(1, n_steps + 1)]           # step k's operand a, listed in the question
    steps = [{"step": k, "a": str(o), "b": "1", "value": str(v), "text": f"{o} + 1 = {v}"}
             for k, (o, v) in enumerate(zip(ops, vals), 1)]
    a, b = 7 + j, 3 + j
    gold = vals[-1]
    opts = [str(gold), str(gold + 11), str(gold + 23), f"{gold + 5}.0", str(gold - 2)]
    prompt = (f"Ann has {a} apples and buys {b} more, pays 1,000 coins and 12.5 kg of pears. Her notes list "
              + ", ".join(str(o) for o in ops) + f" units. After {n_steps} steps, "
              f"how many does she have?\nOptions:\n" + "\n".join(f"{L}) {o}" for L, o in zip("ABCDE", opts)))
    it = {"item_id": f"d{j}", "prompt": prompt, "labels": list("ABCDE"), "gold_label": "A", "options": opts,
          "teacher": {"A": 1.0, "B": 0.0, "C": 0.0, "D": 0.0, "E": 0.0}, "n_steps": n_steps}
    if with_steps:
        it["worked_steps"] = steps
    return it


def items8() -> list[dict]:
    """8 items with 1..4 steps (two of each) and disjoint value sets, plus none without steps."""
    return [df_item(j, 1 + j % 4, base=100 * (j + 1)) for j in range(8)]


def finals(items: list[dict]) -> list[Example]:
    from cotdistill.student import FINAL_TEMPLATE
    return [Example(FINAL_TEMPLATE.format(problem=it["prompt"]), it["labels"],
                    [it["teacher"][L] for L in it["labels"]], 1.0, "final", it["item_id"]) for it in items]


@unittest.skipUnless(HAVE, "needs torch + transformers")
class TestHelpers(unittest.TestCase):
    def test_canon_and_code(self):
        self.assertEqual([canon_number(x) for x in ("12.0", "12", "1,000", "-0.50", "0.0", "1.2e1", "abc", "")],
                         ["12", "12", "1000", "-0.5", "0", "12", None, None])
        self.assertEqual(digit_code("3"), [0, 3, 0, 0, 0, 0, 0, 6])
        self.assertEqual(digit_code("12.5"), [0, 1, 2, 5, 0, 0, 0, 7])
        self.assertEqual(digit_code("0"), [0] * 7 + [6])
        self.assertEqual(digit_code("-1234567"), [1, 1, 2, 3, 4, 5, 6, 12])     # truncated to 6 digits, exp clipped
        self.assertEqual(digit_code("0.004"), [0, 4, 0, 0, 0, 0, 0, 3])
        self.assertEqual(digit_code("30"), digit_code("30.0"))
        self.assertEqual(len(digit_code("1")), 1 + 6 + 1)
        self.assertEqual(DIGITS_OUT, 2 + 60 + 13)
        with self.assertRaises(ValueError):
            digit_code("x")

    def test_prompt_numbers_and_options(self):
        it = df_item(0, 2, base=100)
        self.assertEqual(prompt_numbers(it["prompt"]), ["7", "3", "1000", "12.5", "11", "21", "2"])   # options excluded
        self.assertEqual(option_values(it), it["options"])
        self.assertEqual(option_values({"prompt": it["prompt"]}), it["options"])          # parsed from the prompt

    def test_parse_layers(self):
        self.assertEqual(parse_df_layers("auto", 4), (10, 14, 18, 22))
        self.assertEqual(parse_df_layers("auto", 3, L0=2, stride=3), (5, 8, 11))
        self.assertEqual(parse_df_layers("10,14,18,22", 3), (10, 14, 18))
        self.assertEqual(parse_df_layers(" 1, 5 ", 4), (1, 5))
        for bad in ("", "1,1", "a", "-1"):
            with self.assertRaises(ValueError):
                parse_df_layers(bad, 4)
        with self.assertRaises(ValueError):
            parse_df_layers("auto", 0)

    def test_spec_round_trip(self):
        spec = DFSpec((1, 3, 5), lam=0.25, target="digits", dim=32, shared_head=True, shuffle=True, max_steps=3,
                      temperature=0.2, seed=7, L0=0, stride=2)
        self.assertEqual(DFSpec.from_dict(json.loads(json.dumps(spec.as_dict()))), spec)
        with self.assertRaises(ValueError):
            DFSpec.from_dict({"layers": [1, 1]})
        with self.assertRaises(ValueError):
            DFSpec.from_dict({"layers": [1], "target": "x"})

    def test_table_and_counts(self):
        items = items8() + [df_item(8, 2, with_steps=False)]
        spec = DFSpec((1, 3, 5))                                           # K = 3: the 4-step items supervise 3
        t = build_table(items, spec)
        self.assertEqual(set(t), {f"d{j}" for j in range(8)})
        self.assertEqual(supervised_counts(t, 3), [8, 6, 4])
        self.assertEqual(t["d3"].values, ["401", "402", "403"])            # 4 steps, capped at K
        self.assertEqual(t["d3"].targets, t["d3"].values)
        self.assertEqual(len(t["d0"].nums), 6)                             # 7, 3, 1000, 12.5, 11, 1 (at most 8)
        self.assertEqual(t["d0"].ends, [])                                 # pos answer: no operand positions

    def test_shuffle_partners(self):                                       # (6)
        items = items8()
        spec = DFSpec((1, 3, 5), shuffle=True, seed=3)
        t1, t2 = build_table(items, spec), build_table(items, spec)
        self.assertEqual({k: v.targets for k, v in t1.items()}, {k: v.targets for k, v in t2.items()})   # deterministic
        for d in t1.values():
            self.assertEqual(len(d.targets), len(d.values))
            self.assertTrue(all(a != b for a, b in zip(d.targets, d.values)), d)   # disjoint value sets: every target differs
            self.assertIsNotNone(d.partner)
            self.assertNotEqual(d.partner, d.item_id)
        self.assertEqual(supervised_counts(t1, 3), supervised_counts(build_table(items, DFSpec((1, 3, 5))), 3))
        p3, p4 = df_partners(items, 3), df_partners(items, 4)
        self.assertEqual(p3, {k: v.partner for k, v in t1.items()})
        self.assertNotEqual(p3, p4)                                        # the seed matters
        with self.assertRaises(ValueError):
            df_partners([items[0]], 0)                                     # no other item
        self.assertEqual(build_table(items, spec, shuffle=False)["d0"].targets, t1["d0"].values)   # the probe's table

    def test_window(self):
        w = DFWindow(2)
        w.add({"n": 3, "aux": 1.0, "per_k": {1: [2, 2], 2: [0, 1]}, "cands": 5.0})
        w.add({"n": 0, "aux": 0.0, "per_k": {1: [0, 0], 2: [0, 0]}, "cands": 0.0})
        r = w.row(0.5)
        self.assertEqual((r["df_aux"], r["loss_df"], r["df_pairs"], r["df_acc"]), (1.0, 0.5, 3, {"1": 1.0, "2": 0.0}))
        self.assertEqual(w.totals, [2, 1])
        self.assertEqual(w.row(0.5)["df_aux"], None)                       # reset
        w.add_reduced(2.0, 2, [[1, 2], [1, 1]])
        self.assertEqual(w.row(1.0), {"df_aux": 1.0, "loss_df": 1.0, "df_pairs": 3, "df_acc": {"1": 0.5, "2": 1.0}})


@unittest.skipUnless(HAVE, "needs torch + transformers")
class TestForward(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            cls.tok = gpt2_tok()
        except Exception as e:
            raise unittest.SkipTest(f"no local gpt2 tokenizer: {e}")
        cls.items = items8()
        cls.batch = finals(cls.items)

    def fresh(self, spec=None, seed=0):
        model = tiny_qwen35(len(self.tok), seed)
        model.config.use_cache = False
        model.train()
        spec = spec or DFSpec((1, 3, 5), lam=0.5, dim=32)
        df = DepthForcing(model, spec)
        return model, df, build_table(self.items, spec)

    def test_heads_registered(self):
        model, df, _ = self.fresh()
        body, _ = text_parts(model)
        self.assertIs(body.df_heads, df.heads)
        names = [n for n, _ in model.named_parameters() if "df_heads" in n]
        self.assertEqual(len(names), 4)                                    # 3 heads + proj
        self.assertEqual(df.n_params(), 4 * 64 * 32)
        self.assertEqual(len(body_layers(body)), 8)                        # the heads are not decoder layers
        from cotdistill.fsdp import decoder_layers
        self.assertEqual(len(decoder_layers(body)), 8)
        shared = DepthForcing(tiny_qwen35(len(self.tok)), DFSpec((1, 3, 5), shared_head=True, dim=32))
        self.assertEqual(shared.n_params(), 2 * 64 * 32)
        self.assertIs(shared.heads.head(1), shared.heads.head(3))
        with self.assertRaises(ValueError):
            DepthForcing(tiny_qwen35(len(self.tok)), DFSpec((1, 7)))       # layer 8 does not exist

    def test_flags_off_logits_bit_identical(self):                        # (1)
        model, df, table = self.fresh()
        plain = copy.deepcopy(model)
        del text_parts(plain)[0].df_heads                                  # the A2 model: no heads
        cache: dict = {}
        z_a2 = label_logits(plain, self.tok, self.batch, 512, cache)
        z_df, aux, st = df.forward(model, self.tok, self.batch, 512, {}, table)
        self.assertEqual(len(z_a2), len(z_df))
        for a, b in zip(z_a2, z_df):
            self.assertTrue(torch.equal(a, b))
        self.assertTrue(torch.equal(kl_loss(z_a2, self.batch), kl_loss(z_df, self.batch)))
        self.assertTrue(torch.isfinite(aux))
        self.assertEqual(st["n"], 8 + 6 + 4)                               # (3): items with >= k steps, k = 1..3
        self.assertEqual({k: v[1] for k, v in st["per_k"].items()}, {1: 8, 2: 6, 3: 4})

    def grads(self, model, loss):
        model.zero_grad(set_to_none=True)
        loss.backward()
        return {n: p.grad.detach().clone() for n, p in model.named_parameters() if p.grad is not None}

    def test_lambda0_base_gradients_equal_A2(self):                        # (2)
        model, df, table = self.fresh()
        plain = copy.deepcopy(model)
        del text_parts(plain)[0].df_heads
        z = label_logits(plain, self.tok, self.batch, 512, {})
        g_a2 = self.grads(plain, kl_loss(z, self.batch) * len(self.batch) / len(self.batch))
        z, aux, st = df.forward(model, self.tok, self.batch, 512, {}, table)
        lam = 0.0
        total = kl_loss(z, self.batch) * len(self.batch)
        total = total + (lam * aux if lam else 0.0) * len(self.batch)      # as train_student's df_term at lambda 0
        g_df = self.grads(model, total / len(self.batch))
        base = {n for n in g_df if "df_heads" not in n}
        self.assertEqual(base, set(g_a2))
        for n in base:
            self.assertTrue(torch.equal(g_a2[n], g_df[n]), n)
        self.assertFalse(any("df_heads" in n for n in g_df))               # no head gradient at lambda 0

    def test_capture_is_the_layer_output(self):                            # (3)
        model, df, table = self.fresh()
        model.eval()
        body, _ = text_parts(model)
        from cotdistill.student import collate
        b = collate(self.tok, self.batch, 512, "cpu")
        with torch.no_grad(), _Capture(df.dl, df.spec.layers) as cap:
            res = body(input_ids=b["input_ids"], attention_mask=b["attention_mask"], output_hidden_states=True,
                       use_cache=False)
        self.assertEqual(set(cap.h), {1, 3, 5})
        for li in df.spec.layers:                                          # hidden_states[0] is the embedding output
            self.assertTrue(torch.equal(cap.h[li], res.hidden_states[li + 1]), li)
        self.assertFalse(torch.equal(cap.h[1], cap.h[3]))

    def test_candidates_hold_the_positive_once_and_loss_is_finite(self):   # (4)
        model, df, table = self.fresh()
        items = [dict(it, options=it["options"] + [it["worked_steps"][0]["value"] + ".0"]) for it in self.items]
        table = build_table(items, df.spec)                                # an option equal in value to step 1
        pairs = [(i, k) for i, e in enumerate(self.batch) for k in range(1, len(table[e.item_id].targets) + 1)]
        strings, allowed, pos = DepthForcing.candidates(self.batch, table, pairs)
        self.assertEqual(len({canon_number(s) for s in strings}), len(strings))   # distinct numeric values
        for (i, k), cset, p in zip(pairs, allowed, pos):
            d = table[self.batch[i].item_id]
            self.assertIn(p, cset)
            self.assertEqual(canon_number(strings[p]), canon_number(d.targets[k - 1]))
            same = [j for j in cset if canon_number(strings[j]) == canon_number(strings[p])]
            self.assertEqual(same, [p], (i, k))                            # the positive once, no duplicate negative
            for t in d.targets + d.options + d.nums:                       # (a) (b) (d) are candidates
                self.assertIn(canon_number(t), {canon_number(strings[j]) for j in cset})
            for e in self.batch:                                           # (c) the other items' targets
                for t in table[e.item_id].targets:
                    self.assertIn(canon_number(t), {canon_number(strings[j]) for j in cset})
            self.assertGreaterEqual(len(cset), 20)
        z, aux, st = df.forward(model, self.tok, self.batch, 512, {}, table)
        self.assertTrue(torch.isfinite(aux))
        self.assertGreater(aux.detach().item(), 0.0)
        self.assertGreater(st["cands"], 20)

    def test_checkpointing_same_loss(self):                                # (8)
        def run(ckpt):
            model, df, table = self.fresh()
            if ckpt is not None:
                model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": ckpt})
                if ckpt:
                    model.enable_input_require_grads()
            z, aux, st = df.forward(model, self.tok, self.batch, 512, {}, table)
            loss = (kl_loss(z, self.batch) * len(self.batch) + 0.5 * aux * len(self.batch)) / len(self.batch)
            g = self.grads(model, loss)
            return loss.detach(), aux.detach().item(), g
        off, non_re, re = run(None), run(False), run(True)
        for name, (loss, aux, g) in (("non-reentrant", non_re), ("reentrant", re)):
            self.assertLess(abs(float(loss) - float(off[0])), 1e-5, name)
            self.assertLess(abs(aux - off[1]), 1e-5, name)
            self.assertEqual(set(g), set(off[2]), name)
            for n in off[2]:
                self.assertTrue(torch.allclose(off[2][n], g[n], atol=1e-5, rtol=1e-4), (name, n))
        for n in ("model.layers.0.mlp.down_proj.weight", "model.layers.4.mlp.down_proj.weight",
                  "model.df_heads.heads.0.weight", "model.df_heads.heads.2.weight", "model.df_heads.proj.weight"):
            self.assertGreater(off[2][n].abs().sum().item(), 0.0, n)      # the auxiliary gradient reaches them

    def test_aux_gradient_reaches_only_earlier_layers(self):
        """The head-k loss alone moves layers <= L_k and the heads, not layers past L_K (= 5) or the output rows."""
        model, df, table = self.fresh()
        z, aux, st = df.forward(model, self.tok, self.batch, 512, {}, table)
        g = self.grads(model, aux)
        self.assertTrue(all(g[f"model.layers.{li}.mlp.down_proj.weight"].abs().sum() > 0 for li in range(6)))
        self.assertTrue(all(f"model.layers.{li}.mlp.down_proj.weight" not in g for li in (6, 7)))
        self.assertNotIn("model.norm.weight", g)
        self.assertIn("model.embed_tokens.weight", g)                     # through the residual stream (the inputs)
        # ... but not through the target encodings: they read the embedding table detached
        model, df, table = self.fresh()
        emb = text_parts(model)[0].get_input_embeddings().weight
        df.encode_values(model, self.tok, ["101", "12.5"]).sum().backward()
        self.assertIsNone(emb.grad)
        self.assertIsNotNone(df.heads.proj.weight.grad)

    def overfit(self, spec, steps=30, lr_heads=1e-2, lr_base=1e-3):
        """steps of AdamW on the 8 items (heads and base weights in their own groups: the random tiny model's layer-1
        states differ across items by about 0.5% of their norm, so the heads need the larger rate)."""
        model, df, table = self.fresh(spec)
        params = [p for p in model.parameters() if p.requires_grad]
        if lr_base == 0.0:                                 # heads only (the base frozen)
            groups = [{"params": [p for p in params if id(p) in {id(q) for q in df.heads.parameters()}], "lr": lr_heads}]
        else:                                              # the trainer's grouping: param_groups (--df-head-lr)
            groups = param_groups(params, df.heads, None if lr_heads == lr_base else lr_heads)
        opt = torch.optim.AdamW(groups, lr=lr_base, weight_decay=0.0)
        ces, accs = [], []
        for _ in range(steps):
            z, aux, st = df.forward(model, self.tok, self.batch, 512, {}, table)
            ce = kl_loss(z, self.batch)
            loss = ce + spec.lam * aux
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
            ces.append(ce.detach().item())
            accs.append({k: c / n for k, (c, n) in st["per_k"].items() if n})
        with torch.no_grad():
            z, aux, st = df.forward(model, self.tok, self.batch, 512, {}, table)
        return ces, accs, {k: c / n for k, (c, n) in st["per_k"].items() if n}, df, model, table

    def test_overfit_probe_reaches_one(self):                              # (5)
        ces, accs, final, df, model, table = self.overfit(DFSpec((1, 3, 5), lam=0.5, dim=32))
        self.assertEqual(final, {1: 1.0, 2: 1.0, 3: 1.0}, accs[-3:])
        self.assertLess(ces[-1], ces[0] * 0.5, (ces[0], ces[-1]))
        self.assertLess(min(accs[0].values()), 1.0)                        # it started below 1
        probe = df.probe(model, self.tok, self.items, 512, 4, {})
        self.assertEqual((probe["layers"], probe["pairs"], probe["acc"]), ([1, 3, 5], [8, 6, 4], [1.0, 1.0, 1.0]))
        self.assertGreater(probe["cands"], 10)

    def test_digits_target(self):
        spec = DFSpec((1, 3, 5), lam=0.5, target="digits")
        model, df, table = self.fresh(spec)
        self.assertEqual(df.heads.heads[0].weight.shape, (DIGITS_OUT, 64))
        self.assertIsNone(df.heads.proj)
        z, aux, st = df.forward(model, self.tok, self.batch, 512, {}, table)
        self.assertTrue(torch.isfinite(aux))
        self.assertEqual({k: v[1] for k, v in st["per_k"].items()}, {1: 8, 2: 6, 3: 4})
        # the code is memorisable: 30 steps of the heads alone (the base fixed) reach exact matches everywhere
        ces, accs, final, df, model, table = self.overfit(spec, steps=30, lr_heads=0.1, lr_base=0.0)
        self.assertEqual(final, {1: 1.0, 2: 1.0, 3: 1.0}, accs[-3:])
        self.assertEqual(ces[0], ces[-1])                                  # the base did not move
        probe = df.probe(model, self.tok, self.items, 512, 4, {})
        self.assertEqual(probe["acc"], [1.0, 1.0, 1.0])
        self.assertIsNone(probe["cands"])

    def test_weight_zero_pairs_are_in_the_graph_but_not_counted(self):
        """An --fsdp pad micro-batch (one sequence at weight 0): zero auxiliary loss, zero head gradients (not None),
        no counted pair."""
        import dataclasses
        model, df, table = self.fresh()
        pad = [dataclasses.replace(self.batch[3], weight=0.0)]
        z, aux, st = df.forward(model, self.tok, pad, 512, {}, table)
        self.assertEqual((st["n"], aux.detach().item()), (0, 0.0))
        self.assertEqual({k: v[1] for k, v in st["per_k"].items()}, {1: 0, 2: 0, 3: 0})
        g = self.grads(model, aux)
        for n in ("model.df_heads.heads.0.weight", "model.df_heads.heads.1.weight", "model.df_heads.proj.weight"):
            self.assertIn(n, g, n)
            self.assertEqual(g[n].abs().sum().item(), 0.0, n)
        # a micro-batch of items without steps: the heads still enter the graph (every rank reduces the same set)
        no_steps = finals([df_item(9, 2, with_steps=False)])
        z, aux, st = df.forward(model, self.tok, no_steps, 512, {}, table)
        self.assertEqual(st["n"], 0)
        g = self.grads(model, aux)
        self.assertIn("model.df_heads.heads.2.weight", g)

    # ---- --df-pos operand (DFO / DFOX)
    HAND = {"item_id": "h0", "labels": list("ABCDE"), "gold_label": "A", "n_steps": 3,
            "teacher": {"A": 1.0, "B": 0.0, "C": 0.0, "D": 0.0, "E": 0.0},
            "prompt": "Tom had 5 apples. He ate 2 of them, then bought 1,000 grams of pears for 3 coins and 12.5 kg of "
                      "plums. How many apples are left?\nOptions:\nA) 3\nB) 2\nC) 5\nD) 1000\nE) 7",
            "options": ["3", "2", "5", "1000", "7"],
            "worked_steps": [{"step": 1, "a": "5", "b": "2", "value": "3", "text": "5 - 2 = 3"},
                             {"step": 2, "a": "3", "b": "1000", "value": "3000", "text": "3 x 1000 = 3000"},
                             {"step": 3, "a": "99", "b": "77", "value": "7623", "text": "99 x 77 = 7623"}]}

    def test_operand_position_found(self):                                 # (a)
        from cotdistill.student import FINAL_TEMPLATE, collate
        p = self.HAND["prompt"]
        q = p.split("\nOptions:")[0]
        e1, e2, e3 = (operand_end(p, s) for s in self.HAND["worked_steps"])
        self.assertEqual(q[e1 - 1], "2")                                   # "ate 2": the latest of 5 and 2
        self.assertEqual(q[:e1].endswith("He ate 2"), True)
        self.assertEqual(q[:e2].endswith("for 3"), True)                   # "3 coins" after "1,000" (= 1000); not A) 3
        self.assertIsNone(e3)                                              # 99 and 77 are not in the question
        text = FINAL_TEMPLATE.format(problem=p)
        for end, num in ((e1, "2"), (e2, "3")):
            pos = token_at(self.tok, text, end, 512)
            enc = self.tok(text, add_special_tokens=False, return_offsets_mapping=True)
            self.assertEqual(enc["offset_mapping"][pos][1], end)           # the token ends where the number ends
            self.assertEqual(self.tok.decode([enc["input_ids"][pos]]).strip(), num)
            b = collate(self.tok, finals([self.HAND]), 512, "cpu")
            self.assertEqual(int(b["input_ids"][0, pos]), enc["input_ids"][pos])   # the same index in collate's row
            self.assertLess(pos, int(b["last"][0]))
        # the slow path (prefix re-tokenised) agrees on this text
        ids = self.tok.encode(text, add_special_tokens=False)
        self.assertEqual(len(self.tok.encode(text[:e1], add_special_tokens=False)) - 1, token_at(self.tok, text, e1, 512))
        # the tail cut: a max_len that drops the first tokens shifts the index; one that drops the number gives None
        n = len(ids)
        self.assertEqual(token_at(self.tok, text, e1, n - 3), token_at(self.tok, text, e1, 512) - 3)
        pos1 = token_at(self.tok, text, e1, 512)
        self.assertIsNone(token_at(self.tok, text, e1, n - pos1 - 1))
        self.assertEqual(token_at(self.tok, text, e1, n - pos1), 0)
        # canonical matching: "1,000" in the text is operand "1000"; a standalone "5" is not matched by "12.5"
        self.assertEqual(q[:operand_end(p, {"a": "1000", "b": "0"})].endswith("1,000"), True)
        self.assertEqual(q[:operand_end(p, {"a": "5", "b": "x"})].endswith("had 5"), True)
        self.assertEqual(q[:operand_end(p, {"a": "12.5", "b": "x"})].endswith("12.5"), True)
        self.assertIsNone(operand_end(p, {"a": None, "b": None}))
        # the options block is not searched: "7" occurs only as option E) 7 -> no position; "3" (option A) is read at
        # "for 3" in the question, not at the option line (checked above); without an Options block the whole prompt is
        self.assertIsNone(operand_end(p, {"a": "7", "b": "7"}))
        self.assertIn("E) 7", p)
        self.assertEqual(operand_end("Tom had 7 apples.", {"a": "7", "b": "x"}), len("Tom had 7"))

    def test_no_operand_step_skipped_and_counted(self):                    # (b)
        spec = DFSpec((1, 3, 5), lam=0.5, dim=32, pos="operand")
        items = self.items + [self.HAND]
        table = build_table(items, spec)
        self.assertEqual(table["h0"].ends[2], None)
        self.assertEqual(no_operand_counts(table, 3), [0, 0, 1])
        self.assertEqual(supervised_counts(table, 3, "operand"), [9, 7, 4])     # h0 supervises steps 1 and 2 only
        self.assertEqual(supervised_counts(table, 3, "answer"), [9, 7, 5])
        self.assertFalse(table["h0"].supervised(3, "operand"))
        self.assertTrue(table["h0"].supervised(3, "answer"))
        model = tiny_qwen35(len(self.tok))
        model.train()
        df = DepthForcing(model, spec)
        z, aux, st = df.forward(model, self.tok, finals(items), 512, {}, table)
        self.assertEqual(st["skipped"], {"no_operand": 1, "truncated": 0})
        self.assertEqual({k: v[1] for k, v in st["per_k"].items()}, {1: 9, 2: 7, 3: 4})
        self.assertTrue(torch.isfinite(aux))
        probe = df.probe(model, self.tok, items, 512, 4, {})
        self.assertEqual((probe["pos"], probe["pairs"], probe["no_operand_position"]), ("operand", [9, 7, 4], [0, 0, 1]))
        # a position cut by max_len is counted as truncated
        z, aux, st = df.forward(model, self.tok, finals([self.HAND]), 12, {}, table)
        self.assertEqual(st["skipped"], {"no_operand": 1, "truncated": 2})
        self.assertEqual(st["n"], 0)
        w = DFWindow(3)
        w.add(st)
        self.assertEqual(w.skipped, {"no_operand": 1, "truncated": 2})

    def test_operand_positions_train(self):                                # (c)
        spec = DFSpec((1, 3, 5), lam=0.5, dim=32, pos="operand")
        ces, accs, final, df, model, table = self.overfit(spec)
        self.assertEqual(final, {1: 1.0, 2: 1.0, 3: 1.0}, accs[-3:])
        self.assertLess(ces[-1], ces[0] * 0.5, (ces[0], ces[-1]))
        probe = df.probe(model, self.tok, self.items, 512, 4, {})
        self.assertEqual((probe["pos"], probe["pairs"], probe["acc"]), ("operand", [8, 6, 4], [1.0, 1.0, 1.0]))
        # the read positions are the operands' tokens, not the answer cue: every item's positions differ from last
        from cotdistill.student import collate
        b = collate(self.tok, self.batch, 512, "cpu")
        for i, e in enumerate(self.batch):
            for end in table[e.item_id].ends:
                self.assertLess(token_at(self.tok, e.text, end, 512), int(b["last"][i]))
        # the shuffled control at operand positions: the item's own positions, the partner's values
        sx = DFSpec((1, 3, 5), lam=0.5, dim=32, pos="operand", shuffle=True)
        tx = build_table(self.items, sx)
        self.assertEqual({k: v.ends for k, v in tx.items()}, {k: v.ends for k, v in table.items()})
        self.assertTrue(all(a != b for d in tx.values() for a, b in zip(d.targets, d.values)))

    def test_answer_position_is_last_token(self):                          # (d): pos answer = the previous build
        """--df-pos answer reads b["last"] for every pair: the auxiliary loss equals an independent recomputation of
        the InfoNCE from the captured states at the answer positions (same heads); a sidecar without "pos" (written by
        the build before --df-pos) loads as answer; the default spec is answer."""
        import torch.nn.functional as F
        from cotdistill.student import collate
        model, df, table = self.fresh()
        self.assertEqual(DFSpec((1,)).pos, "answer")
        self.assertEqual(DFSpec.from_dict({"layers": [1, 3, 5]}).pos, "answer")
        self.assertEqual(table["d0"].ends, [])
        model.eval()
        with torch.no_grad():
            z, aux, st = df.forward(model, self.tok, self.batch, 512, {}, table)
            body, _ = text_parts(model)
            b = collate(self.tok, self.batch, 512, "cpu")
            with _Capture(df.dl, df.spec.layers) as cap:
                body(input_ids=b["input_ids"], attention_mask=b["attention_mask"], use_cache=False)
            pairs = [(i, k) for i, e in enumerate(self.batch) for k in range(1, len(table[e.item_id].targets) + 1)]
            anchors = torch.stack([df.heads.head(k)(cap.h[df.layer_of(k)][i, b["last"][i]]) for i, k in pairs])
            strings, allowed, pos = DepthForcing.candidates(self.batch, table, pairs)
            E = F.normalize(df.encode_values(model, self.tok, strings), dim=-1)
            sims = F.normalize(anchors, dim=-1) @ E.T / df.spec.temperature
            losses = []
            for r, (cset, p) in enumerate(zip(allowed, pos)):
                idx = sorted(cset)
                losses.append(F.cross_entropy(sims[r, idx][None], torch.tensor([idx.index(p)])))
            self.assertLess(abs(torch.stack(losses).mean().item() - aux.item()), 1e-6)
            self.assertEqual(st["n"], len(pairs))

    # ---- --df-head-lr (the heads' own optimizer group)
    def test_param_groups(self):                                           # head-lr (a), (b)
        model, df, table = self.fresh()
        params = [p for p in model.parameters() if p.requires_grad]
        self.assertIs(param_groups(params, df.heads, None), params)       # (b): one group, the plain optimizer
        opt0 = torch.optim.AdamW(param_groups(params, df.heads, None), lr=1e-6, weight_decay=0.0)
        self.assertEqual(len(opt0.param_groups), 1)
        self.assertEqual([id(p) for p in opt0.param_groups[0]["params"]], [id(p) for p in params])
        g = param_groups(params, df.heads, 1e-2)                            # (a): two groups
        self.assertEqual(len(g), 2)
        head_ids = [id(p) for p in df.heads.parameters()]
        self.assertEqual([id(p) for p in g[1]["params"]], [id(p) for p in params if id(p) in set(head_ids)])
        self.assertEqual(sorted(id(p) for p in g[1]["params"]), sorted(head_ids))
        self.assertEqual(len(g[1]["params"]), 4)
        self.assertEqual((g[1]["lr"], g[1]["weight_decay"]), (1e-2, 0.0))
        self.assertEqual([id(p) for p in g[0]["params"]], [id(p) for p in params if id(p) not in set(head_ids)])
        self.assertEqual(len(g[0]["params"]) + len(g[1]["params"]), len(params))
        opt = torch.optim.AdamW(g, lr=1e-6, weight_decay=0.0)
        self.assertEqual([pg["lr"] for pg in opt.param_groups], [1e-6, 1e-2])
        self.assertEqual([pg["weight_decay"] for pg in opt.param_groups], [0.0, 0.0])
        # the scheduler scales both groups by the same factor: the ratio stays head / base along the schedule
        import math
        warm, total = 3, 10
        sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda s, w=warm, t=total: min(1.0, (s + 1) / w) * 0.5 * (
            1 + math.cos(math.pi * min(1.0, s / t))))
        for s in range(total):
            base_lr, head_lr = (pg["lr"] for pg in opt.param_groups)
            self.assertAlmostEqual(head_lr / base_lr, 1e4, places=6, msg=s)
            self.assertAlmostEqual(base_lr, 1e-6 * min(1.0, (s + 1) / warm) * 0.5 * (1 + math.cos(math.pi * s / total)), places=12)
            opt.step()
            sched.step()
        with self.assertRaises(ValueError):
            param_groups(params, df.heads, 0.0)
        with self.assertRaises(ValueError):
            param_groups(params[:-4], df.heads, 1e-2)                     # a head parameter not trainable

    def test_sharded_optim_groups(self):
        """--fsdp cpu-adamw (world 1: plain tensors): ShardedOptim with the groups has two param groups with the right
        lr, the clipping still covers every parameter, and a step moves the heads at their own rate."""
        from cotdistill.fsdp import ShardedOptim
        model, df, table = self.fresh()
        params = [p for p in model.parameters() if p.requires_grad]
        g = param_groups(params, df.heads, 1e-2)
        tr = ShardedOptim(params, "cpu-adamw", 1e-6, torch.device("cpu"), groups=g)
        self.assertEqual([pg["lr"] for pg in tr.opt.param_groups], [1e-6, 1e-2])
        self.assertEqual(len(tr.opt.param_groups[1]["params"]), 4)
        self.assertEqual(len(tr.params), len(params))
        tr0 = ShardedOptim(params, "cpu-adamw", 1e-6, torch.device("cpu"))
        self.assertEqual(len(tr0.opt.param_groups), 1)
        before = {n: p.detach().clone() for n, p in model.named_parameters()}
        z, aux, st = df.forward(model, self.tok, self.batch, 512, {}, table)
        (kl_loss(z, self.batch) + 0.5 * aux).backward()
        tr.clip_grad_norm_(1.0)
        tr.step()
        moved = {n: (p.detach() - before[n]).abs().max().item() for n, p in model.named_parameters()}
        self.assertGreater(moved["model.df_heads.heads.0.weight"], 1e-3)   # Adam's first step is about lr per weight
        self.assertLess(moved["model.layers.1.mlp.down_proj.weight"], 1e-5)
        tr.release()

    def test_head_lr_fixes_the_pilot_failure(self):                        # head-lr (c)
        """Base lr 1e-6 (the cluster pilot's regime, j601: aux 3.70 -> 3.65, probe at chance): with --df-head-lr 1e-2
        the probe reaches 1.0 at every layer in 30 steps at operand positions (the operand tokens differ across items,
        so the random tiny model's states there are separable); the same run with the heads at the base lr stays at
        chance. At the answer position the random tiny model's states differ across items by 0.5% of their norm
        (see overfit), so the heads alone cannot separate them in 30 steps: there the check is that the auxiliary loss
        falls from about 4.5 to below 2 with the head rate and stays above 4.3 without it."""
        spec = DFSpec((1, 3, 5), lam=0.5, dim=32, pos="operand")
        _, _, with_head, *_ = self.overfit(spec, lr_heads=1e-2, lr_base=1e-6)
        self.assertEqual(with_head, {1: 1.0, 2: 1.0, 3: 1.0})
        _, accs, without, *_ = self.overfit(spec, lr_heads=1e-6, lr_base=1e-6)
        self.assertLess(max(without.values()), 0.5, without)
        spec_a = DFSpec((1, 3, 5), lam=0.5, dim=32)
        aux_with = self.overfit_aux(spec_a, lr_heads=1e-2, lr_base=1e-6)
        aux_without = self.overfit_aux(spec_a, lr_heads=1e-6, lr_base=1e-6)
        self.assertLess(aux_with[-1], 2.0, aux_with[::10])
        self.assertGreater(aux_without[-1], 4.3, aux_without[::10])

    def overfit_aux(self, spec, steps=30, lr_heads=1e-2, lr_base=1e-3) -> list:
        """The auxiliary loss along the overfit protocol (its last value is a tracked run, not the final re-forward)."""
        model, df, table = self.fresh(spec)
        params = [p for p in model.parameters() if p.requires_grad]
        opt = torch.optim.AdamW(param_groups(params, df.heads, None if lr_heads == lr_base else lr_heads), lr=lr_base,
                                weight_decay=0.0)
        auxs = []
        for _ in range(steps):
            z, aux, st = df.forward(model, self.tok, self.batch, 512, {}, table)
            opt.zero_grad(set_to_none=True)
            (kl_loss(z, self.batch) + spec.lam * aux).backward()
            opt.step()
            auxs.append(aux.detach().item())
        return auxs

    def test_heads_save_and_load(self):                                    # (7, in process)
        model, df, table = self.fresh()
        with torch.no_grad():
            for p in df.heads.parameters():
                p.add_(1.0)
        with tempfile.TemporaryDirectory() as d:
            model.save_pretrained(d, safe_serialization=True)
            from safetensors import safe_open
            with safe_open(d + "/model.safetensors", framework="pt") as fh:
                keys = [k for k in fh.keys() if "df_heads." in k]
            self.assertEqual(len(keys), 4)                                 # save_pretrained keeps the heads
            fresh = transformers.Qwen3_5ForCausalLM.from_pretrained(d)
            self.assertFalse(hasattr(text_parts(fresh)[0], "df_heads"))   # from_pretrained drops them
            df2 = DepthForcing(fresh, DFSpec.from_dict(json.loads(json.dumps(df.spec.as_dict()))))
            src = load_df_heads(text_parts(fresh)[0], d)                   # from model.safetensors
            self.assertTrue(src.endswith("model.safetensors"))
            for a, b in zip(df.heads.parameters(), df2.heads.parameters()):
                self.assertTrue(torch.equal(a, b))
            torch.save(df.heads.state_dict(), Path(d) / DF_HEADS_FILE)
            df3 = DepthForcing(tiny_qwen35(len(self.tok), 5), df.spec)
            self.assertTrue(load_df_heads(text_parts(df3.body)[0] if False else df3.body, d).endswith(DF_HEADS_FILE))
            for a, b in zip(df.heads.parameters(), df3.heads.parameters()):
                self.assertTrue(torch.equal(a, b))


@unittest.skipUnless(HAVE, "needs torch + transformers")
class TestTrainerSmoke(unittest.TestCase):
    """train_student.py / eval_student.py end to end (CPU, tiny Qwen3.5 + GPT-2 tokenizer): DF with --save, the
    sidecar round trip, eval_student's probe; DFX; the token-budget loop; flag validation; and, with COTD_REF_REPO
    (a reference checkout), the plain A2 history bit for bit."""

    @classmethod
    def setUpClass(cls):
        try:
            cls.tok = gpt2_tok()
        except Exception as e:
            raise unittest.SkipTest(f"no local gpt2 tokenizer: {e}")

    def fixture(self, d: str) -> None:
        tiny_qwen35(len(self.tok)).save_pretrained(d + "/m")
        self.tok.save_pretrained(d + "/m")
        items = items8() + [df_item(8, 2, base=900, with_steps=False), df_item(9, 3, base=1000)]
        Path(d + "/t.jsonl").write_text("\n".join(json.dumps(x) for x in items) + "\n")

    def run_train(self, d, out, *extra, script=TRAIN):
        r = subprocess.run([sys.executable, script, "--model", d + "/m", "--train", d + "/t.jsonl",
                            "--eval", "val=" + d + "/t.jsonl", "--final", "teacher", "--subq", "none", "--epochs", "3",
                            "--micro-bs", "5", "--grad-accum", "2", "--max-len", "512", "--eval-max-len", "512",
                            "--precision", "fp32master", "--lr", "1e-3", "--log-every", "1", "--seed", "1", "--out", out,
                            *extra], capture_output=True, text=True, timeout=1200, env=ENV)
        self.assertEqual(r.returncode, 0, r.stderr[-4000:])
        return r, json.loads(Path(out + "/metrics.json").read_text())

    def run_eval(self, d, model_dir, out, *extra):
        r = subprocess.run([sys.executable, EVAL, "--model", model_dir, "--eval", "x=" + d + "/t.jsonl",
                            "--max-len", "512", "--bs", "4", "--out", out, *extra],
                           capture_output=True, text=True, timeout=1200, env=ENV)
        self.assertEqual(r.returncode, 0, r.stderr[-4000:])
        return r, json.loads(Path(out + "/metrics.json").read_text())

    def test_df_train_save_eval(self):                                     # (7)
        with tempfile.TemporaryDirectory() as d:
            self.fixture(d)
            r, m = self.run_train(d, d + "/df", "--df-layers", "1,3,5", "--df-lambda", "0.5", "--df-dim", "32",
                                  "--save")
            self.assertIn("depth forcing: layers [1, 3, 5] (step k <- output of layer k), lambda 0.5, target contrast, "
                          "3 heads, 8192 new parameters", r.stdout)
            self.assertIn("9 of 10 training items have steps; items supervising step k = 1..3: [9, 7, 5]", r.stdout)
            self.assertEqual(len(m["history"]), 3)                         # 3 epochs x 10 items / (5 x 2) = 1 step each
            for row in m["history"]:
                self.assertIn("df_aux", row)
                self.assertIn("loss_df", row)
                self.assertEqual(set(row["df_acc"]), {"1", "2", "3"})
                self.assertEqual(row["df_pairs"], 9 + 7 + 5)
                self.assertAlmostEqual(row["loss_df"], 0.5 * row["df_aux"], places=9)
            dfm = m["df"]
            self.assertEqual((dfm["layers"], dfm["lambda"], dfm["target"], dfm["shuffle"], dfm["n_params"]),
                             ([1, 3, 5], 0.5, "contrast", False, 8192))
            self.assertEqual((dfm["train_items_with_steps"], dfm["items_supervising_k"], dfm["train_pairs_k"]),
                             (9, [9, 7, 5], [27, 21, 15]))
            self.assertEqual(dfm["probe"]["val"]["layers"], [1, 3, 5])
            self.assertEqual(dfm["probe"]["val"]["pairs"], [9, 7, 5])
            self.assertEqual(len(dfm["probe"]["val"]["acc"]), 3)
            self.assertIn("val", m["eval"])
            side = json.loads(Path(d + "/df/" + DF_SIDECAR).read_text())
            self.assertEqual(side, DFSpec((1, 3, 5), lam=0.5, dim=32, seed=1).as_dict())
            self.assertEqual(json.loads(Path(d + "/df/model/" + DF_SIDECAR).read_text()), side)
            self.assertTrue(Path(d + "/df/model/" + DF_HEADS_FILE).exists())
            sd = torch.load(d + "/df/model/" + DF_HEADS_FILE, weights_only=True)
            self.assertEqual(set(sd), {"heads.0.weight", "heads.1.weight", "heads.2.weight", "proj.weight"})
            self.assertEqual(sd["proj.weight"].dtype, torch.bfloat16)
            from safetensors import safe_open
            with safe_open(d + "/df/model/model.safetensors", framework="pt") as fh:
                self.assertEqual(len([k for k in fh.keys() if "df_heads." in k]), 4)
            # eval_student: the sidecar rebuilds the heads; the probe on the set (bf16 weights: close, not equal)
            r2, e = self.run_eval(d, d + "/df/model", d + "/e1")
            self.assertIn("depth forcing (from", r2.stdout)
            self.assertIn("heads from", r2.stdout)
            self.assertEqual(e["df"], side)
            p = e["df_probe"]["x"]
            self.assertEqual((p["layers"], p["pairs"]), ([1, 3, 5], [9, 7, 5]))
            for a, b in zip(p["acc"], dfm["probe"]["val"]["acc"]):
                self.assertAlmostEqual(a, b, delta=0.25)
            self.assertAlmostEqual(e["eval"]["x"]["nll"], m["eval"]["val"]["nll"], delta=0.02)
            _, e0 = self.run_eval(d, d + "/df/model", d + "/e2", "--df-probe", "none")
            self.assertNotIn("df_probe", e0)
            self.assertNotIn("df", e0)

    def test_dfx_and_token_budget(self):
        with tempfile.TemporaryDirectory() as d:
            self.fixture(d)
            r, m = self.run_train(d, d + "/dfx", "--df-layers", "auto", "--df-L0", "0", "--df-stride", "2",
                                  "--df-max-steps", "3", "--df-shuffle", "--df-dim", "32", "--token-budget", "400",
                                  "--token-budget-seqs", "4", "--no-grad-ckpt")
            self.assertIn("SHUFFLED targets (DFX)", r.stdout)
            self.assertIn("depth forcing: layers [2, 4, 6]", r.stdout)
            self.assertTrue(m["df"]["shuffle"])
            self.assertEqual(m["df"]["layers"], [2, 4, 6])
            self.assertEqual(m["df"]["train_pairs_k"], [27, 21, 15])      # the DF arm's counts
            for row in m["history"]:
                self.assertIn("df_acc", row)
                self.assertIn("pad_tok", row)                              # the token-budget loop
            self.assertEqual(m["df"]["probe"]["val"]["pairs"], [9, 7, 5])  # the probe reads the items' own values

    def test_digits_arm(self):
        with tempfile.TemporaryDirectory() as d:
            self.fixture(d)
            r, m = self.run_train(d, d + "/dg", "--df-layers", "1,3", "--df-target", "digits", "--df-shared-head",
                                  "--no-grad-ckpt")
            self.assertIn("target digits, shared head, 4800 new parameters", r.stdout)
            self.assertEqual(m["df"]["probe"]["val"]["cands"], None)
            self.assertEqual(m["df"]["probe"]["val"]["pairs"], [9, 7])

    def test_dfo_arm(self):
        """--df-pos operand end to end: d9's step 2 has no operand in the question (counted), the others are read at
        their operand tokens; the sidecar carries pos and eval_student's probe reports it."""
        with tempfile.TemporaryDirectory() as d:
            self.fixture(d)
            items = [json.loads(l) for l in Path(d + "/t.jsonl").read_text().splitlines()]
            items[-1]["worked_steps"][1].update(a="999999", b="888888")    # d9: step 2 not computable from the question
            Path(d + "/t.jsonl").write_text("\n".join(json.dumps(x) for x in items) + "\n")
            r, m = self.run_train(d, d + "/dfo", "--df-layers", "1,3,5", "--df-pos", "operand", "--df-dim", "32",
                                  "--save")
            self.assertIn("items supervising step k = 1..3: [9, 6, 5]; steps without an operand position: [0, 1, 0]",
                          r.stdout)
            dfm = m["df"]
            self.assertEqual((dfm["pos"], dfm["items_supervising_k"], dfm["no_operand_position"]),
                             ("operand", [9, 6, 5], [0, 1, 0]))
            self.assertEqual((dfm["train_pairs_k"], dfm["train_skipped"]), ([27, 18, 15], {"no_operand": 3, "truncated": 0}))
            self.assertEqual(dfm["probe"]["val"]["pos"], "operand")
            self.assertEqual((dfm["probe"]["val"]["pairs"], dfm["probe"]["val"]["no_operand_position"]), ([9, 6, 5], [0, 1, 0]))
            for row in m["history"]:
                self.assertEqual(row["df_pairs"], 9 + 6 + 5)
            side = json.loads(Path(d + "/dfo/model/" + DF_SIDECAR).read_text())
            self.assertEqual(side["pos"], "operand")
            r2, e = self.run_eval(d, d + "/dfo/model", d + "/e")
            self.assertEqual(e["df"]["pos"], "operand")
            self.assertEqual((e["df_probe"]["x"]["pos"], e["df_probe"]["x"]["pairs"]), ("operand", [9, 6, 5]))
            _, mx = self.run_train(d, d + "/dfox", "--df-layers", "1,3,5", "--df-pos", "operand", "--df-shuffle",
                                   "--df-dim", "32", "--no-grad-ckpt")
            self.assertEqual((mx["df"]["pos"], mx["df"]["shuffle"], mx["df"]["train_pairs_k"]),
                             ("operand", True, [27, 18, 15]))

    def test_df_head_lr_arm(self):
        """--df-head-lr end to end (operand positions, where the random tiny model's states are separable): the banner
        and the metrics record it; at base lr 1e-6 the heads learn (the probe rises, df_aux falls) where the same run
        without the flag stays flat."""
        with tempfile.TemporaryDirectory() as d:
            self.fixture(d)
            r, m = self.run_train(d, d + "/hl", "--df-layers", "1,3,5", "--df-dim", "32", "--lr", "1e-6",
                                  "--df-pos", "operand", "--df-head-lr", "0.02", "--epochs", "12", "--no-grad-ckpt")
            self.assertIn("head lr 0.02", r.stdout)
            self.assertEqual((m["df"]["head_lr"], m["df"]["head_lr_own_group"]), (0.02, True))
            self.assertEqual(m["args"]["df_head_lr"], 0.02)
            _, m0 = self.run_train(d, d + "/h0", "--df-layers", "1,3,5", "--df-dim", "32", "--lr", "1e-6",
                                   "--df-pos", "operand", "--epochs", "12", "--no-grad-ckpt")
            self.assertEqual((m0["df"]["head_lr"], m0["df"]["head_lr_own_group"]), (1e-6, False))
            # The auxiliary loss is the learning signal (4.8 -> about 1.4 with the flag, 4.8 -> 4.7 without; margin 0.5).
            # The val probe has only 9 / 7 / 5 pairs and the random tiny model's answer-position states barely differ
            # across items (see the note on test 5), so its accuracy is a coarse second check: 0.30 vs 0.09 on torch
            # 2.14 CPU (2026-10-24), margin 0.15, not 0.3.
            self.assertLess(m["history"][-1]["df_aux"], m0["history"][-1]["df_aux"] - 0.5,
                            (m["history"][-1]["df_aux"], m0["history"][-1]["df_aux"]))
            # the head diagnostics: the scheduled head lr as the optimizer holds it, the weights move, they get gradient
            import math
            for i, row in enumerate(m["history"]):
                s, w, t = row["step"], max(1, int(0.05 * 12)), 12
                want = 0.02 * min(1.0, (s + 1) / w) * 0.5 * (1 + math.cos(math.pi * min(1.0, s / t)))
                self.assertAlmostEqual(row["df_head_lr_now"], want, places=9, msg=row)
                self.assertGreater(row["df_head_gnorm"], 0.0, row)
                self.assertGreater(row["df_head_norm"], 0.0, row)
                if i and row["df_head_lr_now"] > 1e-3:
                    self.assertGreater(row["df_head_delta"], 1e-2, row)          # about lr x sqrt(params) per step
            self.assertIsNone(m["history"][0]["df_head_delta"])
            self.assertEqual(m["history"][-1]["df_head_lr_now"], 0.0)                 # the cosine's end
            for i, row in enumerate(m0["history"]):
                self.assertLess(row["df_head_lr_now"], 1e-6 + 1e-12, row)             # the base lr (one group)
                if i:
                    self.assertLess(row["df_head_delta"], 1e-3, row)
            acc = lambda mm: sum(mm["df"]["probe"]["val"]["acc"]) / 3
            self.assertGreater(acc(m), acc(m0) + 0.15, (m["df"]["probe"]["val"]["acc"], m0["df"]["probe"]["val"]["acc"]))

    def test_a2_history_unchanged_against_reference(self):                 # (1), trainer level
        ref = os.environ.get("COTD_REF_REPO")
        if not ref or not Path(ref, "scripts/train_student.py").exists():
            raise unittest.SkipTest("set COTD_REF_REPO to a reference checkout")
        with tempfile.TemporaryDirectory() as d:
            self.fixture(d)
            _, new = self.run_train(d, d + "/new", "--no-grad-ckpt")
            _, old = self.run_train(d, d + "/old", "--no-grad-ckpt", script=str(Path(ref, "scripts/train_student.py")))
            self.assertEqual([r["loss"] for r in new["history"]], [r["loss"] for r in old["history"]])
            self.assertEqual(new["eval"]["val"], old["eval"]["val"])
            self.assertNotIn("df", new)
            self.assertNotIn("df_aux", new["history"][0])

    def test_flag_validation(self):
        with tempfile.TemporaryDirectory() as d:
            self.fixture(d)
            for extra, msg in ((["--df-lambda", "0.1"], "need --df-layers"),
                               (["--df-layers", "7"], "out of 0..6"),
                               (["--df-layers", "1", "--loop-layers", "2-3"], "--loop-layers (the layer indices shift)"),
                               (["--df-layers", "1", "--subq", "cot"], "--subq none"),
                               (["--df-layers", "1", "--lora-r", "2"], "the heads would be frozen"),
                               (["--df-layers", "1,1"], "distinct layers"),
                               (["--df-layers", "1", "--df-temperature", "0"], "--df-temperature > 0"),
                               (["--df-layers", "1", "--df-target", "x"], "invalid choice"),
                               (["--df-pos", "operand"], "need --df-layers"),
                               (["--df-head-lr", "1e-3"], "need --df-layers"),
                               (["--df-layers", "1", "--df-head-lr", "0"], "--df-head-lr 0.0: > 0"),
                               (["--df-layers", "1", "--df-pos", "operand", "--chat-template"], "no --chat-template")):
                r = subprocess.run([sys.executable, TRAIN, "--model", d + "/m", "--train", d + "/t.jsonl",
                                    "--epochs", "1", "--out", d + "/o", *extra], capture_output=True, text=True,
                                   timeout=900, env=ENV)
                self.assertNotEqual(r.returncode, 0, extra)
                self.assertIn(msg, r.stderr, extra)


@unittest.skipUnless(HAVE, "needs torch + transformers")
class TestFSDPWorld1(unittest.TestCase):
    """The cluster path on the CPU: FSDP2 (gloo, world 1) around the tiny model with the heads built before sharding,
    non-reentrant gradient checkpointing, the forward through Readout.run (df.call), fsdp_update's loss, ShardedOptim
    cpu-adamw with the head group, LambdaLR. Checks that the heads' sharded parameters receive non-zero gradients, that
    the captures equal the unsharded model's layer outputs, that one step moves the heads by about their own lr and
    the base by about its lr, that the scheduler scales both groups alike, and that 30 updates at base lr 1e-6 /
    head lr 1e-2 bring the probe to 1.0 at operand positions (bf16 weights, as --precision bf16)."""

    @classmethod
    def setUpClass(cls):
        try:
            cls.tok = gpt2_tok()
        except Exception as e:
            raise unittest.SkipTest(f"no local gpt2 tokenizer: {e}")
        import torch.distributed as dist
        if dist.is_initialized():
            raise unittest.SkipTest("a process group is already up")
        os.environ.update(RANK="0", WORLD_SIZE="1", LOCAL_RANK="0", MASTER_ADDR="127.0.0.1",
                          MASTER_PORT=str(29600 + os.getpid() % 300))
        from cotdistill import fsdp as fsdp_lib
        cls.fs = fsdp_lib.init(timeout_min=2.0)
        cls.items = items8()
        cls.batch = finals(cls.items)

    @classmethod
    def tearDownClass(cls):
        import torch.distributed as dist
        if dist.is_initialized():
            dist.destroy_process_group()

    def build(self, spec, dtype=torch.float32, ckpt=True):
        from cotdistill import fsdp as fsdp_lib
        model = tiny_qwen35(len(self.tok)).to(dtype)
        model.config.use_cache = False
        if ckpt:
            model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
        df = DepthForcing(model, spec)                         # before sharding, as the trainer does
        root = fsdp_lib.shard_model(model, self.fs.mesh)
        root.train()
        return model, df, root, build_table(self.items, spec)

    def test_heads_get_gradients_and_move_at_their_lr(self):
        from cotdistill.fsdp import ShardedOptim, _local
        spec = DFSpec((1, 3, 5), lam=0.5, dim=32, pos="operand")
        model, df, root, table = self.build(spec)
        params = [p for p in root.parameters() if p.requires_grad]
        head_ids = {id(p) for p in df.heads.parameters()}
        self.assertEqual(len([p for p in params if id(p) in head_ids]), 4)       # the sharded heads are in params
        self.assertTrue(all(hasattr(p, "to_local") for p in params))            # DTensors (sharded)
        groups = param_groups(params, df.heads, 1e-2)
        tr = ShardedOptim(params, "cpu-adamw", 1e-6, self.fs.device, groups=groups)
        self.assertEqual([g["lr"] for g in tr.opt.param_groups], [1e-6, 1e-2])
        # the captures inside the FSDP root forward equal the plain (unsharded-copy) model's layer outputs
        plain = tiny_qwen35(len(self.tok))
        plain.load_state_dict({k: _local(v) for k, v in model.state_dict().items()}, strict=False)
        from cotdistill.student import collate
        b = collate(self.tok, self.batch, 512, "cpu")
        with torch.no_grad(), _Capture(body_layers(text_parts(plain)[0]), spec.layers) as cap_ref:
            text_parts(plain)[0](input_ids=b["input_ids"], attention_mask=b["attention_mask"], use_cache=False)
        seen = {}

        def record(li):                                          # the states the FSDP forward hands to layer li + 1
            def pre(mod, args, kwargs):
                seen.setdefault(li, (args[0] if args else kwargs["hidden_states"]).detach().clone())
            return pre
        hooks = [df.dl[li + 1].register_forward_pre_hook(record(li), with_kwargs=True) for li in spec.layers]
        z, aux, st = df.call(root, self.tok, self.batch, 512, {}, table)
        for h in hooks:
            h.remove()
        for li in spec.layers:
            self.assertTrue(torch.allclose(seen[li], cap_ref.h[li], atol=1e-5), li)
        self.assertEqual(st["n"], 8 + 6 + 4)
        loss = (kl_loss(z, self.batch) * len(self.batch) + 0.5 * aux * len(self.batch)) / len(self.batch)   # fsdp_update
        loss.backward()
        for p in params:
            self.assertIsNotNone(p.grad)
        hg = [p for p in params if id(p) in head_ids]
        self.assertTrue(all(_local(p.grad).abs().sum() > 0 for p in hg))      # non-zero head gradients
        before = {id(p): _local(p).detach().clone() for p in params}
        tr.clip_grad_norm_(1.0)
        tr.step()
        tr.zero_grad()
        moved_h = max((_local(p).detach() - before[id(p)]).abs().max().item() for p in hg)
        moved_b = max((_local(p).detach() - before[id(p)]).abs().max().item() for p in params if id(p) not in head_ids)
        self.assertGreater(moved_h, 3e-3)                                        # about lr 1e-2 (Adam's first step)
        self.assertLess(moved_b, 3e-6)                                           # about lr 1e-6
        import math
        sched = torch.optim.lr_scheduler.LambdaLR(tr.opt, lambda s, w=3, t=30: min(1.0, (s + 1) / w) * 0.5 * (
            1 + math.cos(math.pi * min(1.0, s / t))))
        for _ in range(5):
            sched.step()
        lrs = [g["lr"] for g in tr.opt.param_groups]
        self.assertAlmostEqual(lrs[1] / lrs[0], 1e4, places=6)
        tr.release()

    def test_bf16_training_reaches_probe_one(self):
        """bf16 weights (--precision bf16) + cpu-adamw fp32 masters: 30 updates, base lr 1e-6, head lr 1e-2, operand
        positions -> probe 1.0 at every layer; the same at head lr 1e-6 stays at chance."""
        from cotdistill.fsdp import ShardedOptim

        def run(head_lr):
            spec = DFSpec((1, 3, 5), lam=0.5, dim=32, pos="operand")
            model, df, root, table = self.build(spec, dtype=torch.bfloat16)
            params = [p for p in root.parameters() if p.requires_grad]
            tr = ShardedOptim(params, "cpu-adamw", 1e-6, self.fs.device, groups=param_groups(params, df.heads, head_lr))
            auxs = []
            for _ in range(30):
                z, aux, st = df.call(root, self.tok, self.batch, 512, {}, table)
                loss = (kl_loss(z, self.batch) * len(self.batch) + 0.5 * aux * len(self.batch)) / len(self.batch)
                loss.backward()
                tr.clip_grad_norm_(1.0)
                tr.step()
                tr.zero_grad()
                auxs.append(st["aux"])
            with torch.no_grad():
                z, aux, st = df.call(root, self.tok, self.batch, 512, {}, table)
            tr.release()
            return {k: c / n for k, (c, n) in st["per_k"].items() if n}, auxs
        acc, auxs = run(1e-2)
        self.assertGreaterEqual(sum(acc.values()) / 3, 0.9, (acc, auxs[::10]))   # bf16 states: 1.0, 1.0 and >= 7/8
        self.assertEqual((acc[2], acc[3]), (1.0, 1.0), acc)
        self.assertLess(auxs[-1], 0.5, auxs[::10])
        acc0, auxs0 = run(None)
        self.assertLess(max(acc0.values()), 0.5, acc0)
        self.assertGreater(auxs0[-1], 3.5, auxs0[::10])


if __name__ == "__main__":
    unittest.main()
