"""LayerLoop (src/cotdistill/student.py; train_student.py / eval_student.py --loop-layers; arms LOOP, LOOP-MIX,
LOOP-UNTIED): a contiguous block of decoder layers re-applied T - 1 extra times inside one forward. CPU, float32, a
tiny random Qwen3.5 text model (8 layers, full attention at 3 and 7, the rest Gated DeltaNet) so the linear and the
full-attention layers get different masks, as on Qwen3.5-4B. Checks: T = 1 is bit-identical to no hook; T = 2, the
damped update and T = 3 equal a manual re-application with the recorded per-layer kwargs; the untied copies are new
parameters that start equal to the originals and receive gradients only through the extra pass; gradients reach the
window with and without the model's gradient checkpointing; the LOOP-MIX draw is deterministic and uniform; the
recorded masks differ by layer type; sidecar round trip; re-entrancy; the saved copies load back the way
eval_student.py does it; the FSDP helper sees the copies; and a trainer-level smoke of train_student.py +
eval_student.py on the repo's tiny Qwen2 fixture (subprocess, as tests/test_eval_mid_preds.py)."""
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "tests"))

try:
    import torch
    import transformers
    from cotdistill.fsdp import decoder_layers
    from cotdistill.student import (LOOP_SIDECAR, Example, LayerLoop, body_layers, draw_loop_T, load_loop_untied,
                                    load_model, loop_rms_summary, loop_spec_from_dict, loop_spec_to_dict,
                                    parse_loop_Ts, parse_loop_layers, text_parts)
    HAVE = True
except ImportError:
    HAVE = False

ENV = {**os.environ, "CUDA_VISIBLE_DEVICES": "", "OMP_NUM_THREADS": "2"}
TRAIN = str(ROOT / "scripts/train_student.py")
EVAL = str(ROOT / "scripts/eval_student.py")
LAYER_TYPES = ["linear_attention"] * 3 + ["full_attention"] + ["linear_attention"] * 3 + ["full_attention"]


def tiny_qwen35(seed: int = 0):
    """A random Qwen3.5 text model: hidden 64, 8 layers, full attention at 3 and 7 (as Qwen3.5-4B's 3, 7, ...)."""
    cfg = transformers.Qwen3_5TextConfig(vocab_size=300, hidden_size=64, intermediate_size=128, num_hidden_layers=8,
                                         num_attention_heads=4, num_key_value_heads=2, head_dim=16,
                                         layer_types=list(LAYER_TYPES), linear_num_value_heads=4, linear_num_key_heads=2,
                                         linear_key_head_dim=16, linear_value_head_dim=16, linear_conv_kernel_dim=4,
                                         max_position_embeddings=512, tie_word_embeddings=True)
    torch.manual_seed(seed)
    return transformers.Qwen3_5ForCausalLM(cfg)


def batch(seed: int = 1, n: int = 2, L: int = 12, pad: int = 3):
    """input ids and an attention mask with `pad` left pads on the second row (so the masks are real tensors)."""
    g = torch.Generator().manual_seed(seed)
    ids = torch.randint(3, 300, (n, L), generator=g)
    am = torch.ones(n, L, dtype=torch.long)
    if pad:
        am[1, :pad] = 0
    return ids, am


def record_pass(model, ids, am):
    """One plain forward with recording hooks on every layer: (logits, {layer: kwargs}, {layer: input})."""
    body, _ = text_parts(model)
    rec, h0, hs = {}, {}, []
    for li, lay in enumerate(body_layers(body)):
        def pre(mod, args, kwargs, li=li):
            rec[li] = {k: v for k, v in kwargs.items() if k != "hidden_states"}
            h0[li] = args[0] if args else kwargs["hidden_states"]
        hs.append(lay.register_forward_pre_hook(pre, with_kwargs=True))
    try:
        out = model(input_ids=ids, attention_mask=am, use_cache=False).logits
    finally:
        for hd in hs:
            hd.remove()
    return out, rec, h0


def manual(model, rec, h0, lo, hi, T, alpha, block=None):
    """The looped network computed by hand from the recorded pass-1 kwargs: layers 0..n-1 in order, and before layer
    hi + 1 the T - 1 extra passes of the block (block: the modules to use; default the layers themselves)."""
    body, head = text_parts(model)
    dl = body_layers(body)
    block = block or dl[lo:hi + 1]
    h = h0[0]
    for li in range(len(dl)):
        if li == hi + 1:
            for _ in range(T - 1):
                y = h
                for j, lj in enumerate(range(lo, hi + 1)):
                    y = block[j](y, **rec[lj])
                h = y if alpha == 1.0 else h + alpha * (y - h)
        h = dl[li](h, **rec[li])
    return head(body.norm(h))


def toy_examples(n: int):
    return [Example(f"Case {i}.", ["A", "B"], [1.0, 0.0], 1.0, "final", f"t{i}") for i in range(n)]


@unittest.skipUnless(HAVE, "needs torch + transformers")
class TestLoopForward(unittest.TestCase):
    def setUp(self):
        self.model = tiny_qwen35().eval()
        self.body, _ = text_parts(self.model)
        self.ids, self.am = batch()
        with torch.no_grad():
            self.ref, self.rec, self.h0 = record_pass(self.model, self.ids, self.am)
            self.man = {(T, a): manual(self.model, self.rec, self.h0, 2, 5, T, a)
                        for T, a in ((1, 1.0), (2, 1.0), (2, 0.5), (3, 1.0))}

    def test_manual_T1_is_the_model(self):
        self.assertTrue(torch.equal(self.man[(1, 1.0)], self.ref))

    def test_T1_bit_identical(self):
        for train in (False, True):
            self.model.train(train)
            with LayerLoop(self.body, 2, 5, T=1) as loop:
                with torch.no_grad():
                    out = self.model(input_ids=self.ids, attention_mask=self.am, use_cache=False).logits
                self.assertEqual(loop.counts, {1: 1})
            self.assertTrue(torch.equal(out, self.ref), f"train={train}")
        self.model.eval()

    def test_T2_equals_manual(self):
        with LayerLoop(self.body, 2, 5, T=2, log=[]) as loop, torch.no_grad():
            out = self.model(input_ids=self.ids, attention_mask=self.am, use_cache=False).logits
        self.assertLess((out - self.man[(2, 1.0)]).abs().max().item(), 1e-5)
        self.assertGreater((out - self.ref).abs().max().item(), 1e-3)     # the loop changes the output
        self.assertEqual(loop.counts, {2: 1})
        self.assertEqual(len(loop.log), 1)
        self.assertEqual(len(loop.log[0]), 2)                             # RMS of pass 1 and of the extra pass
        self.assertTrue(all(r > 0 for r in loop.log[0]))
        s = loop_rms_summary(loop.log)
        self.assertEqual((s["n"], len(s["mean_pass"])), (1, 2))
        self.assertAlmostEqual(s["max_ratio_2_1"], loop.log[0][1] / loop.log[0][0], places=4)

    def test_alpha_damped(self):
        with LayerLoop(self.body, 2, 5, T=2, alpha=0.5) as loop, torch.no_grad():
            out = self.model(input_ids=self.ids, attention_mask=self.am, use_cache=False).logits
        self.assertLess((out - self.man[(2, 0.5)]).abs().max().item(), 1e-5)
        self.assertGreater((out - self.man[(2, 1.0)]).abs().max().item(), 1e-4)
        self.assertEqual(loop.counts, {2: 1})

    def test_T3_two_extra_passes(self):
        with LayerLoop(self.body, 2, 5, T=3, log=[]) as loop, torch.no_grad():
            out = self.model(input_ids=self.ids, attention_mask=self.am, use_cache=False).logits
        self.assertLess((out - self.man[(3, 1.0)]).abs().max().item(), 1e-5)
        self.assertEqual(loop.counts, {3: 1})
        self.assertEqual(len(loop.log[0]), 3)

    def test_T_mutable_and_new_forward_rerecords(self):
        """T changes between forwards; a second forward of another length re-records the kwargs (new shapes)."""
        with LayerLoop(self.body, 2, 5, T=2) as loop, torch.no_grad():
            self.model(input_ids=self.ids, attention_mask=self.am, use_cache=False)
            loop.T = 1
            out1 = self.model(input_ids=self.ids, attention_mask=self.am, use_cache=False).logits
            loop.T = 2
            ids2, am2 = batch(seed=5, n=3, L=7, pad=2)
            ref2, rec2, h02 = record_pass(self.model, ids2, am2)      # the loop is installed: rec2 is its pass 1
            self.assertEqual(loop.counts, {2: 2, 1: 1})         # T=2, T=1, T=2 (record_pass)
            self.assertEqual(loop.kw[3]["attention_mask"].shape[-1], 7)
        self.assertTrue(torch.equal(out1, self.ref))
        with torch.no_grad():
            man2 = manual(self.model, rec2, h02, 2, 5, 2, 1.0)
        self.assertLess((ref2 - man2).abs().max().item(), 1e-5)

    def test_recorded_masks_by_layer_type(self):
        """The linear layers (2, 4, 5) get the recurrent mask, the full-attention layer 3 the causal mask: different
        objects, as the model built them (padding makes both real tensors)."""
        with LayerLoop(self.body, 2, 5, T=2) as loop, torch.no_grad():
            self.model(input_ids=self.ids, attention_mask=self.am, use_cache=False)
            kw = {li: dict(loop.kw[li]) for li in range(2, 6)}
        self.assertEqual(sorted(kw), [2, 3, 4, 5])
        full, lin = kw[3]["attention_mask"], kw[2]["attention_mask"]
        self.assertIsNotNone(full)
        self.assertIsNotNone(lin)
        self.assertIsNot(full, lin)
        self.assertEqual(full.dim(), 4)                 # [batch, 1, q, k] causal mask
        self.assertEqual(lin.dim(), 2)                  # [batch, k] recurrent (padding) mask
        for li in (4, 5):
            self.assertIs(kw[li]["attention_mask"], lin)
        for li in range(2, 6):                          # the same kwarg names as an outside hook records
            self.assertEqual(sorted(kw[li]), sorted(self.rec[li]))
            self.assertIsNone(kw[li]["past_key_values"])
            self.assertFalse(kw[li]["use_cache"])

    def test_cache_refused(self):
        with LayerLoop(self.body, 2, 5, T=2), torch.no_grad():
            with self.assertRaises(RuntimeError):
                self.model(input_ids=self.ids, attention_mask=self.am, use_cache=True)

    def test_validation(self):
        LayerLoop(self.body, 0, 6, T=1)                 # hi = n - 2 is the last legal window end
        for lo, hi, T, a in ((0, 7, 2, 1.0), (3, 2, 2, 1.0), (-1, 2, 2, 1.0), (2, 5, 0, 1.0), (2, 5, 2, 0.0),
                             (2, 5, 2, 1.5)):
            with self.assertRaises(ValueError, msg=(lo, hi, T, a)):
                LayerLoop(self.body, lo, hi, T=T, alpha=a)

    def test_reentrancy(self):
        loop = LayerLoop(self.body, 2, 5, T=2).install()
        with self.assertRaises(RuntimeError):
            loop.install()
        loop.remove()
        loop.remove()                                   # a second remove is a no-op
        self.assertFalse(loop.installed)
        with torch.no_grad():
            out = self.model(input_ids=self.ids, attention_mask=self.am, use_cache=False).logits
        self.assertTrue(torch.equal(out, self.ref))      # nothing left behind
        loop.install()                                  # re-installable after remove
        self.assertTrue(loop.installed)
        loop.remove()
        self.assertEqual(sum(len(l._forward_pre_hooks) for l in body_layers(self.body)), 0)


@unittest.skipUnless(HAVE, "needs torch + transformers")
class TestLoopTraining(unittest.TestCase):
    def loss_and_grads(self, model, loop_kw, ckpt: bool):
        """One training forward/backward at the loop's T: (loss, {name: grad} of the window + neighbours)."""
        body, _ = text_parts(model)
        model.train()
        model.zero_grad(set_to_none=True)
        if ckpt:
            model.gradient_checkpointing_enable()
        try:
            ids, am = batch()
            with LayerLoop(body, 2, 5, **loop_kw) as loop:
                dl = body_layers(body)
                if ckpt:                                # the window and hi + 1 run unchecked, the others checked
                    self.assertTrue(all(not dl[li].gradient_checkpointing for li in range(2, 7)))
                    self.assertTrue(all(dl[li].gradient_checkpointing for li in (0, 1, 7)))
                    if loop.untied:
                        self.assertTrue(all(not m.gradient_checkpointing for m in body.loop_untied))
                z = model(input_ids=ids, attention_mask=am, use_cache=False).logits
                loss = z[:, -1].logsumexp(-1).mean() - z[:, -1, 7].mean()
                loss.backward()
            if ckpt:                                    # restored on remove
                self.assertTrue(all(dl[li].gradient_checkpointing for li in range(8)))
            grads = {n: p.grad.detach().clone() for n, p in body.named_parameters() if p.grad is not None}
        finally:
            if ckpt:
                model.gradient_checkpointing_disable()
            model.eval()
        return loss.detach(), grads

    def test_gradients_reach_the_window_with_and_without_checkpointing(self):
        model = tiny_qwen35()
        res = {c: self.loss_and_grads(model, dict(T=2), c) for c in (False, True)}
        for c, (loss, grads) in res.items():
            for li in range(2, 6):
                names = [n for n in grads if n.startswith(f"layers.{li}.")]
                self.assertTrue(names, (c, li))
                self.assertTrue(any(grads[n].abs().sum() > 0 for n in names), (c, li))
        self.assertTrue(torch.allclose(res[False][0], res[True][0], atol=1e-6))
        self.assertEqual(sorted(res[False][1]), sorted(res[True][1]))
        for n in res[False][1]:
            self.assertTrue(torch.allclose(res[False][1][n], res[True][1][n], atol=1e-5, rtol=1e-4), n)

    def test_T2_gradient_differs_from_T1(self):
        model = tiny_qwen35()
        g1 = self.loss_and_grads(model, dict(T=1), False)[1]
        g2 = self.loss_and_grads(model, dict(T=2), False)[1]
        self.assertFalse(torch.allclose(g1["layers.3.mlp.down_proj.weight"], g2["layers.3.mlp.down_proj.weight"]))

    def test_untied(self):
        model = tiny_qwen35().eval()
        body, _ = text_parts(model)
        ids, am = batch()
        with torch.no_grad():
            ref, rec, h0 = record_pass(model, ids, am)
            tied = manual(model, rec, h0, 2, 5, 2, 1.0)
        loop = LayerLoop(body, 2, 5, T=2, untied=True)
        copies = body.loop_untied
        self.assertIsInstance(copies, torch.nn.ModuleList)
        self.assertEqual(len(copies), 4)
        self.assertEqual(len(body_layers(body)), 8)                      # the copies are not decoder layers
        self.assertEqual(len(decoder_layers(body)), 12)                  # but fsdp.shard_model sees them
        orig = body_layers(body)[2:6]
        for c, o in zip(copies, orig):
            self.assertEqual(type(c), type(o))
            self.assertEqual(c.block_type, o.block_type)
            for (nc, pc), (no, po) in zip(c.named_parameters(), o.named_parameters()):
                self.assertEqual(nc, no)
                self.assertNotEqual(pc.data_ptr(), po.data_ptr())
                self.assertTrue(torch.equal(pc, po))
        self.assertIn("loop_untied.0.mlp.down_proj.weight", dict(body.named_parameters()))
        with loop, torch.no_grad():
            out = model(input_ids=ids, attention_mask=am, use_cache=False).logits
        self.assertLess((out - tied).abs().max().item(), 1e-5)         # copies start equal: the tied output
        # the copies get gradients only through the extra pass: T = 1 none, T = 2 yes; the originals in both cases
        model.train()
        for T, expect in ((1, False), (2, True)):
            model.zero_grad(set_to_none=True)
            loop.T = T
            with loop:
                z = model(input_ids=ids, attention_mask=am, use_cache=False).logits
                (z[:, -1].logsumexp(-1).mean() - z[:, -1, 7].mean()).backward()
            cg = [p.grad for p in copies.parameters()]
            self.assertEqual(any(g is not None and g.abs().sum() > 0 for g in cg), expect, T)
            self.assertTrue(any(p.grad is not None and p.grad.abs().sum() > 0 for p in orig[0].parameters()), T)
        # one optimizer step on the extra pass's parameters alone moves the copies and not the originals
        before = {n: p.detach().clone() for n, p in body.named_parameters()}
        opt = torch.optim.SGD(copies.parameters(), lr=0.1)
        opt.step()
        after = dict(body.named_parameters())
        for n in before:
            moved = not torch.equal(before[n], after[n])
            self.assertEqual(moved, n.startswith("loop_untied.") and after[n].grad is not None and
                             bool(after[n].grad.abs().sum() > 0), n)
        # a second LayerLoop on the same body reuses the copies (no second deep copy)
        loop2 = LayerLoop(body, 2, 5, T=2, untied=True)
        self.assertIs(loop2.block[0], copies[0])
        with self.assertRaises(ValueError):
            LayerLoop(body, 1, 5, T=2, untied=True)                      # another window: wrong copy count
        model.eval()

    def test_untied_save_and_reload_as_eval_student(self):
        """save_pretrained writes loop_untied.*; from_pretrained drops them; LayerLoop(untied) + load_loop_untied
        restores them: the reloaded looped logits equal the saved model's."""
        model = tiny_qwen35().eval()
        body, _ = text_parts(model)
        ids, am = batch()
        loop = LayerLoop(body, 2, 5, T=2, untied=True)
        with torch.no_grad():
            for p in body.loop_untied.parameters():                      # make the copies differ from the originals
                p.add_(0.01 * torch.randn_like(p))
            with loop:
                want = model(input_ids=ids, attention_mask=am, use_cache=False).logits
        with tempfile.TemporaryDirectory() as d:
            model.save_pretrained(d, safe_serialization=True)
            from safetensors import safe_open
            with safe_open(d + "/model.safetensors", framework="pt") as fh:
                keys = [k for k in fh.keys() if "loop_untied." in k]
            self.assertEqual(len(keys), sum(1 for _ in body.loop_untied.state_dict()))
            m2 = load_model(d, torch.float32)
            b2, _ = text_parts(m2)
            self.assertFalse(hasattr(b2, "loop_untied"))
            with self.assertRaises(ValueError):                          # copies must exist before the load
                load_loop_untied(b2, d)
            loop2 = LayerLoop(b2, 2, 5, T=2, untied=True)
            n = load_loop_untied(b2, d)
            self.assertEqual(n, len(keys))
            for pc, po in zip(b2.loop_untied.parameters(), body.loop_untied.parameters()):
                self.assertTrue(torch.equal(pc, po))
            with loop2, torch.no_grad():
                got = m2(input_ids=ids, attention_mask=am, use_cache=False).logits
            self.assertTrue(torch.allclose(got, want, atol=1e-6))
            # a plain checkpoint (no copies) refuses: not a LOOP-UNTIED model
            m3 = tiny_qwen35()
            m3.save_pretrained(d + "/plain", safe_serialization=True)
            b3, _ = text_parts(m3)
            LayerLoop(b3, 2, 5, T=2, untied=True)
            with self.assertRaises(ValueError):
                load_loop_untied(b3, d + "/plain")


@unittest.skipUnless(HAVE, "needs torch")
class TestHelpers(unittest.TestCase):
    def test_draw_loop_T_deterministic_and_uniform(self):
        exs = toy_examples(4)
        a = draw_loop_T(0, 3, exs, (1, 2))
        self.assertEqual(a, draw_loop_T(0, 3, list(reversed(exs)), (2, 1)))   # order of the items, of the choices
        self.assertEqual(a, draw_loop_T(0, 3, exs, [1, 2]))
        self.assertIn(a, (1, 2))
        draws = [draw_loop_T(0, s, exs, (1, 2)) for s in range(2000)]
        self.assertTrue(0.45 * 2000 < draws.count(2) < 0.55 * 2000, draws.count(2))
        draws3 = [draw_loop_T(7, s, exs, (1, 2, 3)) for s in range(3000)]
        for t in (1, 2, 3):
            self.assertTrue(0.28 * 3000 < draws3.count(t) < 0.39 * 3000, (t, draws3.count(t)))
        # the key: seed, step, items and the salt all matter; the index of the micro-batch does not exist
        self.assertTrue(any(draw_loop_T(1, s, exs, (1, 2)) != draw_loop_T(0, s, exs, (1, 2)) for s in range(50)))
        self.assertTrue(any(draw_loop_T(0, s, exs, (1, 2), "mb1") != draw_loop_T(0, s, exs, (1, 2), "mb0")
                            for s in range(50)))
        self.assertTrue(any(draw_loop_T(0, s, toy_examples(3), (1, 2)) != draw_loop_T(0, s, exs, (1, 2))
                            for s in range(50)))
        with self.assertRaises(ValueError):
            draw_loop_T(0, 0, exs, ())

    def test_parsers(self):
        self.assertEqual(parse_loop_layers("16-19"), (16, 19))
        self.assertEqual(parse_loop_layers(" 4 "), (4, 4))
        for bad in ("19-16", "a-b", "-1-3", ""):
            with self.assertRaises(ValueError, msg=bad):
                parse_loop_layers(bad)
        self.assertEqual(parse_loop_Ts("2,1,2"), (1, 2))
        self.assertEqual(parse_loop_Ts(""), ())
        for bad in ("0,1", "x"):
            with self.assertRaises(ValueError, msg=bad):
                parse_loop_Ts(bad)

    def test_sidecar_round_trip(self):
        spec = loop_spec_to_dict(16, 19, 2, 0.5, True, (1, 2))
        self.assertEqual(spec, {"lo": 16, "hi": 19, "T": 2, "alpha": 0.5, "untied": True, "mix": [1, 2]})
        self.assertEqual(loop_spec_from_dict(json.loads(json.dumps(spec))), spec)
        self.assertEqual(loop_spec_from_dict({"lo": 1, "hi": 2, "T": 1, "alpha": 1})["mix"], [])
        for bad in ({"lo": 3, "hi": 2, "T": 2, "alpha": 1.0}, {"lo": 1, "hi": 2, "T": 0, "alpha": 1.0},
                    {"lo": 1, "hi": 2, "T": 2, "alpha": 0.0}, {"lo": 1, "hi": 2}):
            with self.assertRaises(ValueError, msg=bad):
                loop_spec_from_dict(bad)
        self.assertEqual(LOOP_SIDECAR, "layer_loop.json")
        self.assertEqual(loop_rms_summary([]), {"n": 0, "mean_pass": [], "max_ratio_2_1": None})
        s = loop_rms_summary([[1.0, 2.0], [1.0], [2.0, 3.0]])
        self.assertEqual((s["n"], s["mean_pass"], s["max_ratio_2_1"]), (3, [round(4 / 3, 5), 2.5], 2.0))


@unittest.skipUnless(HAVE, "needs torch + transformers")
class TestTrainerSmoke(unittest.TestCase):
    """train_student.py / eval_student.py end to end on the tiny Qwen2 fixture (2 layers: window 0-0, GPT-2
    tokenizer from the local HF cache), CPU: LOOP-MIX with --loop-eval-T 1,2 and --save, then eval_student.py on
    the saved model (sidecar read, the same predictions at every T), then LOOP-UNTIED save + reload."""

    @classmethod
    def setUpClass(cls):
        try:
            from test_mc_nodes import toy_fa
            from test_tree_forcing import tiny
        except ImportError as e:
            raise unittest.SkipTest(f"fixtures: {e}")
        try:
            transformers.AutoTokenizer.from_pretrained("gpt2", local_files_only=True)
        except Exception as e:
            raise unittest.SkipTest(f"no local gpt2 tokenizer: {e}")
        cls.tiny, cls.toy_fa = staticmethod(tiny), staticmethod(toy_fa)

    def run_train(self, d, out, *extra):
        items = [dict(self.toy_fa(), item_id=f"t{j}") for j in range(4)]
        Path(d + "/t.jsonl").write_text("\n".join(json.dumps(x) for x in items))
        r = subprocess.run([sys.executable, TRAIN, "--model", d + "/m", "--train", d + "/t.jsonl",
                            "--eval", "val=" + d + "/t.jsonl", "--epochs", "2", "--items-per-update", "2",
                            "--micro-bs", "2", "--max-len", "512", "--eval-max-len", "512", "--precision", "fp32master",
                            "--log-every", "1", "--seed", "1", "--eval-at", "1", "--eval-mid", "val", "--out", out,
                            *extra], capture_output=True, text=True, timeout=900, env=ENV)
        self.assertEqual(r.returncode, 0, r.stderr[-3000:])
        return r, json.loads(Path(out + "/metrics.json").read_text())

    def run_eval(self, d, model_dir, out, *extra):
        r = subprocess.run([sys.executable, EVAL, "--model", model_dir, "--eval", "x=" + d + "/t.jsonl",
                            "--max-len", "512", "--bs", "2", "--out", out, *extra],
                           capture_output=True, text=True, timeout=900, env=ENV)
        self.assertEqual(r.returncode, 0, r.stderr[-3000:])
        return r, json.loads(Path(out + "/metrics.json").read_text())

    def test_loop_mix_train_save_eval(self):
        with tempfile.TemporaryDirectory() as d:
            self.tiny(d)
            r, m = self.run_train(d, d + "/mix", "--loop-layers", "0-0", "--loop-T", "2", "--loop-mix", "1,2",
                                  "--loop-eval-T", "1,2", "--save", "--no-grad-ckpt")
            self.assertIn("layer loop: layers 0-0, T 2", r.stdout)
            ll = m["layer_loop"]
            self.assertEqual({k: ll[k] for k in ("lo", "hi", "T", "alpha", "untied", "mix")},
                             {"lo": 0, "hi": 0, "T": 2, "alpha": 1.0, "untied": False, "mix": [1, 2]})
            self.assertEqual(sum(ll["train_T_counts"].values()), 4)          # 2 epochs x 2 micro-batches of 2 items
            self.assertEqual(set(ll["train_T_counts"]) <= {"1", "2"}, True)
            self.assertEqual(sum(ll["forward_counts"].values()), 7)          # + the mid eval, the final eval at T=2, T=1
            self.assertGreaterEqual(ll["forward_counts"]["1"], 1)
            self.assertEqual(ll["rms"]["n"], 7)
            self.assertIn("val", m["eval"])
            self.assertIn("val@T1", m["eval"])
            self.assertNotIn("val@T2", m["eval"])
            self.assertTrue(Path(d + "/mix/preds_val@T1.jsonl").exists())
            self.assertEqual(json.loads(Path(d + "/mix/" + LOOP_SIDECAR).read_text()), loop_spec_to_dict(0, 0, 2, 1.0, False, (1, 2)))
            self.assertEqual(json.loads(Path(d + "/mix/model/" + LOOP_SIDECAR).read_text()),
                             json.loads(Path(d + "/mix/" + LOOP_SIDECAR).read_text()))
            # eval_student: the sidecar sets the loop; T=2 under the plain name, T=1 as x@T1; same predictions
            r2, e = self.run_eval(d, d + "/mix/model", d + "/e1", "--loop-eval-T", "1,2")
            self.assertIn("layer loop (from", r2.stdout)
            self.assertEqual(e["layer_loop"]["T"], 2)
            self.assertEqual(set(e["eval"]), {"x", "x@T1"})
            for a, b in (("x", "val"), ("x@T1", "val@T1")):   # the saved model is bf16: close, not equal
                self.assertAlmostEqual(e["eval"][a]["nll"], m["eval"][b]["nll"], delta=0.01, msg=a)
            self.assertNotAlmostEqual(e["eval"]["x"]["nll"], e["eval"]["x@T1"]["nll"], places=6)
            _, ex = self.run_eval(d, d + "/mix/model", d + "/ex", "--loop-layers", "0-0", "--loop-T", "2")
            self.assertEqual(ex["eval"]["x"], e["eval"]["x"])           # explicit flags = the sidecar
            # flags override the sidecar: T=1 plain name; --loop-layers none: no loop at all (T=1 numbers)
            _, e1 = self.run_eval(d, d + "/mix/model", d + "/e2", "--loop-T", "1")
            self.assertAlmostEqual(e1["eval"]["x"]["nll"], e["eval"]["x@T1"]["nll"], places=5)
            _, e0 = self.run_eval(d, d + "/mix/model", d + "/e3", "--loop-layers", "none")
            self.assertNotIn("layer_loop", e0)
            self.assertAlmostEqual(e0["eval"]["x"]["nll"], e["eval"]["x@T1"]["nll"], places=5)
            # damped eval: alpha 0.5 differs from both
            _, ea = self.run_eval(d, d + "/mix/model", d + "/e4", "--loop-alpha", "0.5")
            self.assertNotAlmostEqual(ea["eval"]["x"]["nll"], e["eval"]["x"]["nll"], places=6)
            self.assertNotAlmostEqual(ea["eval"]["x"]["nll"], e["eval"]["x@T1"]["nll"], places=6)

    def test_loop_untied_train_save_eval(self):
        with tempfile.TemporaryDirectory() as d:
            self.tiny(d)
            r, m = self.run_train(d, d + "/un", "--loop-layers", "0-0", "--loop-T", "2", "--loop-untied",
                                  "--loop-eval-T", "1,2", "--save")
            self.assertIn("untied (", r.stdout)
            self.assertTrue(m["layer_loop"]["untied"])
            self.assertEqual(m["layer_loop"]["train_T_counts"], {})            # no mix: fixed T
            self.assertEqual(set(m["layer_loop"]["forward_counts"]), {"1", "2"})   # T=2 training + T=1 eval
            from safetensors import safe_open
            with safe_open(d + "/un/model/model.safetensors", framework="pt") as fh:
                keys = [k for k in fh.keys() if "loop_untied." in k]
            self.assertTrue(keys, "the copies are saved with the model")
            r2, e = self.run_eval(d, d + "/un/model", d + "/e", "--loop-eval-T", "1,2")
            self.assertIn("loop_untied tensors loaded", r2.stdout)
            self.assertTrue(e["layer_loop"]["untied"])
            for a, b in (("x", "val"), ("x@T1", "val@T1")):   # the saved model is bf16: close, not equal
                self.assertAlmostEqual(e["eval"][a]["nll"], m["eval"][b]["nll"], delta=0.01, msg=a)
            self.assertNotAlmostEqual(e["eval"]["x"]["nll"], e["eval"]["x@T1"]["nll"], places=6)
            _, ex = self.run_eval(d, d + "/un/model", d + "/ex", "--loop-layers", "0-0", "--loop-T", "2",
                                  "--loop-untied")
            self.assertEqual(ex["eval"]["x"], e["eval"]["x"])           # explicit flags = the sidecar

    def test_flag_validation(self):
        with tempfile.TemporaryDirectory() as d:
            self.tiny(d)
            Path(d + "/t.jsonl").write_text(json.dumps(dict(self.toy_fa(), item_id="t0")))
            for extra, msg in ((["--loop-T", "3"], "need --loop-layers"),
                               (["--loop-layers", "0-0", "--loop-mix", "2"], "two or more"),
                               (["--loop-layers", "1-1"], "layer hi + 1 must exist"),
                               (["--loop-layers", "0-0", "--loop-alpha", "0"], "0 < --loop-alpha")):
                r = subprocess.run([sys.executable, TRAIN, "--model", d + "/m", "--train", d + "/t.jsonl",
                                    "--epochs", "1", "--out", d + "/o", *extra], capture_output=True, text=True,
                                   timeout=900, env=ENV)
                self.assertNotEqual(r.returncode, 0, extra)
                self.assertIn(msg, r.stderr, extra)


if __name__ == "__main__":
    unittest.main()
