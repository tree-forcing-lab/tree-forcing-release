"""Evaluate a model (untrained base control or a saved student) on eval sets, final question only.

  python scripts/eval_student.py --model ~/cotd/models/Qwen3.5-2B-Base \
      --eval jevbench=data/eval/jevbench_public.jsonl kk=data/eval/kk_heldout.jsonl --out runs/base-2B

Writes metrics.json and preds_<set>.jsonl; scripts/score_preds.py gives per-group breakdowns.

--time (opt-in): forward-only seconds per item for a practicality table (e.g. StepFinder's seconds per trajectory):
every item of every set alone (batch 1, the readout forward of evaluate, no generation), after one warm-up item,
CUDA-synchronized wall time per item -> timing_<set>.json (mean, median, p90, max, total, prompt tokens, device).
The predictions and metrics are written as without the flag.

Latent-slot models (train_student.py --latent-slots, arms LS / LSU / LSR / LSY): a saved model directory holds
latent_slots.json, and every final question is then built with the same slot line as in training (final_text); the
--latent-slots / --slot-* flags set or override it. --slot-necessity / --slot-decode run the necessity test and the
decoding readout as at the end of training. v2.1 models (arms LSL / LSLU / LSLR / LSLY) keep their distinct tokens,
slot layer, lens readout and fill in latent_slots.json: --slot-decode N then gives the lens readout (slot_readout), and
the necessity mode mean needs --slot-mean-train (training items for the slot means). A model trained with
--slot-overflow truncate / --slot-pad-weight W != 1 records them there too (overflow, pad_weight), so --slot-decode
rebuilds its targets (truncate: the FIRST K steps) without --slot-overflow.

LayerLoop models (train_student.py --loop-layers, arms LOOP / LOOP-MIX / LOOP-UNTIED): a saved model directory holds
layer_loop.json (the window lo-hi, T, alpha, untied), and the loop is rebuilt and installed before the evaluations;
the --loop-* flags set or override it (--loop-layers none: no loop, e.g. the plain base model). Every set is scored at
--loop-T under its name and at every other --loop-eval-T value as <name>@T<t>; --loop-alpha damps every extra pass
(stage 0: eval_student.py --loop-layers 16-19 --loop-T 2 --loop-alpha 0.5 --loop-eval-T 1,2 on the untrained base).
LOOP-UNTIED: from_pretrained drops the copies' weights (loop_untied.*, unknown to the architecture), so the copies are
rebuilt from the originals and their tensors read back from the safetensors files (student.load_loop_untied).

Depth-forcing models (train_student.py --df-layers, arms DF / DFX; cotdistill.depth_forcing): a saved model directory
holds df.json (the forced layers, target, head size) and df_heads.pt (the probe heads, which from_pretrained drops as
unknown keys). The heads are rebuilt and loaded, and every eval set whose items carry worked_steps is also scored with
the per-layer probe (results["df_probe"][set]: accuracy per step k that the item's own value of step k is the
argmax among the candidates / matches the digit code); --df-probe none skips it.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cotdistill.student import (LOOP_SIDECAR, SLOT_POOL, SLOT_SIDECAR, LayerLoop, SlotSpec, choose_slot_token,  # noqa: E402
                                encode_tail, evaluate, evaluate_subq, final_text, load_loop_untied, load_model,
                                loop_spec_from_dict, parse_loop_Ts, parse_loop_layers, parse_slot_necessity,
                                set_slot_prompt, slot_evals, slot_spec, subq_sets, text_parts, use_chat_template,
                                worked_steps)
from cotdistill.depth_forcing import DF_SIDECAR, DFSpec, DepthForcing, load_df_heads  # noqa: E402


def time_items(model, tok, items: list[dict], max_len: int, cache: dict) -> dict:
    """--time: seconds per item, each item alone (batch 1), after one untimed warm-up item; CUDA synchronized."""
    import time
    import numpy as np
    dev = next(model.parameters()).device
    sync = torch.cuda.synchronize if dev.type == "cuda" else (lambda: None)
    evaluate(model, tok, items[:1], max_len, 1, cache)                 # warm-up (kernels, allocator, label ids)
    secs, ntok = [], []
    for it in items:
        sync()
        t = time.perf_counter()
        evaluate(model, tok, [it], max_len, 1, cache)
        sync()
        secs.append(time.perf_counter() - t)
        ntok.append(len(encode_tail(tok, final_text(tok, it["prompt"]), max_len)))
    a = np.array(secs)
    return {"n": len(secs), "s_mean": float(a.mean()), "s_median": float(np.median(a)),
            "s_p90": float(np.percentile(a, 90)), "s_max": float(a.max()), "s_total": float(a.sum()),
            "tokens_mean": float(np.mean(ntok)), "tokens_max": int(max(ntok)), "batch": 1, "max_len": max_len,
            "device": torch.cuda.get_device_name(dev) if dev.type == "cuda" else "cpu",
            "dtype": str(next(model.parameters()).dtype), "per_item_s": [round(x, 4) for x in secs]}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--eval", nargs="+", required=True, help="name=path.jsonl")
    ap.add_argument("--max-len", type=int, default=6144)
    ap.add_argument("--bs", type=int, default=8)
    ap.add_argument("--out", required=True)
    ap.add_argument("--dump-layers", default="", help="comma list of decoder layers whose readout states are saved "
                    "with --dump-hidden (shape [n, layers + 1, hidden]; the last entry is the final readout state)")
    ap.add_argument("--dump-hidden", default="", help="comma list of eval-set names whose readout hidden states "
                    "to save as hidden_<name>.pt (float16, preds order)")
    ap.add_argument("--eval-subq", default=None, help="student data file whose sub-questions to score, or "
                    "comma-separated name=path entries (predictions in preds_subq[_name].jsonl)")
    ap.add_argument("--chat-template", action="store_true",
                    help="read out every item as one user turn of the model's chat template, thinking off, at the "
                         "assistant turn's first token (bare letters), as train_student.py --chat-template; off: "
                         "unchanged")
    ap.add_argument("--time", action="store_true", help="also time every item alone (batch 1, forward only): "
                    "timing_<set>.json")
    ap.add_argument("--latent-slots", type=int, default=None,
                    help="slot line of every final question: K slots (default: the model's latent_slots.json, if any; "
                         "0 = none)")
    ap.add_argument("--slot-c", type=int, default=None, help="tokens per slot (default: latent_slots.json, else 1)")
    ap.add_argument("--slot-token", default=None, help="the slot token (default: latent_slots.json, else auto)")
    ap.add_argument("--slot-place", default=None, choices=["before-options", "after-options"],
                    help="slot line placement (default: latent_slots.json, else before-options)")
    ap.add_argument("--slot-overflow", default=None, choices=["merge", "truncate"],
                    help="--slot-decode: how the targets of chains longer than K are shown (as in training; default: "
                         "the overflow in latent_slots.json, else merge)")
    ap.add_argument("--slot-necessity", default="", help="necessity test modes (swap, drop, noise@<layer|mid>:<sigma>; "
                    "train_student.py --slot-necessity)")
    ap.add_argument("--slot-necessity-sets", default="", help="--slot-necessity: comma list of eval sets (default all)")
    ap.add_argument("--slot-swap-token", default="auto", help="--slot-necessity swap: the replacement token")
    ap.add_argument("--slot-decode", type=int, default=0, help="decode every slot of the first N items of "
                    "--slot-decode-set greedily: slot_decode_<set>.jsonl")
    ap.add_argument("--slot-decode-set", default="", help="--slot-decode: the eval set (default: the first --eval set; "
                    "lens models: a comma list)")
    ap.add_argument("--slot-mean-train", default="", help="--slot-necessity mean: training items (jsonl) whose slot "
                    "states give the means")
    ap.add_argument("--slot-mean-n", type=int, default=300, help="--slot-mean-train: the first N items")
    ap.add_argument("--loop-layers", default=None,
                    help="LayerLoop window 'lo-hi' (0-based decoder layers, inclusive; default: the model's "
                         "layer_loop.json, if any; 'none' = no loop)")
    ap.add_argument("--loop-T", type=int, default=None, help="passes through the window for the plain-named "
                    "evaluations (default: layer_loop.json, else 2)")
    ap.add_argument("--loop-alpha", type=float, default=None,
                    help="damping of every extra pass, x <- x + alpha (block(x) - x), in (0, 1] (default: "
                         "layer_loop.json, else 1 = plain re-application)")
    ap.add_argument("--loop-untied", action="store_true",
                    help="the extra passes run the saved copies loop_untied.* (default: layer_loop.json)")
    ap.add_argument("--loop-eval-T", default="", help="comma list of pass counts: every set is also scored at each "
                    "T other than --loop-T, as <name>@T<t> (default: --loop-T only)")
    ap.add_argument("--df-probe", default="auto", choices=["auto", "none"],
                    help="depth-forcing models (df.json next to the model): auto = report the per-layer probe "
                         "accuracy on every eval set with worked steps (results df_probe); none = skip")
    args = ap.parse_args()

    import transformers
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    tok = transformers.AutoTokenizer.from_pretrained(args.model)
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    if args.chat_template:
        print("chat template: every item rendered as", repr(use_chat_template(tok, args.model)), flush=True)
    side = Path(args.model) / SLOT_SIDECAR
    sd = json.loads(side.read_text()) if side.exists() else {}
    k = args.latent_slots if args.latent_slots is not None else sd.get("k", 0)
    if args.slot_overflow is None:       # a v2.1 model trained with --slot-overflow truncate records it
        args.slot_overflow = sd.get("overflow", "merge")
    swap = None
    if k:
        if args.chat_template:
            raise SystemExit("latent slots do not combine with --chat-template")
        try:
            token = choose_slot_token(tok, args.slot_token or sd.get("token", "auto"))
            spec = SlotSpec(k, args.slot_c or sd.get("c", 1), token, args.slot_place or sd.get("place", "before-options"))
            if any(x in sd for x in ("tokens", "layer", "readout", "fill", "head_grad", "pad_weight", "overflow")):
                spec = SlotSpec(spec.k, spec.c, spec.token, spec.place, tokens=tuple(sd.get("tokens", ())),  # v2.1
                                layer=sd.get("layer"), readout=sd.get("readout", "decode"), fill=sd.get("fill", "none"),
                                head_grad=sd.get("head_grad", False), pad_weight=sd.get("pad_weight", 1.0),
                                overflow=sd.get("overflow", "merge"))
            set_slot_prompt(tok, spec)
            modes = parse_slot_necessity(args.slot_necessity)
            if "swap" in modes:
                swap = choose_slot_token(tok, args.slot_swap_token, avoid=spec.tokens or (token,),
                                         **({"pool": SLOT_POOL} if spec.tokens else {}))
            if "mean" in modes and spec.layer is None:
                raise ValueError("--slot-necessity mean: the model has no slot layer (use mean@<layer>)")
            if any(m.startswith("mean") for m in modes) and not args.slot_mean_train:
                raise ValueError("--slot-necessity mean: pass --slot-mean-train <train.jsonl>")
        except ValueError as e:
            raise SystemExit(f"latent slots: {e}")
        print(f"latent slots ({'from ' + str(side) if sd else 'flags'}): {spec}", flush=True)
    elif args.slot_necessity or args.slot_decode:
        raise SystemExit("--slot-necessity / --slot-decode need a slot model (latent_slots.json) or --latent-slots")
    lside = Path(args.model) / LOOP_SIDECAR
    try:
        lsd = loop_spec_from_dict(json.loads(lside.read_text())) if lside.exists() else None
        if args.loop_layers is not None:
            loop_lohi = None if args.loop_layers.strip().lower() == "none" else parse_loop_layers(args.loop_layers)
        else:
            loop_lohi = (lsd["lo"], lsd["hi"]) if lsd else None
        loop_eval_T = parse_loop_Ts(args.loop_eval_T)
    except ValueError as e:
        raise SystemExit(f"layer loop: {e}")
    if loop_lohi is None and (args.loop_T is not None or args.loop_alpha is not None or args.loop_untied or loop_eval_T):
        raise SystemExit("--loop-T / --loop-alpha / --loop-untied / --loop-eval-T need a loop (--loop-layers or "
                         f"{LOOP_SIDECAR})")
    if loop_lohi is not None and args.dump_layers:
        raise SystemExit("the layer loop does not combine with --dump-layers (the looped layers record their hidden "
                         "states once per pass, so the layer indices shift)")
    model = load_model(args.model, torch.bfloat16 if dev == "cuda" else torch.float32).to(dev)
    loop = None
    if loop_lohi is not None:
        lsd = lsd or {}
        loop_T = args.loop_T if args.loop_T is not None else lsd.get("T", 2)
        loop_alpha = args.loop_alpha if args.loop_alpha is not None else lsd.get("alpha", 1.0)
        loop_untied = args.loop_untied or bool(lsd.get("untied", False))
        loop_eval_T = loop_eval_T or (loop_T,)
        try:
            body, _ = text_parts(model)
            loop = LayerLoop(body, loop_lohi[0], loop_lohi[1], T=loop_T, alpha=loop_alpha, untied=loop_untied)
            if loop_untied:          # the copies exist now; their saved weights replace the originals' values
                n_loaded = load_loop_untied(body, args.model)
                print(f"layer loop: {n_loaded} loop_untied tensors loaded from {args.model}", flush=True)
        except ValueError as e:
            raise SystemExit(f"layer loop: {e}")
        loop.install()
        print(f"layer loop ({'from ' + str(lside) if lsd else 'flags'}): layers {loop.lo}-{loop.hi}, T {loop.T}, "
              f"alpha {loop.alpha}, {'untied' if loop.untied else 'tied'}, eval T {list(loop_eval_T)}", flush=True)
    df = None                            # depth forcing: the saved heads, for the per-layer probe readout
    dside = Path(args.model) / DF_SIDECAR
    if dside.exists() and args.df_probe != "none":
        try:
            df = DepthForcing(model, DFSpec.from_dict(json.loads(dside.read_text())))
            src = load_df_heads(text_parts(model)[0], args.model)
        except ValueError as e:
            raise SystemExit(f"depth forcing: {e}")
        print(f"depth forcing (from {dside}): layers {list(df.spec.layers)}, target {df.spec.target}"
              f"{', shuffled targets (DFX)' if df.spec.shuffle else ''}; heads from {src}", flush=True)
    results, cache = {"args": vars(args), "eval": {}}, {}
    if loop is not None:
        results["layer_loop"] = {**loop.spec(), "eval_T": list(loop_eval_T)}
    if df is not None:
        results["df"] = df.spec.as_dict()
        results["df_probe"] = {}
    evals = {}
    for kv in args.eval:
        name, path = kv.split("=", 1)
        items = [json.loads(l) for l in open(path) if l.strip()]
        evals[name] = items
        if k and items:
            if any(any(t in it["prompt"] for t in spec.slot_tokens()) or swap and swap in it["prompt"] for it in items):
                raise SystemExit(f"{name}: the slot (or swap) token occurs in a prompt; pick another --slot-token")
            print(name, "final question e.g.", repr(final_text(tok, items[0]["prompt"])), flush=True)
        hid = [] if name in args.dump_hidden.split(",") else None
        m, preds = evaluate(model, tok, items, args.max_len, args.bs, cache, hidden=hid,
                            layers=[int(x) for x in args.dump_layers.split(",") if x] or None)
        if hid is not None:
            torch.save(torch.stack(hid).half(), out / f"hidden_{name}.pt")
        results["eval"][name] = m
        with open(out / f"preds_{name}.jsonl", "w") as f:
            for p in preds:
                f.write(json.dumps(p) + "\n")
        print(name, json.dumps(m), flush=True)
        if df is not None and any(worked_steps(it) for it in items):   # is the step value decodable at its layer?
            results["df_probe"][name] = df.probe(model, tok, items, args.max_len, args.bs, cache)
            print(f"df probe {name}", json.dumps(results["df_probe"][name]), flush=True)
        for t in (loop_eval_T if loop is not None else ()):    # the same set at the other pass counts
            if t == loop_T:
                continue
            loop.T = t
            mt, pt = evaluate(model, tok, items, args.max_len, args.bs, cache)
            loop.T = loop_T
            results["eval"][f"{name}@T{t}"] = mt
            with open(out / f"preds_{name}@T{t}.jsonl", "w") as f:
                for p in pt:
                    f.write(json.dumps(p) + "\n")
            print(f"{name}@T{t}", json.dumps(mt), flush=True)
        if args.time:
            tm = time_items(model, tok, items, args.max_len, cache)
            (out / f"timing_{name}.json").write_text(json.dumps(tm, indent=1))
            results.setdefault("timing", {})[name] = {k: v for k, v in tm.items() if k != "per_item_s"}
            print("timing", name, json.dumps(results["timing"][name]), flush=True)
    if k:
        results["latent_slots"] = slot_spec(tok).as_dict()
        slot_evals(model, tok, evals, results, out, modes=parse_slot_necessity(args.slot_necessity),
                   sets=[x for x in args.slot_necessity_sets.split(",") if x], swap_token=swap,
                   decode_n=args.slot_decode, decode_set=args.slot_decode_set, max_len=args.max_len, bs=args.bs,
                   cache=cache, overflow=args.slot_overflow,
                   mean_items=[json.loads(l) for l in open(args.slot_mean_train) if l.strip()][:args.slot_mean_n]
                   if args.slot_mean_train else None)
    for sname, spath in subq_sets(args.eval_subq or ""):
        items = [json.loads(l) for l in open(spath) if l.strip()]
        sm, spreds = evaluate_subq(model, tok, items, args.max_len, args.bs, cache)
        results["eval"][sname] = sm
        with open(out / f"preds_{sname}.jsonl", "w") as f:
            for p in spreds:
                f.write(json.dumps(p) + "\n")
        print(sname, json.dumps({k: round(v["acc"], 3) for k, v in sm.items()}), flush=True)
    (out / "metrics.json").write_text(json.dumps(results, indent=1))


if __name__ == "__main__":
    main()
