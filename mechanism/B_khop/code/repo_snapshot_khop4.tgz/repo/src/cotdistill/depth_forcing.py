"""Depth forcing (arm DF; control DFX): an auxiliary loss that makes the value of worked step k decodable from the
residual stream at the answer position after decoder layer L_k (direction report, card B).

A one-pass model computes about one serial arithmetic step per 4 layers; forcing step k's value to be linearly
decodable after layer L_k = L0 + s k (default L0 = 6, s = 4: layers 10, 14, 18, 22 for k = 1..4) should push the
network to compute the steps in depth order instead of guessing the answer from surface features.

Mechanics (opt-in: train_student.py --df-layers; nothing here runs on the default path):
  * The training forward of a micro-batch of final views runs as student.label_logits does (same collate, same body
    call, same letter rows), inside a _Capture: a forward pre-hook on decoder layer L_k + 1 keeps its hidden-state
    input, the output of layer L_k, at every position, NOT detached. The input of a checkpointed layer is the graph
    tensor itself under reentrant and non-reentrant gradient checkpointing (as student._SlotCapture), so the
    auxiliary gradient reaches layers 0..L_k; the recompute in backward fires the hook again but the first capture
    of a forward is kept. Layer indices are 0-based decoder layers; L_k <= n - 2 (layer L_k + 1 must exist).
  * Head k (DFHeads, a ModuleList registered as body.df_heads so FSDP sharding, the optimizer and save_pretrained
    see it; --df-shared-head: one head for every k) maps the captured state at the answer position to a vector.
  * Target "contrast": a value string is tokenized with the model tokenizer and encoded as the mean of the model's
    input embeddings of its tokens (detached: the auxiliary loss does not move the embedding table) projected by
    DFHeads.proj (shared across k, trained). Loss = InfoNCE at temperature --df-temperature over L2-normalised
    vectors: the positive is the step's value; the negatives are the encodings of (a) the other steps' values of the
    item, (b) the item's option values, (c) every other item's step values in the micro-batch and (d) up to
    DF_PROMPT_NEGS numbers of the prompt (drawn once per item by a generator keyed by the seed and the item). The
    candidates are deduplicated by numeric value (canon_number), and no negative equals the positive.
    Probe accuracy = argmax over the candidates is the positive.
  * Target "digits": cross-entropy over a fixed code of the value (digit_code: sign 2-way, DIGITS_N = 6 significant
    digits each 10-way, exponent 1-of-13 classes for 10^-6..10^6) from a Linear(hidden, DIGITS_OUT) head; the loss
    is the mean of the 8 cross-entropies; probe accuracy = exact match of the whole code.
  * Loss of a micro-batch = sum of the answer CEs + lambda x (mean over its supervised (item, k) pairs of the
    auxiliary loss) x (number of examples), then the loop's own 1 / (examples x grad_accum) normalisation, so the
    update's loss is mean CE_answer + lambda x mean auxiliary loss. An item with n worked steps supervises
    k = 1..min(n, K) (K = len(layers)); items without steps are unsupervised.
  * --df-pos operand (arms DFO / DFOX): step k is read NOT at the "Answer:" cue but where it becomes computable in the
    question: the last token of the last occurrence, in the question text (the prompt before its Options block), of
    whichever of the step's operand strings (worked_steps[k]["a"], ["b"]) occurs latest, matched as standalone numbers
    by numeric value (operand_end; "1,000" matches "1000"); the character offset is mapped to collate's token index
    with the tokenizer's offset mapping (token_at; slow tokenizers: the prefix re-tokenised), after the tail cut of
    encode_tail. A step with neither operand in the question is unsupervised and counted (no_operand_position); one
    whose position was cut by max_len is counted as truncated. The layer schedule and everything else are the same.
    The reason: a causal patching run showed the readout-position residual at layers 4-28 carries at most a fifth of
    the hinted information; the final attention layer gathers the computation from the context positions.
  * --df-shuffle (control DFX): every item's targets are another item's step values (df_partners: a partner with a
    different value sequence, drawn by a generator keyed by the seed and the item, fixed over the epochs; the partner's
    values are cycled to the item's own step count, so the supervised counts per k are those of the DF arm).
  * Sidecar DF_SIDECAR next to metrics.json and the saved model (the spec eval_student.py rebuilds); the head weights
    go into model.safetensors (body.df_heads.*) and into DF_HEADS_FILE (from_pretrained drops unknown keys;
    load_df_heads reads either).
  * probe(): the per-layer probe accuracy on items with worked steps (the item's OWN values, also for a DFX model:
    the readout asks whether the true step value is decodable), with the training candidate scheme.
"""
from __future__ import annotations

import json
import random
import re
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from pathlib import Path

import torch
import torch.nn.functional as F

from .student import (Example, collate, head_logits, letter_token_ids, logit_softcap, special_prefix, text_parts,
                      worked_steps)

DF_SIDECAR = "df.json"                   # next to a saved DF model: the spec eval_student rebuilds
DF_HEADS_FILE = "df_heads.pt"            # the heads' state dict (body.df_heads), next to the saved model
DF_TARGETS = ("contrast", "digits")
DF_POSITIONS = ("answer", "operand")     # where step k is read: the "Answer:" cue, or where it becomes computable
DF_TEMPERATURE = 0.1
DF_PROMPT_NEGS = 8                       # numbers of the prompt used as negatives (contrast), per item
DIGITS_N = 6                             # significant digits of the digit code
EXP_LO, EXP_HI = -6, 6                   # exponent classes of the digit code (13)
DIGITS_OUT = 2 + 10 * DIGITS_N + (EXP_HI - EXP_LO + 1)   # 75
_NUM = re.compile(r"-?\d+(?:,\d{3})*(?:\.\d+)?")
_OPT_LINE = re.compile(r"^([A-Za-z0-9])\) (.*)$")


# ---------------------------------------------------------------------------------------------------- spec
@dataclass
class DFSpec:
    layers: tuple                        # L_k for k = 1..K (0-based decoder layers, outputs)
    lam: float = 0.5
    target: str = "contrast"
    dim: int = 256
    shared_head: bool = False
    shuffle: bool = False
    max_steps: int = 4
    temperature: float = DF_TEMPERATURE
    seed: int = 0
    L0: int = 6
    stride: int = 4
    pos: str = "answer"                  # DF_POSITIONS

    @property
    def K(self) -> int:
        return len(self.layers)

    def as_dict(self) -> dict:
        return {"layers": [int(x) for x in self.layers], "lambda": float(self.lam), "target": self.target,
                "dim": int(self.dim), "shared_head": bool(self.shared_head), "shuffle": bool(self.shuffle),
                "max_steps": int(self.max_steps), "temperature": float(self.temperature), "seed": int(self.seed),
                "L0": int(self.L0), "stride": int(self.stride), "pos": self.pos}

    @classmethod
    def from_dict(cls, d: dict) -> "DFSpec":
        try:
            spec = cls(layers=tuple(int(x) for x in d["layers"]), lam=float(d.get("lambda", 0.5)),
                       target=str(d.get("target", "contrast")), dim=int(d.get("dim", 256)),
                       shared_head=bool(d.get("shared_head", False)), shuffle=bool(d.get("shuffle", False)),
                       max_steps=int(d.get("max_steps", len(d["layers"]))),
                       temperature=float(d.get("temperature", DF_TEMPERATURE)), seed=int(d.get("seed", 0)),
                       L0=int(d.get("L0", 6)), stride=int(d.get("stride", 4)), pos=str(d.get("pos", "answer")))
        except (KeyError, TypeError, ValueError) as e:
            raise ValueError(f"{DF_SIDECAR}: {e}")
        validate_spec(spec)
        return spec


def parse_df_layers(text: str, max_steps: int, L0: int = 6, stride: int = 4) -> tuple:
    """--df-layers: 'auto' -> (L0 + stride k for k = 1..max_steps); else a comma list of 0-based decoder layers, the
    first max_steps of them (step k reads layer k). Distinct, >= 0."""
    s = text.strip().lower()
    if max_steps < 1:
        raise ValueError(f"--df-max-steps {max_steps}: >= 1")
    if s == "auto":
        if L0 < 0 or stride < 1:
            raise ValueError(f"--df-L0 {L0} >= 0 and --df-stride {stride} >= 1")
        layers = tuple(L0 + stride * k for k in range(1, max_steps + 1))
    else:
        try:
            layers = tuple(int(x) for x in s.split(",") if x.strip())
        except ValueError:
            raise ValueError(f"--df-layers {text!r}: 'auto' or a comma list of 0-based decoder layers")
        if not layers:
            raise ValueError(f"--df-layers {text!r}: no layer")
        layers = layers[:max_steps]
    if len(set(layers)) != len(layers) or any(x < 0 for x in layers):
        raise ValueError(f"--df-layers {text!r}: distinct layers >= 0")
    return layers


def validate_spec(spec: DFSpec) -> None:
    if spec.target not in DF_TARGETS:
        raise ValueError(f"--df-target {spec.target}: one of {DF_TARGETS}")
    if spec.pos not in DF_POSITIONS:
        raise ValueError(f"--df-pos {spec.pos}: one of {DF_POSITIONS}")
    if not spec.layers or len(set(spec.layers)) != len(spec.layers) or any(x < 0 for x in spec.layers):
        raise ValueError(f"--df-layers {list(spec.layers)}: distinct layers >= 0")
    if spec.lam < 0 or spec.dim < 1 or spec.temperature <= 0 or spec.max_steps < 1:
        raise ValueError("--df-lambda >= 0, --df-dim >= 1, --df-temperature > 0, --df-max-steps >= 1")


# ---------------------------------------------------------------------------------------------------- values
def canon_number(s) -> str | None:
    """The canonical form of a number string ('12.0', '12', '1.2e1' -> '12'; '1,000' -> '1000'); None if not a number."""
    if s is None:
        return None
    t = str(s).strip().replace(",", "").replace("−", "-")
    if not t:
        return None
    try:
        d = Decimal(t)
    except InvalidOperation:
        return None
    if not d.is_finite():
        return None
    if d == 0:
        return "0"
    return format(d.normalize(), "f")


def prompt_numbers(prompt: str) -> list[str]:
    """The distinct numbers of the problem text (the prompt before its 'Options:' block), in order of appearance,
    as canonical strings."""
    text = prompt.split("\nOptions:", 1)[0]
    out, seen = [], set()
    for m in _NUM.finditer(text):
        c = canon_number(m.group(0))
        if c is not None and c not in seen:
            seen.add(c)
            out.append(c)
    return out


def option_values(item: dict) -> list[str]:
    """The item's option texts: item['options'] when it is a list of strings, else the 'X) text' lines of the prompt."""
    opts = item.get("options")
    if isinstance(opts, list) and all(isinstance(x, str) for x in opts):
        return list(opts)
    out = []
    tail = item.get("prompt", "").split("\nOptions:", 1)
    if len(tail) == 2:
        for line in tail[1].split("\n"):
            m = _OPT_LINE.match(line.strip())
            if m:
                out.append(m.group(2))
    return out


def step_values(item: dict) -> list[str]:
    """The values of the item's worked steps in step order ([] without steps)."""
    steps = worked_steps(item) or []
    return [str(s["value"]) for s in sorted(steps, key=lambda s: s.get("step", 0)) if s.get("value") is not None]


def question_text(prompt: str) -> str:
    """The prompt before its Options block (the question proper)."""
    return prompt.split("\nOptions:", 1)[0]


def operand_end(prompt: str, step: dict) -> int | None:
    """--df-pos operand: the character offset (exclusive) in the prompt where step k becomes computable: the end of the
    last occurrence, in the question text, of whichever operand string (step["a"], step["b"]) occurs latest. Operands
    are matched as standalone numbers by numeric value (canon_number), so '1,000' in the text matches operand '1000'.
    None when neither operand occurs."""
    q = question_text(prompt)
    wanted = {c for c in (canon_number(step.get(key)) for key in ("a", "b")) if c is not None}
    if not wanted:
        return None
    best = None
    for m in _NUM.finditer(q):
        if canon_number(m.group(0)) in wanted:
            best = m.end() if best is None else max(best, m.end())
    return best


def token_at(tokenizer, text: str, char_end: int, max_len: int) -> int | None:
    """collate's token index (in encode_tail(tokenizer, text, max_len)) of the token holding character char_end - 1 of
    text: the special prefix is counted, the tail cut of encode_tail applied; None when the token was cut away. A fast
    tokenizer gives offsets; else the prefix text[:char_end] is re-tokenised (its last token)."""
    pre = special_prefix(tokenizer)
    if getattr(tokenizer, "is_fast", False):
        enc = tokenizer(text, add_special_tokens=False, return_offsets_mapping=True)
        ids, offs = enc["input_ids"], enc["offset_mapping"]
        j = max((t for t, (s, _) in enumerate(offs) if s < char_end), default=None)
    else:
        ids = tokenizer.encode(text, add_special_tokens=False)
        j = len(tokenizer.encode(text[:char_end], add_special_tokens=False)) - 1
    if j is None or j < 0:
        return None
    cut = max(0, len(ids) - max(1, max_len - len(pre)))
    return None if j < cut else len(pre) + j - cut


def digit_code(value: str) -> list[int]:
    """The fixed code of a number: [sign (0 +, 1 -), DIGITS_N significant digits (leading first, zero padded, the
    rest truncated), exponent class (floor(log10 |v|) clipped to EXP_LO..EXP_HI, minus EXP_LO)]. 0 -> all zeros,
    exponent class of 0."""
    c = canon_number(value)
    if c is None:
        raise ValueError(f"digit_code: not a number: {value!r}")
    d = Decimal(c)
    if d == 0:
        return [0] + [0] * DIGITS_N + [-EXP_LO]
    sign, digits, exp = d.as_tuple()
    digits = list(digits)
    while len(digits) > 1 and digits[-1] == 0:          # significant digits only
        digits.pop()
        exp += 1
    sci = len(digits) - 1 + exp
    digs = (digits + [0] * DIGITS_N)[:DIGITS_N]
    return [int(sign)] + digs + [min(EXP_HI, max(EXP_LO, sci)) - EXP_LO]


def df_partners(items: list[dict], seed) -> dict:
    """DFX: item_id -> the id of another item whose step values the item's targets are. Candidates: items with
    worked steps, other than the item and with a different value sequence; drawn by a generator keyed by the seed
    and the item (fixed over the epochs). Raises when an item has no such partner."""
    vals = {it["item_id"]: tuple(step_values(it)) for it in items}
    ids = sorted((i for i, v in vals.items() if v), key=str)
    out = {}
    for iid in ids:
        rng = random.Random(f"df-partner|{seed}|{iid}")
        pick = None
        for _ in range(64):
            j = ids[rng.randrange(len(ids))]
            if j != iid and vals[j] != vals[iid]:
                pick = j
                break
        if pick is None:
            ok = [j for j in ids if j != iid and vals[j] != vals[iid]]
            if not ok:
                raise ValueError(f"df partners: no other item with a different value sequence for {iid}")
            pick = ok[rng.randrange(len(ok))]
        out[iid] = pick
    return out


@dataclass
class DFItem:
    item_id: str
    values: list                         # the item's own step values, at most K
    targets: list                        # the supervised targets (own values, or the partner's: DFX), len = len(values)
    options: list                        # option texts (contrast negatives)
    nums: list                           # up to DF_PROMPT_NEGS numbers of the prompt (contrast negatives)
    partner: str | None = None
    ends: list = field(default_factory=list)   # --df-pos operand: per k the operand_end offset, or None

    def supervised(self, k: int, pos: str) -> bool:
        """Does step k (1-based) have a target and, with pos operand, a position?"""
        return k <= len(self.targets) and (pos == "answer" or self.ends[k - 1] is not None)


def build_table(items: list[dict], spec: DFSpec, shuffle: bool | None = None) -> dict:
    """item_id -> DFItem for every item with worked steps. shuffle (default spec.shuffle): the targets are the
    partner's values (df_partners), cycled to the item's own step count. spec.pos operand: ends holds every step's
    operand_end in the item's own prompt (the position is the item's, also for a shuffled target)."""
    shuffle = spec.shuffle if shuffle is None else shuffle
    partners = df_partners(items, spec.seed) if shuffle else {}
    by = {it["item_id"]: it for it in items}
    table = {}
    for it in items:
        steps = [s for s in sorted(worked_steps(it) or [], key=lambda s: s.get("step", 0)) if s.get("value") is not None]
        vals = [str(s["value"]) for s in steps][:spec.K]
        if not vals:
            continue
        tg = vals
        pid = partners.get(it["item_id"])
        if pid is not None:
            pv = step_values(by[pid])
            tg = [pv[j % len(pv)] for j in range(len(vals))]
        nums = prompt_numbers(it.get("prompt", ""))
        rng = random.Random(f"df-nums|{spec.seed}|{it['item_id']}")
        nums = rng.sample(nums, min(DF_PROMPT_NEGS, len(nums))) if len(nums) > DF_PROMPT_NEGS else nums
        ends = [operand_end(it.get("prompt", ""), s) for s in steps[:len(vals)]] if spec.pos == "operand" else []
        table[it["item_id"]] = DFItem(it["item_id"], vals, tg, option_values(it), nums, pid, ends)
    return table


def supervised_counts(table: dict, K: int, pos: str = "answer") -> list[int]:
    """[items supervising step k for k = 1..K] (pos operand: steps with an operand position only)."""
    return [sum(1 for d in table.values() if d.supervised(k, pos)) for k in range(1, K + 1)]


def no_operand_counts(table: dict, K: int) -> list[int]:
    """[steps k = 1..K with a target but no operand position in the question] (pos operand; else zeros)."""
    return [sum(1 for d in table.values() if k <= len(d.targets) and d.ends and d.ends[k - 1] is None)
            for k in range(1, K + 1)]


def param_groups(params: list, heads: torch.nn.Module, head_lr: float | None):
    """--df-head-lr: the optimizer's parameter groups: [the base parameters, the heads (body.df_heads: the probe heads
    and the contrast projection) at head_lr with weight decay 0]. head_lr None returns params itself: one group, the
    plain arm's optimizer, byte for byte. A LambdaLR scheduler scales every group by the same factor, so the heads
    follow the base warmup / decay shape times their own rate."""
    if head_lr is None:
        return params
    if not head_lr > 0:
        raise ValueError(f"--df-head-lr {head_lr}: > 0")
    ids = {id(p) for p in heads.parameters()}
    base = [p for p in params if id(p) not in ids]
    hp = [p for p in params if id(p) in ids]
    if len(hp) != len(ids):
        raise ValueError("--df-head-lr: a head parameter is not among the trainable parameters")
    return [{"params": base}, {"params": hp, "lr": float(head_lr), "weight_decay": 0.0}]


# ---------------------------------------------------------------------------------------------------- heads
class DFHeads(torch.nn.Module):
    """The probe heads: Linear(hidden, out, bias=False) per k (or one shared); contrast: out = dim and a target
    projection proj = Linear(hidden, dim, bias=False); digits: out = DIGITS_OUT."""

    def __init__(self, hidden: int, spec: DFSpec):
        super().__init__()
        out = spec.dim if spec.target == "contrast" else DIGITS_OUT
        n = 1 if spec.shared_head else spec.K
        self.heads = torch.nn.ModuleList(torch.nn.Linear(hidden, out, bias=False) for _ in range(n))
        self.proj = torch.nn.Linear(hidden, spec.dim, bias=False) if spec.target == "contrast" else None

    def head(self, k: int) -> torch.nn.Linear:
        """The head of step k (1-based)."""
        return self.heads[0] if len(self.heads) == 1 else self.heads[k - 1]


def df_heads_state(sd: dict) -> dict:
    """The body.df_heads.* entries of a model state dict, keys relative to df_heads ({} when none)."""
    out = {}
    for k, v in sd.items():
        if "df_heads." in k:
            out[k.split("df_heads.", 1)[1]] = v
    return out


def load_df_heads(body, model_dir) -> str:
    """Load the saved head weights into body.df_heads (DepthForcing must have built them first): DF_HEADS_FILE, else
    the df_heads.* tensors of model.safetensors (one file or the sharded index). Returns the source read."""
    heads = getattr(body, "df_heads", None)
    if heads is None:
        raise ValueError("load_df_heads: build the heads first (DepthForcing)")
    d = Path(model_dir)
    if (d / DF_HEADS_FILE).exists():
        sd = torch.load(d / DF_HEADS_FILE, map_location="cpu", weights_only=True)
        heads.load_state_dict(sd, strict=True)
        return str(d / DF_HEADS_FILE)
    from safetensors import safe_open
    if (d / "model.safetensors").exists():
        files = [d / "model.safetensors"]
    elif (d / "model.safetensors.index.json").exists():
        wm = json.loads((d / "model.safetensors.index.json").read_text())["weight_map"]
        files = [d / f for f in sorted(set(wm.values()))]
    else:
        raise ValueError(f"{d}: no {DF_HEADS_FILE} and no model.safetensors (or index) to read the df_heads from")
    sd = {}
    for f in files:
        with safe_open(str(f), framework="pt") as fh:
            for k in fh.keys():
                if "df_heads." in k:
                    sd[k.split("df_heads.", 1)[1]] = fh.get_tensor(k)
    if not sd:
        raise ValueError(f"{d}: no df_heads.* tensors (not a DF model)")
    heads.load_state_dict(sd, strict=True)
    return str(files[0])


# ---------------------------------------------------------------------------------------------------- capture
class _Capture:
    """The outputs of decoder layers L_k (0-based) at every position, NOT detached: one-shot forward pre-hooks on
    layers L_k + 1 keep their hidden-state inputs (the first fire of a forward; the recompute of a checkpointed
    layer in backward does not overwrite it). A context manager over one forward."""

    def __init__(self, layers: list, idx: tuple):
        self.nxt = {li: layers[li + 1] for li in idx}
        self.h: dict = {}
        self.handles: list = []

    def __enter__(self):
        self.h.clear()
        for li, mod in self.nxt.items():
            def pre(mod_, args, kwargs, li=li):
                if li not in self.h:
                    self.h[li] = args[0] if args else kwargs["hidden_states"]
            self.handles.append(mod.register_forward_pre_hook(pre, with_kwargs=True))
        return self

    def __exit__(self, *exc):
        for hd in self.handles:
            hd.remove()
        self.handles = []
        return False


# ---------------------------------------------------------------------------------------------------- the feature
class DepthForcing:
    """The depth-forcing state of one model: the spec, the heads (body.df_heads, built here when absent) and the
    layer modules the captures hook. forward() is the training forward of a micro-batch (letter logits exactly as
    student.label_logits, plus the auxiliary loss and its stats); probe() the evaluation readout."""

    def __init__(self, model, spec: DFSpec):
        from .student import body_layers
        validate_spec(spec)
        self.spec = spec
        root = model.model if getattr(model, "cotd_readout", False) else model
        self.body, _ = text_parts(root)
        self.dl = body_layers(self.body)
        n = len(self.dl)
        bad = [li for li in spec.layers if not 0 <= li <= n - 2]
        if bad:
            raise ValueError(f"--df-layers {list(spec.layers)}: layers {bad} out of 0..{n - 2} (of {n} decoder layers; "
                             "layer L + 1 must exist)")
        if getattr(self.body, "loop_untied", None) is not None:
            raise ValueError("depth forcing does not combine with LOOP-UNTIED")
        hidden = self.body.get_input_embeddings().weight.shape[1]
        heads = getattr(self.body, "df_heads", None)
        if heads is None:
            heads = DFHeads(hidden, spec).to(self.body.get_input_embeddings().weight.dtype)
            self.body.df_heads = heads
        self.heads = heads
        self._tok_cache: dict = {}

    # ---- helpers
    def n_params(self) -> int:
        return sum(p.numel() for p in self.heads.parameters())

    def layer_of(self, k: int) -> int:
        return self.spec.layers[k - 1]

    def _ids(self, tokenizer, s: str) -> list[int]:
        ids = self._tok_cache.get(s)
        if ids is None:
            ids = tokenizer.encode(s, add_special_tokens=False) or [tokenizer.pad_token_id or 0]
            self._tok_cache[s] = ids
        return ids

    def encode_values(self, model, tokenizer, strings: list[str]) -> torch.Tensor:
        """[n, dim]: proj(mean input embedding of the tokens of each string), the embeddings detached."""
        emb = self.body.get_input_embeddings().weight
        ids = [self._ids(tokenizer, s) for s in strings]
        L = max(len(x) for x in ids)
        mat = torch.zeros((len(ids), L), dtype=torch.long, device=emb.device)
        mask = torch.zeros((len(ids), L), dtype=emb.dtype, device=emb.device)
        for i, x in enumerate(ids):
            mat[i, :len(x)] = torch.tensor(x, device=emb.device)
            mask[i, :len(x)] = 1.0
        e = F.embedding(mat, emb.detach())                      # [n, L, hidden]
        mean = (e * mask.unsqueeze(-1)).sum(1) / mask.sum(1, keepdim=True)
        return self.heads.proj(mean.to(self.heads.proj.weight.dtype))

    # ---- the training forward
    def forward(self, model, tokenizer, batch: list[Example], max_len: int, label_ids_cache: dict, table: dict):
        """(letter logits as student.label_logits, auxiliary loss (mean over the supervised pairs; a zero without
        pairs), stats). stats: n (pairs), aux (float), per_k {k: [correct, n]}, cands (mean candidates per pair,
        contrast). table: item_id -> DFItem (build_table)."""
        body, head = text_parts(model)
        dev = head.weight.device
        b = collate(tokenizer, batch, max_len, dev)
        with _Capture(self.dl, self.spec.layers) as cap:
            res = body(input_ids=b["input_ids"], attention_mask=b["attention_mask"], output_hidden_states=False,
                       use_cache=False)
        hidden = res.last_hidden_state
        rows, last = torch.arange(hidden.shape[0], device=dev), b["last"]
        h = hidden[rows, last]
        out, softcap = [], logit_softcap(model)
        for i, e in enumerate(batch):
            key = tuple(e.labels)
            if key not in label_ids_cache:
                label_ids_cache[key] = torch.tensor(letter_token_ids(tokenizer, e.labels), device=dev)
            lrows = label_ids_cache[key]
            bias = head.bias[lrows] if getattr(head, "bias", None) is not None else None
            out.append(head_logits(h[i], head.weight[lrows], bias, softcap).float())
        missing = [li for li in self.spec.layers if li not in cap.h]
        if missing:
            raise RuntimeError(f"depth forcing: layers {missing} were not captured (is the model's decoder the one "
                               "the heads were built on?)")
        # Every head parameter enters the graph on every forward (x 0): FSDP2 reduce-scatters only the parameters
        # that received a gradient, so a rank whose micro-batch has no supervised pair must still produce (zero) head
        # gradients, or the ranks' collectives would differ.
        touch = sum(p.float().sum() for p in self.heads.parameters()) * 0.0
        pairs, where = [], []                                   # (example, k) and the token position read for it
        skipped = {"no_operand": 0, "truncated": 0}
        for i, e in enumerate(batch):
            d = table.get(e.item_id)
            if d is None or e.kind != "final":
                continue
            for k in range(1, len(d.targets) + 1):
                if self.spec.pos == "operand":
                    if d.ends[k - 1] is None:
                        skipped["no_operand"] += 1
                        continue
                    p = token_at(tokenizer, e.text, d.ends[k - 1], max_len)
                    if p is None:
                        skipped["truncated"] += 1
                        continue
                else:
                    p = int(last[i])
                pairs.append((i, k))
                where.append(p)
        live = [batch[i].weight > 0 for i, _ in pairs]          # weight 0 (an --fsdp pad): in the graph, not counted
        stats = {"n": sum(live), "aux": 0.0, "per_k": {k: [0, 0] for k in range(1, self.spec.K + 1)}, "cands": 0.0,
                 "skipped": skipped}
        if not pairs:
            return out, touch, stats
        ii = torch.tensor([i for i, _ in pairs], device=dev)
        pp = torch.tensor(where, device=dev)
        states = {li: cap.h[li][ii, pp] for li in self.spec.layers}      # [P, hidden] per layer, with gradient
        anchors = torch.stack([self.heads.head(k)(states[self.layer_of(k)][r]) for r, (_, k) in enumerate(pairs)]).float()
        weights = torch.tensor([batch[i].weight for i, _ in pairs], device=anchors.device, dtype=torch.float32)
        if self.spec.target == "contrast":
            losses, correct, ncand = self._contrast(model, tokenizer, batch, table, pairs, anchors)
            stats["cands"] = ncand
        else:
            losses, correct = self._digits(batch, table, pairs, anchors)
        aux = (losses * weights).sum() / max(1, stats["n"]) + touch   # the mean over the counted pairs
        for (i, k), c, ok in zip(pairs, correct, live):
            if ok:
                stats["per_k"][k][0] += int(c)
                stats["per_k"][k][1] += 1
        stats["aux"] = float(aux.detach())
        return out, aux, stats

    @staticmethod
    def candidates(batch, table, pairs) -> tuple:
        """The contrast candidates of a micro-batch: (strings: one per distinct numeric value (the first string seen
        encodes it), allowed: per pair the set of candidate indices (the item's targets, options and prompt numbers
        plus every item's targets in the micro-batch), pos: per pair the index of its target). The positive occurs
        once in its set: a candidate of the same numeric value is the same index."""
        strings, idx = [], {}                       # canonical value -> candidate index

        def add(s):
            c = canon_number(s)
            if c is None:
                c = str(s).strip()
                if not c:
                    return None
            if c not in idx:
                idx[c] = len(strings)
                strings.append(str(s))
            return idx[c]
        own: dict = {}                              # example index -> candidate indices of (a) (b) (d)
        tg_all: set = set()                         # (c): every item's targets in the micro-batch
        tgt_idx: dict = {}                          # example index -> [candidate index of target k]
        for i, e in enumerate(batch):
            d = table.get(e.item_id)
            if d is None or e.kind != "final":
                continue
            tgt_idx[i] = [add(t) for t in d.targets]
            s = set(tgt_idx[i])
            s.update(j for j in (add(o) for o in d.options) if j is not None)
            s.update(j for j in (add(x) for x in d.nums) if j is not None)
            own[i] = s
            tg_all.update(tgt_idx[i])
        allowed = [own[i] | tg_all for i, _ in pairs]
        pos = [tgt_idx[i][k - 1] for i, k in pairs]
        return strings, allowed, pos

    def _contrast(self, model, tokenizer, batch, table, pairs, anchors):
        """InfoNCE of every pair against its candidate set (see the module docstring); (per-pair losses, correct
        flags, mean candidates per pair)."""
        strings, allowed, pos = self.candidates(batch, table, pairs)
        E = F.normalize(self.encode_values(model, tokenizer, strings).float(), dim=-1)    # [C, dim]
        A = F.normalize(anchors, dim=-1)                                                  # [P, dim]
        sims = A @ E.T / self.spec.temperature
        allow = torch.zeros((len(pairs), len(strings)), dtype=torch.bool, device=sims.device)
        for r, cset in enumerate(allowed):
            allow[r, list(cset)] = True
        pos_t = torch.tensor(pos, device=sims.device)
        masked = sims.masked_fill(~allow, float("-inf"))
        losses = F.cross_entropy(masked, pos_t, reduction="none")                        # [P]
        correct = (masked.argmax(-1) == pos_t).tolist()
        return losses, correct, float(allow.sum(1).float().mean())

    def _digits(self, batch, table, pairs, anchors):
        codes = torch.tensor([digit_code(table[batch[i].item_id].targets[k - 1]) for i, k in pairs],
                             device=anchors.device)                                  # [P, 2 + DIGITS_N]
        losses, hits = [], torch.ones(len(pairs), dtype=torch.bool, device=anchors.device)
        off = 0
        for j, width in enumerate([2] + [10] * DIGITS_N + [EXP_HI - EXP_LO + 1]):
            z = anchors[:, off:off + width]
            losses.append(F.cross_entropy(z, codes[:, j], reduction="none"))
            hits &= z.argmax(-1) == codes[:, j]
            off += width
        return torch.stack(losses, 1).mean(1), hits.tolist()                              # [P]

    # ---- evaluation readout
    def probe(self, model, tokenizer, items: list[dict], max_len: int, bs: int, cache: dict) -> dict:
        """Per-layer probe accuracy on the items with worked steps (their own values; batches of bs by prompt length,
        the training candidate scheme): {"layers": [...], "n_items", "pairs": [n_k], "acc": [acc_k], "cands": mean
        candidates per pair (contrast)}."""
        table = build_table(items, self.spec, shuffle=False)
        its = [it for it in items if it["item_id"] in table]
        res = {"layers": list(self.spec.layers), "pos": self.spec.pos, "n_items": len(its), "pairs": [0] * self.spec.K,
               "acc": [None] * self.spec.K, "cands": None, "no_operand_position": no_operand_counts(table, self.spec.K)}
        if not its:
            return res
        was_training = model.training
        model.eval()
        dev = next(model.parameters()).device
        order = sorted(range(len(its)), key=lambda i: len(its[i]["prompt"]))
        per_k = {k: [0, 0] for k in range(1, self.spec.K + 1)}
        cands, nmb = 0.0, 0
        with torch.no_grad():
            for s in range(0, len(order), bs):
                idx = order[s:s + bs]
                from .student import final_text
                batch = [Example(final_text(tokenizer, its[i]["prompt"]), its[i]["labels"],
                                 [0.0] * len(its[i]["labels"]), 1.0, "final", its[i]["item_id"]) for i in idx]
                with torch.autocast("cuda", dtype=torch.bfloat16, enabled=dev.type == "cuda"):
                    _, _, st = self.call(model, tokenizer, batch, max_len, cache, table)
                for k, (c, n) in st["per_k"].items():
                    per_k[k][0] += c
                    per_k[k][1] += n
                cands += st["cands"] * st["n"]
                nmb += st["n"]
        if was_training:
            model.train()
        res["pairs"] = [per_k[k][1] for k in range(1, self.spec.K + 1)]
        res["acc"] = [round(per_k[k][0] / per_k[k][1], 4) if per_k[k][1] else None for k in range(1, self.spec.K + 1)]
        if self.spec.target == "contrast" and nmb:
            res["cands"] = round(cands / nmb, 2)
        return res

    def call(self, model, tokenizer, batch, max_len: int, cache: dict, table: dict):
        """forward() on a plain model, or inside the FSDP2 root's forward (cotdistill.fsdp.Readout.run) so the root
        unit's parameters (embeddings, heads) are unsharded while they are read."""
        if getattr(model, "cotd_readout", False):
            return model.run(self.forward, tokenizer, batch, max_len, cache, table)
        return self.forward(model, tokenizer, batch, max_len, cache, table)


class DFWindow:
    """The training log window of the auxiliary loss: micro-batch stats added since the last row (row() reads and
    resets), and the cumulative pair counts per k (totals)."""

    def __init__(self, K: int):
        self.K = K
        self.totals = [0] * K
        self.skipped = {"no_operand": 0, "truncated": 0}   # cumulative (--df-pos operand)
        self.reset()

    def reset(self) -> None:
        self.aux, self.mb, self.n = 0.0, 0, 0
        self.per_k = {k: [0, 0] for k in range(1, self.K + 1)}

    def add(self, st: dict) -> None:
        if st["n"]:
            self.aux += st["aux"]
            self.mb += 1
        self.n += st["n"]
        for k, (c, n) in st["per_k"].items():
            self.per_k[k][0] += c
            self.per_k[k][1] += n
            self.totals[k - 1] += n
        for key, v in st.get("skipped", {}).items():
            self.skipped[key] += v

    def add_reduced(self, aux_sum: float, mbs: int, per_k: list, no_operand: int = 0, truncated: int = 0) -> None:
        """--fsdp: the all-reduced sums of an update (aux over the micro-batches with pairs, their count, [c, n] per k,
        the skipped operand steps)."""
        self.aux += aux_sum
        self.mb += mbs
        for k, (c, n) in enumerate(per_k, 1):
            self.per_k[k][0] += c
            self.per_k[k][1] += n
            self.n += n
            self.totals[k - 1] += n
        self.skipped["no_operand"] += no_operand
        self.skipped["truncated"] += truncated

    def row(self, lam: float) -> dict:
        r = {"df_aux": self.aux / self.mb if self.mb else None, "loss_df": lam * self.aux / self.mb if self.mb else 0.0,
             "df_pairs": self.n,
             "df_acc": {str(k): (round(c / n, 4) if n else None) for k, (c, n) in self.per_k.items()}}
        self.reset()
        return r
