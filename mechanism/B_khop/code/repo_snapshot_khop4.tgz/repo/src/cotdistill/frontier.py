"""Frontier interchange training (arms F-SIIT, S-SIIT, CF-AUG, SHAM; card B3): the data layer.

A training item R with worked steps is a tiny program: step j computes value_j = a op b, where a / b are literals of the
question (a_from / b_from None) or earlier values (a_from / b_from = the 0-based index of the step). At a BOUNDARY k
(after k steps, k = 1..n-1) the FRONTIER F_k is the set of earlier steps whose values some later step consumes, U_k the
literals the later steps read, P_k the later steps themselves. Re-executing P_k with another item's frontier values gives
a COUNTERFACTUAL answer; the training arms write a source item's layer-L residual slice [0, d) at each frontier node's
token into the receiver's residual slice [0, d) at the receiver's token of the same node (one shared slice for every
node, each node at its own token; boundaries where two nodes share one token are excluded) and supervise the letter
toward that answer (Frontier, the training side, in this module's second half).

Positions: a frontier value "becomes computable" at the latest literal operand among its ancestors (operand_end of
depth_forcing), fallback the end of the question text; mapped to tokens with token_at on the example text (the question
prefix is unchanged by a new option block, so character offsets hold).

Partners (seed-keyed, fixed over the run, as teacher_partners): "size" = a boundary of another item with the same
frontier size whose counterfactual answer is a clean number different from the receiver's gold (S: F-SIIT, S-SIIT,
SHAM, the strictness views); "decoy" = up to RETRIES further same-size candidates per (R, k), the first whose
counterfactual is clean and differs in value from the gold and from cf(S) is the decoy S' (its cf(S') sits in every
intervened block, so the cf letter cannot be found by eliminating the gold and R's own distractors); "samevalue" = the
same frontier values, any program (the readout's `same` sanity rate); "match" = the same frontier values, literals and
program (counted only; no view uses it).

Strictness views (SIIT proper): the S write at a NON-aligned address, label = the gold: "pos" = S's slice [0, d) at a
question token that is no node position of any boundary of R; "sub" = at the aligned node tokens, but into the spare
slice [d, 2d). On val the same construction is the readout's misaligned_keep.

Learned subspace (--b3-rotate, card B3 v2 option (b)): the coordinate slices become the row blocks of a learned map Q
(2d x H, orthonormal rows, rotation()): Q0 = rows [0, d), Q1 = rows [d, 2d). A write takes the source's coordinates
Q0 h_s and puts them into the receiver's destination block Qs (s = the slot: Q0 aligned, Q1 spare), the rest of h_r
unchanged: h_r <- h_r - Qs^T Qs h_r + Qs^T Q0 h_s. Q starts at the first 2d coordinate axes, where this is the slice
copy bit for bit; it trains in its own optimizer group (rotation_groups), the source pass stays detached.

Option blocks: per (R, k) a 5-option block holding R's gold, cf(S), cf(S') and then R's own other options and numeric
fillers, letters shuffled by the seed; the prompt's Options block is rewritten the way permute_options does. The
evaluation items are never touched (the blocks exist only in training examples and in the readout's forced forwards).

Block-all (card B3 v2 section 1, --b3-block-all): the plain final example of every item whose intervened view exists
gets that view's block (the same boundary, S, S' and letter coins of the epoch), no write, label = the gold: mode
"blockplain". Without it a cf-style block carried a foreign label about 3 times as often as the gold, so the block
composition alone leaked the answer (the v1 pilot, block_plain gold 0.39).

Nothing here runs unless train_student.py --b3-arm is set.
"""
from __future__ import annotations

import random
import re
import time
from dataclasses import dataclass, field, replace
from fractions import Fraction

from .depth_forcing import _NUM, canon_number, operand_end, question_text, token_at
from .student import FINAL_TEMPLATE, Example, _OPT_LINE, worked_steps

B3_ARMS = ("fsiit", "ssiit", "cfaug", "sham")
B3_MODES = ("full", "single", "strict", "sham", "cfaug")
SLOT_ALIGNED, SLOT_SPARE = 0, 1          # destination slice of a write: [0, d) or [d, 2d) (the source slice is [0, d))
OPS = ("+", "−", "×", "÷", "% of")
N_OPTIONS = 5
LETTERS = ("A", "B", "C", "D", "E")
MAX_ABS = Fraction(10 ** 7)
RETRIES = 8                              # partner draws per boundary before giving up
ROT_FILE = "b3_rotation.pth"             # --b3-rotate: Q in the run dir (not .pt: the job's results tarball drops *.pt)


# ---------------------------------------------------------------------------------------------------- the program
def num(s) -> Fraction | None:
    """A number string of the data ('5', '12.5', '1,000', with the unicode minus) as a Fraction; None otherwise."""
    if s is None:
        return None
    t = str(s).strip().replace(",", "").replace("−", "-")
    try:
        return Fraction(t)
    except (ValueError, ZeroDivisionError):
        return None


def fmt(v: Fraction) -> str:
    """The data's spelling of a value: integers plain, decimals as short as exact ('12.5', '0.25')."""
    if v.denominator == 1:
        return str(v.numerator)
    s = f"{float(v):.6f}".rstrip("0").rstrip(".")
    return s if s not in ("", "-0") else "0"


def clean(v: Fraction | None) -> bool:
    """A value the data could hold: finite, 0 <= v < 1e7, at most two decimals (no training value is negative; a
    negative option would be out of distribution and a label tell)."""
    return v is not None and 0 <= v < MAX_ABS and (v * 100).denominator == 1


def apply_op(op: str, a: Fraction, b: Fraction) -> Fraction | None:
    if op == "+":
        return a + b
    if op == "−":
        return a - b
    if op == "×":
        return a * b
    if op == "÷":
        return a / b if b != 0 else None
    if op == "% of":
        return a * b / 100
    return None


@dataclass(frozen=True)
class Step:
    idx: int                             # 0-based position in the step list (what a_from / b_from refer to)
    op: str
    a: str                               # operand strings as the data writes them
    b: str
    a_from: int | None
    b_from: int | None
    value: Fraction


def program(item: dict) -> list[Step] | None:
    """The item's worked steps as Steps, in step order; None without steps or when an op, operand or value is not
    readable (such items are left to the plain arm)."""
    ws = worked_steps(item)
    if not ws:
        return None
    ws = sorted(ws, key=lambda s: s.get("step", 0))
    out = []
    for i, s in enumerate(ws):
        v = num(s.get("value"))
        if s.get("op") not in OPS or v is None:
            return None
        for key, fk in (("a", "a_from"), ("b", "b_from")):
            src = s.get(fk)
            if src is None:
                if num(s.get(key)) is None:
                    return None
            elif not 0 <= src < i:
                return None
        out.append(Step(i, s["op"], str(s.get("a")), str(s.get("b")), s.get("a_from"), s.get("b_from"), v))
    return out


def execute(steps: list[Step], k: int, env: dict) -> Fraction | None:
    """Runs steps k..n-1 with env = {earlier step index: value} (the frontier's values; the other earlier values are
    not read by definition) and returns the final value, or None when an operand is missing or a division fails."""
    vals = dict(env)
    for s in steps[k:]:
        a = vals.get(s.a_from) if s.a_from is not None else num(s.a)
        b = vals.get(s.b_from) if s.b_from is not None else num(s.b)
        if a is None or b is None:
            return None
        v = apply_op(s.op, a, b)
        if v is None:
            return None
        vals[s.idx] = v
    return vals.get(len(steps) - 1)


def gold_value(item: dict) -> Fraction | None:
    """The gold option's value."""
    try:
        return num(item["options"][item["labels"].index(item["gold_label"])])
    except (KeyError, ValueError, IndexError):
        return None


def program_ok(item: dict, steps: list[Step] | None = None) -> bool:
    """Does re-executing the whole program from the literals give the gold option? (5,689 of 5,696 train items.)"""
    steps = program(item) if steps is None else steps
    g = gold_value(item)
    return bool(steps) and g is not None and execute(steps, 0, {}) == g


# ---------------------------------------------------------------------------------------------------- boundaries
def frontier(steps: list[Step], k: int) -> tuple:
    """The earlier steps (< k) whose values a step >= k consumes, sorted."""
    return tuple(sorted({src for s in steps[k:] for src in (s.a_from, s.b_from) if src is not None and src < k}))


def literals(steps: list[Step], k: int) -> tuple:
    """U_k: the literal operands of steps >= k, in reading order."""
    out = []
    for s in steps[k:]:
        if s.a_from is None:
            out.append(num(s.a))
        if s.b_from is None:
            out.append(num(s.b))
    return tuple(out)


def wiring(steps: list[Step], k: int, F: tuple) -> tuple:
    """P_k's shape: per later step its op and where each operand comes from: ('F', node index), ('P', offset into P)
    or ('L',) a literal."""
    def src(i):
        if i is None:
            return ("L",)
        return ("F", F.index(i)) if i < k else ("P", i - k)
    return tuple((s.op, src(s.a_from), src(s.b_from)) for s in steps[k:])


def signature(steps: list[Step], k: int, F: tuple) -> tuple:
    """(frontier values, literals, wiring): equal signatures = the same computation from the boundary on."""
    return tuple(steps[i].value for i in F), literals(steps, k), wiring(steps, k, F)


def ancestors(steps: list[Step], i: int) -> set:
    out, stack = set(), [i]
    while stack:
        j = stack.pop()
        if j in out:
            continue
        out.add(j)
        for src in (steps[j].a_from, steps[j].b_from):
            if src is not None:
                stack.append(src)
    return out


def node_end(item: dict, steps: list[Step], i: int) -> int | None:
    """The character offset (exclusive) in the prompt where the value of step i becomes computable: the end of the
    latest literal operand among its ancestors (operand_end: standalone numbers, matched by value, question text
    only). None when no ancestor literal occurs in the question (the caller falls back to the end of the question)."""
    ends = []
    for j in ancestors(steps, i):
        s = steps[j]
        for lit, src in ((s.a, s.a_from), (s.b, s.b_from)):
            if src is None:
                e = operand_end(item["prompt"], {"a": lit, "b": None})
                if e is not None:
                    ends.append(e)
    return max(ends) if ends else None


def resolve_ends(item: dict, ends: tuple) -> tuple:
    """Node ends with the fallback applied: None -> the end of the question text. Returns (ends, fallbacks used)."""
    q = len(question_text(item["prompt"]))
    return tuple(q if e is None else e for e in ends), sum(e is None for e in ends)


def non_operand_end(item: dict, steps: list) -> int | None:
    """The end of the last number of the question that is not a literal operand of any step (the strictness view's
    non-aligned position); None when every number is an operand."""
    lits = {canon_number(s.a) for s in steps if s.a_from is None} | {canon_number(s.b) for s in steps if s.b_from is None}
    best = None
    for m in _NUM.finditer(question_text(item["prompt"])):
        if canon_number(m.group(0)) not in lits:
            best = m.end()
    return best


@dataclass
class Boundary:
    item_id: str
    k: int
    F: tuple                             # frontier step indices
    values: tuple                        # their values (Fraction)
    ends: tuple                          # per node: character end in the prompt, or None (fallback)
    sig: tuple                           # signature(steps, k, F)

    @property
    def size(self) -> int:
        return len(self.F)


def boundaries(item: dict, steps: list[Step]) -> list[Boundary]:
    """Every boundary of the item with a non-empty frontier."""
    out = []
    for k in range(1, len(steps)):
        F = frontier(steps, k)
        if F:
            out.append(Boundary(item["item_id"], k, F, tuple(steps[i].value for i in F),
                                tuple(node_end(item, steps, i) for i in F), signature(steps, k, F)))
    return out


def cf_answer(steps: list[Step], k: int, F: tuple, values: tuple) -> Fraction | None:
    """P_k re-executed with the frontier nodes set to values (node order = F order)."""
    return execute(steps, k, dict(zip(F, values)))


# ---------------------------------------------------------------------------------------------------- partners
def partners(bounds: dict, seed, kind: str, steps_of: dict, gold_of: dict) -> dict:
    """(item_id, k) -> (source item_id, source k) for every boundary that has a partner; kind 'size' (same frontier
    size, clean counterfactual answer different from the receiver's gold; up to RETRIES draws), 'match' (identical
    signature), 'samevalue' (same frontier values). Draws are keyed by the seed and the boundary, so the table is fixed
    over the run and equal across arms with the same seed. bounds: item_id -> [Boundary]."""
    flat = [b for bs in bounds.values() for b in bs]
    pools: dict = {}
    for b in flat:
        key = (b.size if kind == "size" else b.sig if kind == "match" else b.values)
        pools.setdefault(key, []).append(b)
    out = {}
    for b in flat:
        key = (b.size if kind == "size" else b.sig if kind == "match" else b.values)
        pool = [c for c in pools.get(key, ()) if c.item_id != b.item_id]
        if not pool:
            continue
        rng = random.Random(f"b3-partner|{kind}|{seed}|{b.item_id}|{b.k}")
        pick = None
        for _ in range(RETRIES):
            c = pool[rng.randrange(len(pool))]
            if kind != "size":
                pick = c
                break
            cf = cf_answer(steps_of[b.item_id], b.k, b.F, c.values)
            if clean(cf) and cf != gold_of[b.item_id]:
                pick = c
                break
        if pick is not None:
            out[(b.item_id, b.k)] = (pick.item_id, pick.k)
    return out


def decoy_candidates(bounds: dict, seed) -> dict:
    """(item_id, k) -> up to RETRIES (source item_id, source k) of the same frontier size (another item), drawn with
    random.Random(f"b3-decoy|{seed}|{item}|{k}"): the decoy S' is the first candidate whose counterfactual (for the
    view's write) is clean and differs in canonical value from the gold and from cf(S) (decoy_for). Fixed over the run
    and equal across arms with the same seed (F-SIIT and SHAM draw the same S')."""
    pools: dict = {}
    for bs in bounds.values():
        for b in bs:
            pools.setdefault(b.size, []).append(b)
    out = {}
    for bs in bounds.values():
        for b in bs:
            pool = [c for c in pools.get(b.size, ()) if c.item_id != b.item_id]
            if not pool:
                continue
            rng = random.Random(f"b3-decoy|{seed}|{b.item_id}|{b.k}")
            out[(b.item_id, b.k)] = tuple((c.item_id, c.k) for c in (pool[rng.randrange(len(pool))] for _ in range(RETRIES)))
    return out


def bound_of(table: dict, item_id, k: int) -> Boundary:
    return next(x for x in table[item_id].bounds if x.k == k)


def canon_value(v: Fraction) -> str:
    return canon_number(fmt(v))


def decoy_for(table: dict, b: Boundary, cf_of, avoid: tuple):
    """The decoy S' of boundary b: the first decoy candidate whose cf_of(its frontier values) is clean and whose
    canonical value is in no element of avoid (Fractions: the gold, cf(S)). Returns (source id, source k, cf(S'))
    or None (the view is dropped: draws no_decoy)."""
    bad = {canon_value(v) for v in avoid}
    for sid, sk in table["_partners"]["decoy"].get((b.item_id, b.k), ()):
        v = cf_of(bound_of(table, sid, sk).values)
        if clean(v) and canon_value(v) not in bad:
            return sid, sk, v
    return None


def shared_token(item: dict, b: Boundary) -> bool:
    """Two of b's nodes resolve to one character end (so to one token): the boundary is excluded (with one shared slice
    per token, the second write would overwrite the first)."""
    r, _ = resolve_ends(item, b.ends)
    return len(set(r)) < len(r)


def node_ends_all(item: dict, steps: list) -> set:
    """The resolved character ends of every frontier node of every boundary of the item (any size): the positions a
    'pos' strictness write must avoid."""
    q = len(question_text(item["prompt"]))
    used = {i for k in range(1, len(steps)) for i in frontier(steps, k)}
    return {q if e is None else e for e in (node_end(item, steps, i) for i in used)}


_UNIT = re.compile(r"\w+|[^\w\s]")


def free_ends(item: dict, steps: list) -> list:
    """Character ends of the question's units (words, numbers, punctuation; the tokenizers used never merge across
    whitespace, so distinct unit ends are distinct tokens) that are no node position of any boundary and lie inside no
    number whose end is a node position (the pieces of '1,000'). Sorted."""
    q = question_text(item["prompt"])
    avoid = node_ends_all(item, steps)
    spans = [(m.start(), m.end()) for m in _NUM.finditer(q) if m.end() in avoid]
    return [m.end() for m in _UNIT.finditer(q)
            if m.end() not in avoid and not any(s < m.end() <= e for s, e in spans)]


def free_number_ends(item: dict, steps: list) -> list:
    """The ends of the question's numbers (standalone, as operand_end reads them) that are no node position of any
    boundary: the preferred 'pos' tokens (a write on a number token, like the aligned writes, so token type cannot
    tell a misaligned write from an aligned one). Sorted."""
    avoid = node_ends_all(item, steps)
    return [m.end() for m in _NUM.finditer(question_text(item["prompt"])) if m.end() not in avoid]


# ---------------------------------------------------------------------------------------------------- option blocks
def render_options(prompt: str, options: list) -> str:
    """The prompt with its Options block replaced (permute_options' layout: 'X) text' lines after '\\nOptions:\\n')."""
    head, sep, _ = prompt.rpartition("\nOptions:\n")
    if not sep:
        raise ValueError("render_options: the prompt has no Options block")
    return head + sep + "\n".join(f"{L}) {o}" for L, o in zip(LETTERS, options))


def parse_options(prompt: str) -> list:
    _, sep, tail = prompt.rpartition("\nOptions:\n")
    if not sep:
        return []
    ms = [_OPT_LINE.match(line) for line in tail.split("\n")]
    return [m.group(2) for m in ms if m]


def option_block(item: dict, extra: list, rng: random.Random) -> tuple:
    """A 5-option block for a training view of item: the gold, every value of extra (counterfactual answers; those equal
    in value to the gold or to each other collapse), then the item's own other options (not equal in value to any of
    those), then numeric fillers gold + 1, gold + 2, ... until five; letters shuffled by rng. Returns (prompt with the
    block, options, gold index, {canonical extra value: index})."""
    gold = gold_value(item)
    texts, seen = [], set()

    def add(s):
        c = canon_number(s)
        if c is None or c in seen:
            return
        seen.add(c)
        texts.append(s)
    add(fmt(gold))
    for v in extra:
        add(fmt(v) if isinstance(v, Fraction) else str(v))
    if len(texts) > N_OPTIONS:
        raise ValueError(f"option_block: {len(texts)} answers for {N_OPTIONS} options")
    for o in parse_options(item["prompt"]) or item.get("options", []):
        if len(texts) >= N_OPTIONS:
            break
        add(o)
    step = 1
    while len(texts) < N_OPTIONS:
        add(fmt(gold + step))
        step += 1
    perm = list(range(N_OPTIONS))
    rng.shuffle(perm)
    options = [texts[j] for j in perm]
    where = {canon_number(t): options.index(t) for t in texts}
    return render_options(item["prompt"], options), options, where[canon_number(fmt(gold))], where


# ---------------------------------------------------------------------------------------------------- the spec and table
@dataclass
class B3Spec:
    arm: str                             # B3_ARMS
    layer: int = 19                      # the written layer (0-based decoder layer, its output)
    dim: int = 128                       # the written slice [0, d) (every node; strictness "sub": [d, 2d))
    p: float = 0.5                       # share of items whose plain example is replaced by an intervened one
    source_grad: bool = False            # gradient through the source forward
    strict: float = 1.0                  # weight of the strictness examples (0 = none)
    strict_share: float = 0.5            # among the substituted (intervened) views: the strictness share
    lam: float = 1.0                     # weight of the intervened examples
    max_nodes: int = 4                   # frontier nodes written (larger frontiers are skipped)
    seed: int = 0
    rotate: bool = False                 # the written subspaces are the row blocks of a learned Q (rotation())
    rotate_lr: float | None = None       # Q's learning rate (None = the base --lr)
    block_all: bool = False              # v2: every plain example of an item with a view gets the view's block (gold)

    def as_dict(self) -> dict:
        return {"arm": self.arm, "layer": int(self.layer), "dim": int(self.dim), "p": float(self.p),
                "source_grad": bool(self.source_grad), "strict": float(self.strict),
                "strict_share": float(self.strict_share), "lambda": float(self.lam), "max_nodes": int(self.max_nodes),
                "seed": int(self.seed), "rotate": bool(self.rotate),
                "rotate_lr": None if self.rotate_lr is None else float(self.rotate_lr),
                "block_all": bool(self.block_all)}


def validate_spec(spec: B3Spec) -> None:
    if spec.arm not in B3_ARMS:
        raise ValueError(f"--b3-arm {spec.arm}: one of {B3_ARMS}")
    if (spec.layer < 0 or spec.dim < 1 or not 0.0 <= spec.p <= 1.0 or spec.strict < 0 or spec.lam < 0
            or spec.max_nodes < 1 or not 0.0 <= spec.strict_share <= 1.0):
        raise ValueError("--b3-layer >= 0, --b3-dim >= 1, 0 <= --b3-p <= 1, --b3-strict >= 0, 0 <= --b3-strict-share <= 1, "
                         "--b3-lambda >= 0, --b3-max-nodes >= 1")
    if spec.rotate_lr is not None and not (spec.rotate and spec.rotate_lr > 0):
        raise ValueError(f"--b3-rotate-lr {spec.rotate_lr}: > 0, and only with --b3-rotate")


@dataclass
class B3Example(Example):
    """A training view with an interchange (a subclass: Example and the plain path are unchanged). mode: full (every
    frontier node written, label = the counterfactual answer), single (one node, label = its single-variable
    counterfactual), strict (a 'match' source written at non-aligned positions or in the spare subspace, label = the
    gold), sham (the full write, label = a distractor), cfaug (no write: a substituted question, label = its answer),
    blockplain (--b3-block-all: no write, the intervened view's block, label = the gold; nodes empty). nodes: per
    written node (receiver char end, source char end, destination slot: SLOT_ALIGNED = [0, d), SLOT_SPARE = [d, 2d);
    the source slice is always [0, d)), every end resolved (a node without an operand position falls back to the end
    of its question text; counted by the draw). source_text: the source's own final-question text (its
    original options), so the forward needs nothing but the example (as TeacherExample.teacher_text). cf_gold: the
    label's index in the block."""
    source_id: str | None = None
    source_text: str = ""
    k: int = 0
    k_src: int = 0
    nodes: tuple = ()
    cf_gold: int = 0
    mode: str = "full"
    orig_gold: int = 0
    cf_s: int = -1                       # the block index of cf(S) (-1: none in the block)
    decoy: int = -1                      # the block index of cf(S') (the decoy)
    decoy_id: str | None = None          # S'
    variant: str = ""                    # strict: 'pos' | 'sub'
    avoid: tuple = ()                    # strict 'pos': R's node character ends (the forward refuses a write there)


@dataclass
class ItemPlan:
    item_id: str
    steps: list
    bounds: list                         # Boundary, the usable ones (size <= max_nodes)
    gold: Fraction
    excluded: str = ""                   # why the item has no B3 views ("" = usable)


def build_table(items: list, spec: B3Spec) -> dict:
    """item_id -> ItemPlan for every item with a readable program; plus the partner tables under the key "_partners"
    ({"size", "match", "samevalue"}), the pool of question literals under "_literals" (CF-AUG) and counts under
    "_counts"."""
    plans: dict = {}
    bounds: dict = {}
    steps_of: dict = {}
    gold_of: dict = {}
    counts = {"items": len(items), "with_steps": 0, "program_ok": 0, "usable": 0, "boundaries": 0,
              "size_hist": {}, "nodes": 0, "nodes_with_position": 0, "excluded": {}}
    for it in items:
        if not worked_steps(it):
            continue
        counts["with_steps"] += 1
        steps = program(it)
        if steps is None:
            counts["excluded"]["unreadable"] = counts["excluded"].get("unreadable", 0) + 1
            plans[it["item_id"]] = ItemPlan(it["item_id"], [], [], Fraction(0), "unreadable")
            continue
        if not program_ok(it, steps):
            counts["excluded"]["program_mismatch"] = counts["excluded"].get("program_mismatch", 0) + 1
            plans[it["item_id"]] = ItemPlan(it["item_id"], steps, [], Fraction(0), "program_mismatch")
            continue
        counts["program_ok"] += 1
        bs = [b for b in boundaries(it, steps) if b.size <= spec.max_nodes]
        shared = [b for b in bs if shared_token(it, b)]
        if "\nOptions:\n" not in it["prompt"]:
            counts["excluded"]["no_options_block"] = counts["excluded"].get("no_options_block", 0) + 1
            plans[it["item_id"]] = ItemPlan(it["item_id"], steps, [], gold_value(it), "no_options_block")
            continue
        if not bs:
            counts["excluded"]["no_frontier"] = counts["excluded"].get("no_frontier", 0) + 1
            plans[it["item_id"]] = ItemPlan(it["item_id"], steps, [], gold_value(it), "no_frontier")
            continue
        counts["usable"] += 1
        if shared:                       # boundaries (not items): two nodes on one token
            counts["excluded"]["shared_token"] = counts["excluded"].get("shared_token", 0) + len(shared)
            bs = [b for b in bs if b not in shared]
            if not bs:
                counts["items_all_shared"] = counts.get("items_all_shared", 0) + 1
        counts["boundaries"] += len(bs)
        for b in bs:
            counts["size_hist"][str(b.size)] = counts["size_hist"].get(str(b.size), 0) + 1
            counts["nodes"] += b.size
            counts["nodes_with_position"] += sum(e is not None for e in b.ends)
        plans[it["item_id"]] = ItemPlan(it["item_id"], steps, bs, gold_value(it))
        bounds[it["item_id"]] = bs
        steps_of[it["item_id"]] = steps
        gold_of[it["item_id"]] = gold_value(it)
    part = {kind: partners(bounds, spec.seed, kind, steps_of, gold_of) for kind in ("size", "match", "samevalue")}
    part["decoy"] = decoy_candidates(bounds, spec.seed)
    counts["partners"] = {k: len(v) for k, v in part.items() if k != "decoy"}
    counts.setdefault("items_all_shared", 0)
    counts["excluded"].setdefault("shared_token", 0)
    counts["items_with_size_partner"] = len({iid for iid, _ in part["size"]})
    counts["items_with_match_partner"] = len({iid for iid, _ in part["match"]})
    lits = sorted({fmt(v) for pl in plans.values() if not pl.excluded for s in pl.steps
                   for v, src in ((num(s.a), s.a_from), (num(s.b), s.b_from)) if src is None and v is not None},
                  key=lambda s: (len(s), s))
    plans["_partners"] = part
    plans["_literals"] = lits
    plans["_counts"] = counts
    return plans


# ---------------------------------------------------------------------------------------------------- the per-epoch draw
def coin(seed, salt: str, item_id) -> random.Random:
    return random.Random(f"b3|{salt}|{seed}|{item_id}")


def substitute_literals(prompt: str, mapping: dict) -> str | None:
    """CF-AUG: the question text with every standalone occurrence of each literal (matched by value) replaced by its
    new spelling; None when a literal does not occur. The Options block is left for option_block."""
    q = question_text(prompt)
    rest = prompt[len(q):]
    found = {c: False for c in mapping}

    def sub(m):
        c = canon_number(m.group(0))
        if c in mapping:
            found[c] = True
            return mapping[c]
        return m.group(0)
    q2 = _NUM.sub(sub, q)
    if not all(found.values()):
        return None
    return q2 + rest


def _tally(why, key: str) -> None:
    if why is not None:
        why[key] = why.get(key, 0) + 1


def own_in_block(item: dict, options: list, extra: list) -> int:
    """How many of the block's options are R's own distractors (not the gold, not an extra value); the rest of the
    block beyond gold + extras is numeric fillers."""
    g = canon_value(gold_value(item))
    taken = {g} | {canon_value(v) for v in extra}
    own = {canon_number(o) for o in (parse_options(item["prompt"]) or item.get("options", []))} - taken
    return sum(canon_number(o) in own for o in options)


def make_example(item: dict, plan: ItemPlan, table: dict, spec: B3Spec, items_by: dict, epoch: int = 0,
                 weight: float = 1.0, why: dict | None = None):
    """The item's intervened view for this epoch, or None (then the plain example stands): the boundary is drawn
    uniformly among the item's usable boundaries with a 'size' partner S; the mode follows the arm (fsiit -> full,
    ssiit -> single with a uniformly drawn node, sham -> sham, cfaug -> cfaug). Every written view's block holds the
    gold, cf(S) and cf(S') (the decoy, decoy_for; no valid S' -> None, why["no_decoy"]); S-SIIT's cf(S) / cf(S') are
    the single-node counterfactuals at the drawn node (drawn among the nodes where both are clean, distinct and not the
    gold). SHAM: S's write, the label cf(S) or cf(S') with probability 1/2 each (the view's rng), so the label carries
    no information about the write. Returns (B3Example, info) with info the counts to log (fallback positions, size,
    k, own distractors in the block)."""
    if plan.excluded:
        return None
    rng = coin(spec.seed, f"draw{epoch}", item.get("item_id"))
    if spec.arm == "cfaug":
        return _cfaug_example(item, plan, table, spec, rng, weight)   # no write: the shared-token rule does not apply
    cands = [b for b in plan.bounds if (b.item_id, b.k) in table["_partners"]["size"]]
    if not cands:
        return None
    b = cands[rng.randrange(len(cands))]
    sid, sk = table["_partners"]["size"][(b.item_id, b.k)]
    sb = bound_of(table, sid, sk)
    node = None
    if spec.arm == "ssiit":                   # the single-variable counterfactuals of every node, S and S'
        def single(j):
            def f(values):
                vals = list(b.values)
                vals[j] = values[j]
                return cf_answer(plan.steps, b.k, b.F, tuple(vals))
            return f
        ok_s = {}
        for j in range(b.size):
            v = single(j)(sb.values)
            if clean(v) and v != plan.gold:
                ok_s[j] = v
        if not ok_s:
            return None
        decoys = {}
        for j, v in ok_s.items():
            d_ = decoy_for(table, b, single(j), (plan.gold, v))
            if d_ is not None:
                decoys[j] = d_
        if not decoys:
            _tally(why, "no_decoy")
            return None
        node = sorted(decoys)[rng.randrange(len(decoys))]
        label_v, dec = ok_s[node], decoys[node]
    else:
        label_v = cf_answer(plan.steps, b.k, b.F, sb.values)
        dec = decoy_for(table, b, lambda v: cf_answer(plan.steps, b.k, b.F, v), (plan.gold, label_v))
        if dec is None:
            _tally(why, "no_decoy")
            return None
    did, _, dec_v = dec
    text, options, gold_idx, where = option_block(item, [label_v, dec_v], coin(spec.seed, f"opts{epoch}", item["item_id"]))
    cf_i, dec_i = where[canon_value(label_v)], where[canon_value(dec_v)]
    if spec.arm == "fsiit":
        cf_idx, mode, nodes = cf_i, "full", tuple(range(b.size))
    elif spec.arm == "ssiit":
        cf_idx, mode, nodes = cf_i, "single", (node,)
    else:                                     # sham: S's full write, the label cf(S) or cf(S') by a fair coin
        cf_idx, mode, nodes = (cf_i if rng.random() < 0.5 else dec_i), "sham", tuple(range(b.size))
    target = [1.0 if i == cf_idx else 0.0 for i in range(N_OPTIONS)]
    src_item = items_by[sid]
    r_ends, _ = resolve_ends(item, b.ends)
    s_ends, _ = resolve_ends(src_item, sb.ends)
    ex = B3Example(FINAL_TEMPLATE.format(problem=text), list(LETTERS), target, weight * spec.lam, "final",
                   item["item_id"], cf_idx, source_id=sid, source_text=FINAL_TEMPLATE.format(problem=src_item["prompt"]),
                   k=b.k, k_src=sk, nodes=tuple((r_ends[j], s_ends[j], SLOT_ALIGNED) for j in nodes), cf_gold=cf_idx,
                   mode=mode, orig_gold=gold_idx, cf_s=cf_i, decoy=dec_i, decoy_id=did)
    info = {"fallback": sum(b.ends[j] is None for j in nodes) + sum(sb.ends[j] is None for j in nodes),
            "size": b.size, "k": b.k, "own": own_in_block(item, options, [label_v, dec_v])}
    return ex, info


def strict_nodes(item: dict, plan: ItemPlan, b: Boundary, sb: Boundary, src_item: dict, variant: str,
                 rng: random.Random):
    """The writes of a strictness view (S's slice [0, d) at each node's source token): 'pos' = each node at its own
    question token that is no node position of any boundary of R, drawn without replacement, destination [0, d):
    free NUMBER tokens first (free_number_ends; every node on a number token -> variant 'pos_num'); only when the item
    has fewer free numbers than nodes are its free numbers completed by other free tokens (free_ends; variant
    'pos_other'). 'sub' = the aligned node tokens, destination [d, 2d). Returns (nodes, avoid, variant) or None when
    'pos' has fewer free tokens than nodes (the view is skipped)."""
    s_ends, _ = resolve_ends(src_item, sb.ends)
    if variant == "pos":
        nums = free_number_ends(item, plan.steps)
        if len(nums) >= b.size:
            at, variant = rng.sample(nums, b.size), "pos_num"
        else:
            others = [e for e in free_ends(item, plan.steps) if e not in set(nums)]
            if len(nums) + len(others) < b.size:
                return None
            at = rng.sample(nums, len(nums)) + rng.sample(others, b.size - len(nums))
            variant = "pos_other"
        return (tuple((at[j], s_ends[j], SLOT_ALIGNED) for j in range(b.size)),
                tuple(sorted(node_ends_all(item, plan.steps))), variant)
    r_ends, _ = resolve_ends(item, b.ends)
    return tuple((r_ends[j], s_ends[j], SLOT_SPARE) for j in range(b.size)), (), "sub"


def strict_example(item: dict, plan: ItemPlan, table: dict, spec: B3Spec, items_by: dict, epoch: int = 0,
                   weight: float = 1.0, why: dict | None = None):
    """The SIIT strictness view: the boundary and its size partner S drawn as for the intervened views (a partner with
    different frontier values: cf(S) != gold), S written at a NON-aligned address (strict_nodes; a fair coin picks
    'pos' or 'sub'), label = the gold. The block is the intervened views' block (gold, cf(S), cf(S'), same generator),
    so the block cannot tell a strictness view from an intervened one; only the address can. None without a size
    partner, without a valid S' (why["strict_no_decoy"]) or, for 'pos', without enough free tokens
    (why["strict_skip"])."""
    if plan.excluded:
        return None
    cands = [b for b in plan.bounds if (b.item_id, b.k) in table["_partners"]["size"]]
    if not cands:
        return None
    rng = coin(spec.seed, f"strict{epoch}", item["item_id"])
    b = cands[rng.randrange(len(cands))]
    sid, sk = table["_partners"]["size"][(b.item_id, b.k)]
    sb = bound_of(table, sid, sk)
    cf_v = cf_answer(plan.steps, b.k, b.F, sb.values)
    dec = decoy_for(table, b, lambda v: cf_answer(plan.steps, b.k, b.F, v), (plan.gold, cf_v))
    if dec is None:
        _tally(why, "strict_no_decoy")
        return None
    did, _, dec_v = dec
    variant = "pos" if rng.random() < 0.5 else "sub"
    src_item = items_by[sid]
    w = strict_nodes(item, plan, b, sb, src_item, variant, rng)
    if w is None:
        _tally(why, "strict_skip")
        return None
    nodes, avoid, variant = w
    text, options, gold_idx, where = option_block(item, [cf_v, dec_v], coin(spec.seed, f"sopts{epoch}", item["item_id"]))
    target = [1.0 if i == gold_idx else 0.0 for i in range(N_OPTIONS)]
    ex = B3Example(FINAL_TEMPLATE.format(problem=text), list(LETTERS), target, weight * spec.strict, "final",
                   item["item_id"], gold_idx, source_id=sid, source_text=FINAL_TEMPLATE.format(problem=src_item["prompt"]),
                   k=b.k, k_src=sk, nodes=nodes, cf_gold=gold_idx, mode="strict", orig_gold=gold_idx,
                   cf_s=where[canon_value(cf_v)], decoy=where[canon_value(dec_v)], decoy_id=did, variant=variant,
                   avoid=avoid)
    return ex, {"fallback": sum(sb.ends[j] is None for j in range(b.size)), "size": b.size, "k": b.k,
                "variant": variant, "own": own_in_block(item, options, [cf_v, dec_v])}


def _cfaug_example(item: dict, plan: ItemPlan, table: dict, spec: B3Spec, rng: random.Random, weight: float):
    """CF-AUG: the question with its literal operands replaced by other literals of the data, the answer recomputed, a
    fresh option block; no intervention. Only literals that occur in the question are replaced (59% of items carry an
    implicit literal such as the 2 of "twice", the 100 of a percentage or the 60 of an hour; those stay); each
    replacement is an integer literal of the pool with the same number of digits (decimal literals stay), so magnitudes
    are preserved; up to 4 x RETRIES draws until every intermediate value is clean and non-negative and the answer
    differs from the gold. None when no literal occurs in the question or no draw succeeds."""
    steps = plan.steps
    own = {}
    for s in steps:
        for lit, src in ((s.a, s.a_from), (s.b, s.b_from)):
            if src is None and operand_end(item["prompt"], {"a": lit, "b": None}) is not None:
                v = num(lit)
                if v is not None and v.denominator == 1 and v >= 0:
                    own[canon_number(lit)] = v
    if not own:
        return None
    by_len = table.setdefault("_literals_by_len", {})
    if not by_len:
        for l in table["_literals"]:
            if "." not in l and "-" not in l:
                by_len.setdefault(len(l), []).append(l)
    for _ in range(4 * RETRIES):
        mapping = {}
        for c, v in own.items():
            pool = by_len.get(len(fmt(v))) or table["_literals"]
            mapping[c] = pool[rng.randrange(len(pool))]
        if all(mapping[c] == fmt(v) for c, v in own.items()):
            continue
        new_steps = [Step(s.idx, s.op, mapping.get(canon_number(s.a), s.a) if s.a_from is None else s.a,
                          mapping.get(canon_number(s.b), s.b) if s.b_from is None else s.b, s.a_from, s.b_from, s.value)
                     for s in steps]
        vals = {}
        ok = True
        for s in new_steps:
            a = vals.get(s.a_from) if s.a_from is not None else num(s.a)
            b_ = vals.get(s.b_from) if s.b_from is not None else num(s.b)
            v = apply_op(s.op, a, b_) if a is not None and b_ is not None else None
            if not clean(v) or v < 0:
                ok = False
                break
            vals[s.idx] = v
        if not ok:
            continue
        answer = vals[len(steps) - 1]
        if answer == plan.gold:
            continue
        prompt = substitute_literals(item["prompt"], mapping)
        if prompt is None:
            return None
        # the substituted item: its answer first (gold = label A), the original options as the distractor pool
        fake = dict(item, prompt=prompt, options=[fmt(answer)] + list(item["options"]), gold_label=LETTERS[0],
                    labels=list(LETTERS))
        text, options, gold_idx, _ = option_block(fake, [], coin(spec.seed, "cfaug-opts", item["item_id"]))
        target = [1.0 if i == gold_idx else 0.0 for i in range(N_OPTIONS)]
        ex = B3Example(FINAL_TEMPLATE.format(problem=text), list(LETTERS), target, weight * spec.lam, "final",
                       item["item_id"], gold_idx, source_id=None, k=0, k_src=0, nodes=(), cf_gold=gold_idx,
                       mode="cfaug", orig_gold=gold_idx)
        return ex, {"fallback": 0, "size": 0, "k": 0}
    return None


def block_plain(item: dict, plan: ItemPlan, table: dict, spec: B3Spec, items_by: dict, epoch: int, plain: Example):
    """--b3-block-all: the item's plain final example in the block of this epoch's intervened view (make_example with
    the epoch's coins: the same boundary draw, S, S' and letter coin, so the block is the one an intervened view of the
    item would show), no write, label = the gold: a B3Example of mode "blockplain" with the plain example's weight,
    target one-hot at the gold's index in the new block (the remap is an index change; the A2 teacher on gsmvt is
    one-hot gold), cf_s / decoy = the block indices of cf(S) / cf(S'). S-SIIT: its single-node block; F-SIIT, SHAM and
    CF-AUG: the full-frontier block (SHAM and CF-AUG draw it as F-SIIT does, so the four arms' plain blocks match;
    SHAM's own view draws the same block, its label coin comes after the block). None when the item has no such view (no boundary with a size
    partner and a valid S'; the original example stands: its block holds no foreign value). The view's own tallies
    (no_decoy) are not counted: the item was not drawn for a view."""
    sp = spec if spec.arm in ("fsiit", "ssiit") else replace(spec, arm="fsiit")
    out = make_example(item, plan, table, sp, items_by, epoch=epoch, weight=1.0, why={})
    if out is None:
        return None
    v = out[0]
    target = [1.0 if i == v.orig_gold else 0.0 for i in range(N_OPTIONS)]
    return B3Example(v.text, list(LETTERS), target, plain.weight, "final", item["item_id"], v.orig_gold, source_id=None,
                     source_text="", k=v.k, k_src=v.k_src, nodes=(), cf_gold=v.orig_gold, mode="blockplain",
                     orig_gold=v.orig_gold, cf_s=v.cf_s, decoy=v.decoy, decoy_id=v.decoy_id)


def _plain(exs: list, item: dict, plan, table: dict, spec: B3Spec, items_by: dict, epoch: int, counts: dict) -> list:
    """The plain example stands (counts plain); under --b3-block-all it is replaced by its blockplain twin where one
    exists (counts blockplain, else block_orig; blockplain_soft: the original target was not one-hot, so the remap
    dropped teacher mass)."""
    counts["plain"] = counts.get("plain", 0) + 1
    if not spec.block_all:
        return exs
    bp = None
    if plan is not None and not plan.excluded and exs and isinstance(exs[-1], Example) and exs[-1].kind == "final":
        bp = block_plain(item, plan, table, spec, items_by, epoch, exs[-1])
    if bp is None:
        counts["block_orig"] = counts.get("block_orig", 0) + 1
        return exs
    counts["blockplain"] = counts.get("blockplain", 0) + 1
    if max(exs[-1].target) != 1.0:
        counts["blockplain_soft"] = counts.get("blockplain_soft", 0) + 1
    return exs[:-1] + [bp]


def substitute(exs: list, item: dict, plan, table: dict, spec: B3Spec, items_by: dict, epoch: int, counts: dict) -> list:
    """The trainer's per-item substitution: with probability spec.p (a seed-keyed coin per item and epoch) the item's
    plain final example is replaced by its intervened view (make_example); with probability spec.strict_share among
    those, by the strictness view instead (strict_example; not for cfaug), falling back to the intervened view when no
    strictness view exists (strict_fallback, with its reason strict_no_decoy / strict_skip). The number of examples
    never changes (same forwards per update as the plain arm). counts: tallies of what was drawn; a view dropped for
    want of a valid decoy S' counts in no_decoy (and in no_view / plain: the plain example stands). spec.block_all:
    every plain example that stands goes through block_plain (_plain); the coins above are drawn exactly as without
    the flag, so the intervened and strictness views are unchanged."""
    if plan is None or plan.excluded or not exs or not isinstance(exs[-1], Example) or exs[-1].kind != "final":
        return _plain(exs, item, plan, table, spec, items_by, epoch, counts)
    rng = coin(spec.seed, f"sub{epoch}", item["item_id"])
    if rng.random() >= spec.p:
        return _plain(exs, item, plan, table, spec, items_by, epoch, counts)
    out = None
    why: dict = {}
    if spec.arm != "cfaug" and spec.strict > 0 and rng.random() < spec.strict_share:
        out = strict_example(item, plan, table, spec, items_by, epoch=epoch, weight=exs[-1].weight, why=why)
        if out is None:
            counts["strict_fallback"] = counts.get("strict_fallback", 0) + 1
    if out is None:
        out = make_example(item, plan, table, spec, items_by, epoch=epoch, weight=exs[-1].weight, why=why)
    for key, n in why.items():
        counts[key] = counts.get(key, 0) + n
    if out is None:
        res = _plain(exs, item, plan, table, spec, items_by, epoch, counts)
        counts["no_view"] = counts.get("no_view", 0) + 1     # after plain: the draws' key order is v1's
        return res
    ex, info = out
    counts[ex.mode] = counts.get(ex.mode, 0) + 1
    if ex.mode == "strict":
        counts[f"strict_{ex.variant}"] = counts.get(f"strict_{ex.variant}", 0) + 1
    counts["fallback"] = counts.get("fallback", 0) + info.get("fallback", 0)
    hist = counts.setdefault("nodes_hist", {})
    hist[str(len(ex.nodes))] = hist.get(str(len(ex.nodes)), 0) + 1
    if ex.mode != "cfaug":
        kh = counts.setdefault("k_hist", {})            # the boundaries used, per k
        kh[str(ex.k)] = kh.get(str(ex.k), 0) + 1
    return exs[:-1] + [ex]


# ---------------------------------------------------------------------------------------------------- the training forward
STAT_MODES = ("full", "single", "strict", "sham", "cfaug", "plain", "blockplain")   # plain: the plain Examples of the
#                                         receiver pass; blockplain: --b3-block-all's plain views (gold label, cf block)
STAT_LEN = 4 * len(STAT_MODES) + 2     # per mode [n, ce sum, hits, views with a cut write], then cut writes, sources


def empty_stats() -> dict:
    """modes: per mode [n, CE sum, hits, cut views]; cut: cut writes; n_src: real source texts; cut_rows: the batch
    indices of views with a cut write (forward only; not in the --fsdp vector)."""
    return {"modes": {m: [0, 0.0, 0, 0] for m in STAT_MODES}, "cut": 0, "n_src": 0, "cut_rows": []}


def stats_vector(st: dict) -> list:
    """The stats as a flat list of floats (the --fsdp all-reduce buffer; stats_from_vector inverts it)."""
    v = []
    for m in STAT_MODES:
        v.extend(st["modes"][m])
    return v + [st["cut"], st["n_src"]]


def stats_from_vector(v) -> dict:
    st = empty_stats()
    for i, m in enumerate(STAT_MODES):
        st["modes"][m] = [int(v[4 * i]), float(v[4 * i + 1]), int(v[4 * i + 2]), int(v[4 * i + 3])]
    st["cut"], st["n_src"] = int(v[-2]), int(v[-1])
    return st


def _rate(h: int, n: int):
    return round(h / n, 4) if n else None


def readout_summary(preds: list, kinds: list, meta: list, cut: list | None = None) -> dict:
    """The readout's numbers from the predicted letter indices of its views (kinds / meta as Frontier.readout builds
    them; meta: the block indices gold / cf / decoy and, for misaligned / same, the un-intervened twin's index). cut:
    per view, whether a write was cut (token outside the sequence, on an avoid token, or a duplicate (row, token,
    slot)); such a view enters no rate and is counted in its dict's "cut" (a cut misaligned view would otherwise be its
    twin's forward and count as kept)."""
    cut = cut or [False] * len(preds)
    tal = {"cf11": [0, 0, 0, 0], "cf1": [0, 0, 0, 0]}    # n, cf picks, decoy picks, cut
    bp = [0, 0, 0, 0, 0]                                 # n, gold, cf, decoy, cut
    mis = {"sub": [0, 0], "pos_num": [0, 0], "pos_other": [0, 0]}   # n, kept
    mis_cut = 0
    same = [0, 0, 0, 0]                                  # n, kept, gold, cut
    for i, (p, kind, m) in enumerate(zip(preds, kinds, meta)):
        if kind in tal:
            t = tal[kind]
            if cut[i]:
                t[3] += 1
                continue
            t[0] += 1
            t[1] += int(p == m["cf"])
            t[2] += int(p == m["decoy"])
        elif kind == "block_plain":
            if cut[i]:
                bp[4] += 1
                continue
            bp[0] += 1
            bp[1] += int(p == m["gold"])
            bp[2] += int(p == m["cf"])
            bp[3] += int(p == m["decoy"])
        elif kind == "misaligned":
            if cut[i]:
                mis_cut += 1
                continue
            mis[m["variant"]][0] += 1
            mis[m["variant"]][1] += int(p == preds[m["twin"]])
        elif kind == "same":
            if cut[i]:
                same[3] += 1
                continue
            same[0] += 1
            same[1] += int(p == preds[m["twin"]])
            same[2] += int(p == m["gold"])
    out = {}
    for kind, (n, c, d, k) in tal.items():
        out[kind] = {"n": n, "acc": _rate(c, n), "decoy": _rate(d, n), "ratio": _rate(c, c + d), "cut": k}
    out["block_plain"] = {"n": bp[0], "gold": _rate(bp[1], bp[0]), "cf": _rate(bp[2], bp[0]),
                          "decoy": _rate(bp[3], bp[0]), "cut": bp[4]}
    out["misaligned_keep"] = {v: {"n": n, "keep": _rate(k, n)} for v, (n, k) in mis.items()}
    out["misaligned_keep"]["cut"] = mis_cut
    out["same"] = {"n": same[0], "keep": _rate(same[1], same[0]), "gold": _rate(same[2], same[0]), "cut": same[3]}
    return out


TIERS = ("G-strong", "G-weak", "G-fail")


def tier(ro: dict, cf_key: str = "cf11") -> str:
    """The mechanism tier of one readout dict (card B3 Amendment 1 F.5, fractions): G-strong = cf.acc >= 0.60 and
    cf.ratio >= 0.80 and keep_sub >= 0.95 and keep_pos_num >= 0.95; G-fail = cf.acc < 0.40 or cf.ratio < 0.70 or
    either keep < 0.90; G-weak = the rest (a mixed row such as acc 0.70 with ratio 0.65 is G-fail; acc 0.70 with
    ratio 0.75 is G-weak). A missing value (n = 0) counts as failing. cf_key "cf11" (F-SIIT, SHAM) or "cf1"
    (S-SIIT, Amendment B)."""
    mk = ro.get("misaligned_keep", {})
    vals = {"acc": ro.get(cf_key, {}).get("acc"), "ratio": ro.get(cf_key, {}).get("ratio"),
            "sub": mk.get("sub", {}).get("keep"), "pos_num": mk.get("pos_num", {}).get("keep")}
    if any(v is None for v in vals.values()):
        return "G-fail"
    if vals["acc"] < 0.40 or vals["ratio"] < 0.70 or vals["sub"] < 0.90 or vals["pos_num"] < 0.90:
        return "G-fail"
    if vals["acc"] >= 0.60 and vals["ratio"] >= 0.80 and vals["sub"] >= 0.95 and vals["pos_num"] >= 0.95:
        return "G-strong"
    return "G-weak"


class _SliceWrite:

    """A forward hook on decoder layer li that overwrites slices of its output: writes = [(row, pos, lo, hi, vec)].
    As student._LayerCapture.force: layer li runs without gradient checkpointing while the context is open (a
    checkpointed layer would recompute its forward in backward after the hook is gone and drop the write from the
    gradient); the flag is restored on exit. A context manager over one forward.
    rot (--b3-rotate): Q (2d x H, fp32, in the graph); then vec is the source's full hidden state and [lo, hi) names
    the destination rows Qs of Q, the source rows are Q0 = Q[0, hi - lo): h <- h - Qs^T (Qs h) + Qs^T (Q0 vec), in fp32
    (autocast off) and cast back to h's dtype. Element-wise products and sums, not matmuls: at Q = the coordinate axes
    every product is x * 1 or x * 0, so the result is the slice write bit for bit whatever the matmul precision (TF32)."""

    def __init__(self, layer, writes: list, rot=None):
        self.layer, self.writes, self.handle, self._ckpt, self.rot = layer, writes, None, False, rot

    def __enter__(self):
        if getattr(self.layer, "gradient_checkpointing", False):
            self._ckpt = True
            self.layer.gradient_checkpointing = False

        def post(mod, args, out):
            h = out[0] if isinstance(out, tuple) else out
            h = h.clone()
            if self.rot is None:
                for row, pos, lo, hi, vec in self.writes:
                    h[row, pos, lo:hi] = vec.to(h.device, h.dtype)
            else:
                import torch
                Q = self.rot.to(h.device)
                with torch.autocast(h.device.type, enabled=False):
                    for row, pos, lo, hi, vec in self.writes:
                        qs, q0 = Q[lo:hi], Q[0:hi - lo]
                        hr = h[row, pos].float().clone()     # a copy: the in-place write below must not touch
                        #                                        what autograd saved (fp32 h: .float() is a view)
                        src = (q0 * vec.to(h.device).float()).sum(-1)          # Q0 h_s (d)
                        own = (qs * hr).sum(-1)                                 # Qs h_r (d)
                        hr = hr - (qs * own[:, None]).sum(0) + (qs * src[:, None]).sum(0)
                        h[row, pos] = hr.to(h.dtype)
            return (h,) + tuple(out[1:]) if isinstance(out, tuple) else h
        self.handle = self.layer.register_forward_hook(post)
        return self

    def __exit__(self, *exc):
        self.handle.remove()
        if self._ckpt:
            self.layer.gradient_checkpointing = True
        return False


def rotation(rows: int, hidden: int, device=None):
    """--b3-rotate: a module whose .weight is Q (rows x hidden, orthonormal rows, Q Q^T = I), parametrised with
    torch.nn.utils.parametrizations.orthogonal (Householder map, no trivialization: the one parameter is the rows x
    hidden reflector matrix parametrizations.weight.original, fp32; no H x H base, no random completion, the torch RNG
    is not touched), initialised to the first `rows` coordinate axes (Q[i, i] = 1, exactly). The map reads the
    parameter's diagonal only through its sign (.int(), no gradient): weight decay would shrink it below 1 and zero a
    row of Q, so Q's optimizer group has weight decay 0 (rotation_groups)."""
    import torch
    from torch.nn.utils.parametrizations import orthogonal
    m = torch.nn.Module()
    m.weight = torch.nn.Parameter(torch.eye(rows, hidden, dtype=torch.float32, device=device))
    return orthogonal(m, "weight", orthogonal_map="householder", use_trivialization=False)


def rotation_groups(params: list, rot: list, lr: float) -> list:
    """--b3-rotate: the optimizer's parameter groups [the model's parameters, Q's parameter at lr with weight decay 0].
    A LambdaLR scheduler scales every group by the same factor (Q follows the base warmup / cosine shape times its own
    rate, as --df-head-lr). on_device: fsdp.ShardCPUAdamW steps this group with a torch AdamW on its own device in fp32
    (Q is outside the FSDP model and fp32, the shards bf16); the other optimizers ignore the key."""
    return [{"params": params}, {"params": list(rot), "lr": float(lr), "weight_decay": 0.0, "on_device": True}]


class Frontier:
    """The runtime of the arm: the written layer's module, the source pass and the receiver pass of a micro-batch
    (forward), the --fsdp dispatch (call) and the readout (readout)."""

    def __init__(self, model, spec: B3Spec):
        import torch
        from .student import body_layers, text_parts
        validate_spec(spec)
        self.spec = spec
        root = model.model if getattr(model, "cotd_readout", False) else model
        self.body, _ = text_parts(root)
        self.dl = body_layers(self.body)
        n = len(self.dl)
        if not 0 <= spec.layer <= n - 2:
            raise ValueError(f"--b3-layer {spec.layer}: 0..{n - 2} (of {n} decoder layers; layer L + 1 must exist)")
        hidden = self.body.get_input_embeddings().weight.shape[1]
        if 2 * spec.dim > hidden:
            raise ValueError(f"--b3-dim {spec.dim} x 2 = {2 * spec.dim} dimensions (the aligned slice [0, d) and the spare "
                             f"slice [d, 2d)) exceed the hidden size {hidden}")
        self.torch = torch
        self.src_forwards = 0            # source-pass forwards actually run (dummy ones included)
        self.src_seconds = 0.0           # their wall time (CUDA synchronised before and after: the smoke's timing)
        self.src_dummy = 0               # --fsdp dummy source passes (not in src_forwards / src_seconds)
        self.rot = None                  # --b3-rotate: the learned map (rotation(); place() moves it to the GPU)
        if spec.rotate:
            self.rot = rotation(2 * spec.dim, hidden, self.body.get_input_embeddings().weight.device)

    # ---- the learned subspace (--b3-rotate)
    def rot_params(self) -> list:
        """Q's trainable parameter (empty without --b3-rotate)."""
        return [] if self.rot is None else list(self.rot.parameters())

    def place(self, device) -> None:
        """Move Q to device (--fsdp: the model is sharded after this object is built, on the CPU)."""
        if self.rot is not None:
            self.rot.to(device)

    def rot_stats(self) -> dict:
        """Log columns: b3_rot_dev = ||Q - Q_init||_F (Q_init = the coordinate axes), b3_rot_dev_src = the same over the
        source rows Q0, b3_rot_orth = max |Q Q^T - I| (the parametrisation keeps it at float error)."""
        torch = self.torch
        with torch.no_grad():
            Q = self.rot.weight.detach().float()
            eye = torch.eye(Q.shape[0], Q.shape[1], device=Q.device)
            d = self.spec.dim
            return {"b3_rot_dev": float((Q - eye).norm()), "b3_rot_dev_src": float((Q[:d] - eye[:d]).norm()),
                    "b3_rot_orth": float((Q @ Q.T - torch.eye(Q.shape[0], device=Q.device)).abs().max())}

    def save_rotation(self, path) -> None:
        """Q (fp32, CPU) and the module's state dict (the reflector parameter) for a reload with rotation()."""
        torch = self.torch
        with torch.no_grad():
            Q = self.rot.weight.detach().float().cpu()
        torch.save({"Q": Q, "state_dict": {k: v.detach().float().cpu() for k, v in self.rot.state_dict().items()},
                    "dim": self.spec.dim, "hidden": Q.shape[1], "layer": self.spec.layer, "map": "householder",
                    "init": "coordinate axes", **self.rot_stats()}, path)

    def call(self, model, tokenizer, batch, max_len: int, cache: dict):
        """forward() on a plain model, or inside the FSDP2 root's forward (fsdp.Readout.run), so both passes see the
        root unit's parameters unsharded; the FSDP path asks forward for the dummy source pass (sync)."""
        if getattr(model, "cotd_readout", False):
            return model.run(lambda m, *a: self.forward(m, *a, sync=True), tokenizer, batch, max_len, cache)
        return self.forward(model, tokenizer, batch, max_len, cache)

    def forward(self, model, tokenizer, batch: list, max_len: int, cache: dict, sync: bool = False):
        """(letter logits of every example, as student.label_logits gives them, stats). B3Examples with nodes get their
        source's layer-L slice [0, d) at each node's source token written into their layer-L output at the node's
        receiver token, into [0, d) (SLOT_ALIGNED) or [d, 2d) (SLOT_SPARE): the source pass (one forward over the
        distinct source texts, no gradient unless spec.source_grad, layer L captured) then the receiver pass with the
        slice-write hook. Plain examples and cfaug views run unchanged in the receiver pass. Positions cut by max_len,
        a 'pos' write that lands on a node token of R and a second write on one (row, token, slot) drop the write
        (stats cut). --b3-rotate: Q0 h_s into the block Q0 / Q1 instead of the slices (_SliceWrite rot; Q is evaluated
        once per call, in fp32, and is in the graph also when the source is detached). Without a write no source pass runs, except under --fsdp (sync, from call) for the written arms: a
        dummy source pass over one receiver text keeps the collectives identical across ranks (CF-AUG never writes, so
        it never needs one)."""
        torch = self.torch
        from .depth_forcing import _Capture
        from .student import _letters, collate, text_parts
        body, head = text_parts(model)
        dev = head.weight.device
        L, d = self.spec.layer, self.spec.dim
        st = empty_stats()
        inter = [(i, e) for i, e in enumerate(batch) if isinstance(e, B3Example) and e.nodes]
        # ---- the source pass
        src_texts = []
        for _, e in inter:
            if e.source_text not in src_texts:
                src_texts.append(e.source_text)
        dummy = not src_texts
        if dummy and sync and self.spec.arm != "cfaug":      # keep the collectives identical across ranks (--fsdp)
            src_texts = [batch[0].text]
        st["n_src"] = 0 if dummy else len(src_texts)
        writes = []
        Q = None
        if self.rot is not None:
            with torch.autocast(dev.type, enabled=False):
                Q = self.rot.weight
        if src_texts:
            src_ex = [Example(t, ["A"], [1.0], 0.0, "final", f"src{j}") for j, t in enumerate(src_texts)]
            sb = collate(tokenizer, src_ex, max_len, dev)
            ctx = torch.enable_grad() if self.spec.source_grad else torch.no_grad()
            if dev.type == "cuda":
                torch.cuda.synchronize(dev)
            t0 = time.perf_counter()
            with ctx, _Capture(self.dl, (L,)) as cap:
                body(input_ids=sb["input_ids"], attention_mask=sb["attention_mask"], use_cache=False)
            if dev.type == "cuda":
                torch.cuda.synchronize(dev)
            if dummy:
                self.src_dummy += 1
            else:
                self.src_seconds += time.perf_counter() - t0
                self.src_forwards += 1
            src_h = cap.h[L]
        taken = set()
        cut_rows = set()
        for i, e in inter:
            srow = src_texts.index(e.source_text)
            bad = {token_at(tokenizer, e.text, a, max_len) for a in e.avoid}
            for r_end, s_end, slot in e.nodes:
                r_pos = token_at(tokenizer, e.text, r_end, max_len)
                s_pos = token_at(tokenizer, e.source_text, s_end, max_len)
                if r_pos is None or s_pos is None or r_pos in bad or (i, r_pos, slot) in taken:
                    st["cut"] += 1
                    cut_rows.add(i)
                    continue
                taken.add((i, r_pos, slot))
                vec = src_h[srow, s_pos, 0:d] if Q is None else src_h[srow, s_pos]   # rotate: the full state
                if not self.spec.source_grad:
                    vec = vec.detach()
                writes.append((i, r_pos, slot * d, (slot + 1) * d, vec))
        # ---- the receiver pass
        b = collate(tokenizer, batch, max_len, dev)
        with _SliceWrite(self.dl[L], writes, rot=Q):
            hidden = body(input_ids=b["input_ids"], attention_mask=b["attention_mask"], use_cache=False).last_hidden_state
        h = hidden[torch.arange(hidden.shape[0], device=dev), b["last"]]
        out = _letters(model, tokenizer, head, h, batch, cache)
        with torch.no_grad():                     # the per-mode CE and hits (detached; the loss is kl_loss's)
            for i, e in enumerate(batch):
                if e.weight <= 0:
                    continue
                z = out[i].detach().float()
                if isinstance(e, B3Example):
                    ce = -torch.log_softmax(z, -1)[e.cf_gold].item()
                    hit = int(z.argmax().item() == e.cf_gold)
                    m = st["modes"][e.mode]
                else:                             # plain: kl_loss's soft CE (the teacher target), hits vs the gold
                    t = torch.tensor(e.target, dtype=z.dtype, device=z.device)
                    ce = float(-(t * torch.log_softmax(z, -1)).sum().item())
                    g = e.gold if e.gold is not None else int(t.argmax().item())
                    hit = int(z.argmax().item() == g)
                    m = st["modes"]["plain"]
                m[0] += 1
                m[1] += ce
                m[2] += hit
                m[3] += int(i in cut_rows)
        st["cut_rows"] = sorted(cut_rows)
        return out, st


    # ---- the readout (the mechanism gate)
    def readout(self, model, tokenizer, items: list, pool: list, max_len: int, bs: int, cache: dict) -> dict:
        """The mechanism gate on items with programs (the receivers), sources drawn from pool + items (seed-keyed, as in
        training). Per (R, k) with a size partner S and a valid decoy S' (else no_decoy) one block holds the gold, cf(S)
        and cf(S') (the training generator, coin "ro-opts"). cf11 (frontiers of >= 2 nodes) / cf1 (one node): S's full
        write; acc = cf(S) pick rate, decoy = cf(S') pick rate, ratio = acc / (acc + decoy). block_plain: the same block
        without a write: gold / cf / decoy pick rates (the option-block confound). misaligned_keep: the training
        strictness construction on the same block (S at a non-aligned address, 'pos' or 'sub' by a seed coin, "ro-strict"):
        keep = the prediction equals the block_plain twin's, per variant (sub, pos_num = every write on a free number
        token, pos_other; a 'pos' draw without free tokens is counted in misaligned_skip). same: boundaries with a
        same-value partner, the full write into R's ORIGINAL question: keep = the un-intervened prediction is kept,
        gold = the gold is picked (sanity). A view with any cut write enters no rate; each dict counts them in "cut".
        Returns {"cf11": {"n", "acc", "decoy", "ratio", "cut"}, "cf1": ..., "block_plain": {"n", "gold", "cf",
        "decoy", "cut"}, "misaligned_keep": {"sub": {"n", "keep"}, "pos_num": ..., "pos_other": ..., "cut"}, "same":
        {"n", "keep", "gold", "cut"}, "tier" (tier() on cf11), "tier_cf1" (on cf1, the S-SIIT reading),
        "no_partner", "no_decoy", "misaligned_skip", "views"}."""
        import torch
        from .student import Example as Ex
        spec = self.spec
        recv = {it["item_id"] for it in items}
        allitems = list(items) + [it for it in pool if it["item_id"] not in recv]
        table = build_table(allitems, spec)
        by = {it["item_id"]: it for it in allitems}
        views, kinds, meta = [], [], []
        no_partner = no_decoy = mis_skip = 0
        for it in items:
            pl = table.get(it["item_id"])
            if pl is None or pl.excluded:
                continue
            for b in pl.bounds:
                key = (b.item_id, b.k)
                if key in table["_partners"]["size"]:
                    sid, sk = table["_partners"]["size"][key]
                    sb = bound_of(table, sid, sk)
                    cf = cf_answer(pl.steps, b.k, b.F, sb.values)
                    dec = decoy_for(table, b, lambda v, pl=pl, b=b: cf_answer(pl.steps, b.k, b.F, v), (pl.gold, cf))
                    if dec is None:
                        no_decoy += 1
                    else:
                        did, _, dv = dec
                        text, options, gold_idx, where = option_block(it, [cf, dv],
                                                                      coin(spec.seed, "ro-opts", f"{b.item_id}|{b.k}"))
                        cf_idx, dec_idx = where[canon_value(cf)], where[canon_value(dv)]
                        r_ends, _ = resolve_ends(it, b.ends)
                        s_ends, _ = resolve_ends(by[sid], sb.ends)
                        src_text = FINAL_TEMPLATE.format(problem=by[sid]["prompt"])
                        tgt = [1.0 if i == cf_idx else 0.0 for i in range(N_OPTIONS)]
                        prompt = FINAL_TEMPLATE.format(problem=text)
                        m = {"gold": gold_idx, "cf": cf_idx, "decoy": dec_idx}
                        views.append(B3Example(prompt, list(LETTERS), tgt, 1.0, "final", it["item_id"], cf_idx,
                                               source_id=sid, source_text=src_text, k=b.k, k_src=sk,
                                               nodes=tuple((r_ends[j], s_ends[j], SLOT_ALIGNED) for j in range(b.size)),
                                               cf_gold=cf_idx, mode="full", orig_gold=gold_idx, cf_s=cf_idx,
                                               decoy=dec_idx, decoy_id=did))
                        kinds.append("cf11" if b.size >= 2 else "cf1")
                        meta.append(m)
                        twin = len(views)                  # the same block without the write
                        views.append(Ex(prompt, list(LETTERS), [1.0 if i == gold_idx else 0.0 for i in range(N_OPTIONS)],
                                        1.0, "final", it["item_id"], gold_idx))
                        kinds.append("block_plain")
                        meta.append(m)
                        rng = coin(spec.seed, "ro-strict", f"{b.item_id}|{b.k}")
                        variant = "pos" if rng.random() < 0.5 else "sub"
                        w = strict_nodes(it, pl, b, sb, by[sid], variant, rng)
                        if w is None:
                            mis_skip += 1
                        else:
                            views.append(B3Example(prompt, list(LETTERS), list(views[twin].target), 1.0, "final",
                                                   it["item_id"], gold_idx, source_id=sid, source_text=src_text, k=b.k,
                                                   k_src=sk, nodes=w[0], cf_gold=gold_idx, mode="strict",
                                                   orig_gold=gold_idx, cf_s=cf_idx, decoy=dec_idx, decoy_id=did,
                                                   variant=w[2], avoid=w[1]))
                            kinds.append("misaligned")
                            meta.append({**m, "twin": twin, "variant": w[2]})
                else:
                    no_partner += 1
                if key in table["_partners"]["samevalue"]:
                    sid, sk = table["_partners"]["samevalue"][key]
                    sb = bound_of(table, sid, sk)
                    r_ends, _ = resolve_ends(it, b.ends)
                    s_ends, _ = resolve_ends(by[sid], sb.ends)
                    g = it["labels"].index(it["gold_label"])
                    tgt = [1.0 if i == g else 0.0 for i in range(len(it["labels"]))]
                    views.append(B3Example(FINAL_TEMPLATE.format(problem=it["prompt"]), list(it["labels"]), tgt, 1.0,
                                           "final", it["item_id"], g, source_id=sid,
                                           source_text=FINAL_TEMPLATE.format(problem=by[sid]["prompt"]), k=b.k, k_src=sk,
                                           nodes=tuple((r_ends[j], s_ends[j], SLOT_ALIGNED) for j in range(b.size)),
                                           cf_gold=g, mode="full", orig_gold=g))
                    kinds.append("same")
                    meta.append({"gold": g, "twin": len(views)})
                    views.append(Ex(FINAL_TEMPLATE.format(problem=it["prompt"]), list(it["labels"]), tgt, 1.0, "final",
                                    it["item_id"], g))
                    kinds.append("same_plain")
                    meta.append({"gold": g})
        res = {**readout_summary([], [], []),
               "no_partner": no_partner, "no_decoy": no_decoy, "misaligned_skip": mis_skip, "views": len(views)}
        if not views:
            res["tier"], res["tier_cf1"] = tier(res), tier(res, "cf1")
            return res
        was_training = model.training
        model.eval()
        dev = next(model.parameters()).device
        preds = [None] * len(views)
        cut = [False] * len(views)
        order = sorted(range(len(views)), key=lambda i: len(views[i].text))
        with torch.no_grad():
            for s in range(0, len(order), bs):
                idx = order[s:s + bs]
                with torch.autocast("cuda", dtype=torch.bfloat16, enabled=dev.type == "cuda"):
                    zs, st = self.call(model, tokenizer, [views[i] for i in idx], max_len, cache)
                for i, z in zip(idx, zs):
                    preds[i] = int(z.argmax().item())
                for r in st.get("cut_rows", ()):
                    cut[idx[r]] = True
        if was_training:
            model.train()
        res.update(readout_summary(preds, kinds, meta, cut))
        res["tier"], res["tier_cf1"] = tier(res), tier(res, "cf1")
        return res


class B3Window:
    """The log window: per mode the examples, CE and hits since the last row (row() reads and resets) and cumulative
    totals; add_reduced takes the --fsdp all-reduced vector."""

    def __init__(self):
        self.totals = empty_stats()
        self.reset()

    def reset(self) -> None:
        self.cur = empty_stats()

    def _acc(self, st: dict) -> None:
        for tgt in (self.cur, self.totals):
            for m in STAT_MODES:
                for q in range(4):
                    tgt["modes"][m][q] += st["modes"][m][q]
            tgt["cut"] += st["cut"]
            tgt["n_src"] += st["n_src"]

    def add(self, st: dict) -> None:
        self._acc(st)

    def add_reduced(self, v) -> None:
        self._acc(stats_from_vector(v))

    @staticmethod
    def summary(st: dict) -> dict:
        out = {}
        for m in STAT_MODES:
            n, ce, hit, cut = st["modes"][m]
            if n:
                out[f"b3_{m}_n"] = n
                out[f"b3_{m}_ce"] = round(ce / n, 4)
                out[f"b3_{m}_acc"] = round(hit / n, 4)
                if m not in ("plain", "blockplain"):    # no write: never cut
                    out[f"b3_{m}_cut"] = cut          # views of this mode with a cut write (smoke gate <= 1%)
        out["b3_cut"] = st["cut"]
        out["b3_src_fwd"] = st["n_src"]
        return out

    @staticmethod
    def per_mode(st: dict) -> dict:
        """{mode: {"n", "ce", "acc", "cut"}} for every STAT_MODE (ce / acc None at n = 0): metrics["b3"]["train"][mode]."""
        out = {}
        for m in STAT_MODES:
            n, ce, hit, cut = st["modes"][m]
            out[m] = {"n": n, "ce": round(ce / n, 4) if n else None, "acc": round(hit / n, 4) if n else None,
                      "cut": cut}
        return out

    def row(self) -> dict:
        r = self.summary(self.cur)
        self.reset()
        return r
